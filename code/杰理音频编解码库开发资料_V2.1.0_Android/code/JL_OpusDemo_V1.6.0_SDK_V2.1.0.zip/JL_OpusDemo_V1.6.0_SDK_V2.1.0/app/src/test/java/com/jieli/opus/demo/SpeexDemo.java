package com.jieli.opus.demo;

import com.jieli.jl_audio_decode.callback.OnDecodeStreamCallback;
import com.jieli.jl_audio_decode.callback.OnStateCallback;
import com.jieli.jl_audio_decode.exceptions.SpeexException;
import com.jieli.jl_audio_decode.speex.SpeexManager;

/**
 * SpeexDemo
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc speex功能示例代码
 */
class SpeexDemo {

    public void decodeFile() {
        String inFilePath = "SPEEX文件路径";
        String outFilePath = "PCM输出文件路径";
        try {
            SpeexManager speexManager = new SpeexManager();
            if (speexManager.isDecodeStream()) return; //正在解码中
            //执行解码文件接口
            speexManager.decodeFile(inFilePath, outFilePath, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误信息
                }
            });
            //不再使用，需要销毁对象
//            speexManager.release();
        } catch (SpeexException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    public void decodeStream() {
        try {
            SpeexManager speexManager = new SpeexManager();
            if (speexManager.isDecodeStream()) return; //正在解码中
            //执行流式解码接口
            speexManager.startDecodeStream(new OnDecodeStreamCallback() {
                @Override
                public void onDecodeStream(byte[] data) {
                    //回调解码数据
                }

                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误信息
                }
            });
            //添加解码数据
            byte[] speexData = new byte[0]; //待解码的SPEEX数据
            speexManager.writeAudioStream(speexData);
            //停止流式解码
            speexManager.stopDecodeStream();
            //不再使用，需要销毁对象
//            speexManager.release();
        } catch (SpeexException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    public void encodeFile() {
        String inFilePath = "PCM文件路径";
        String outFilePath = "SPEEX输出文件路径";
        try {
            SpeexManager speexManager = new SpeexManager();
            //执行编码文件接口
            speexManager.encodeFile(inFilePath, outFilePath, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始编码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //编码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //编码失败
                    //code --- 错误码
                    //message --- 错误信息
                }
            });
            //不再使用，需要销毁对象
//            speexManager.release();
        } catch (SpeexException e) {
            e.printStackTrace(); //初始化失败
        }
    }
}
