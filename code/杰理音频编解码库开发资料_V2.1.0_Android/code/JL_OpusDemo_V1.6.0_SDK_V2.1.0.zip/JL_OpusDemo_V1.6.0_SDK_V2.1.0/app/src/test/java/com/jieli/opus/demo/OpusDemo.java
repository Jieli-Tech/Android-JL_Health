package com.jieli.opus.demo;

import com.jieli.jl_audio_decode.callback.OnDecodeStreamCallback;
import com.jieli.jl_audio_decode.callback.OnEncodeStreamCallback;
import com.jieli.jl_audio_decode.callback.OnStateCallback;
import com.jieli.jl_audio_decode.exceptions.OpusException;
import com.jieli.jl_audio_decode.opus.OpusManager;
import com.jieli.jl_audio_decode.opus.model.OggConfigure;
import com.jieli.jl_audio_decode.opus.model.OpusOption;

/**
 * OpusDemo
 *
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc opus功能示例代码
 * @since 2025/5/19
 */
class OpusDemo {

    /**
     * 解码杰理OPUS文件
     */
    public void decodeJLOpusFile() {
        String inFilePath = "OPUS文件路径";
        String outFilePath = "PCM输出文件路径";
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isDecodeStream()) return; //正在解码中
            //执行解码文件接口
            opusManager.decodeFile(inFilePath, outFilePath, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 解码标准OPUS文件
     */
    public void decodeStandardOpusFile() {
        String inFilePath = "OPUS文件路径";
        String outFilePath = "PCM输出文件路径";
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isDecodeStream()) return; //正在解码中
            OpusOption option = new OpusOption()
                    .setHasHead(true)
                    .setSampleRate(16000)
                    .setChannel(1);
            //执行解码文件接口
            opusManager.decodeFile(inFilePath, outFilePath, option, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 解码杰理OPUS数据流
     */
    public void decodeJLOpusStream() {
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isDecodeStream()) return; //正在解码中
            //执行解码流数据接口
            opusManager.startDecodeStream(new OnDecodeStreamCallback() {
                @Override
                public void onDecodeStream(byte[] data) {
                    //回调解码数据
                }

                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 结束信息
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //添加解码数据
            byte[] opusData = new byte[0]; //需要解码的OPUS压缩数据
            opusManager.writeAudioStream(opusData);
            //停止流式解码
            opusManager.stopDecodeStream();
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 解码标准OPUS数据流
     */
    public void decodeStandardOpusStream() {
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isDecodeStream()) return; //正在解码中
            OpusOption option = new OpusOption()
                    .setHasHead(true)
                    .setSampleRate(16000)
                    .setChannel(1);
            //执行解码流数据接口
            opusManager.startDecodeStream(option, new OnDecodeStreamCallback() {
                @Override
                public void onDecodeStream(byte[] data) {
                    //回调解码数据
                }

                @Override
                public void onStart() {
                    //开始解码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //解码成功
                    //outFilePath --- 结束信息
                }

                @Override
                public void onError(int code, String message) {
                    //解码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //添加解码数据
            byte[] opusData = new byte[0]; //需要解码的OPUS压缩数据
            opusManager.writeAudioStream(opusData);
            //停止流式解码
            opusManager.stopDecodeStream();
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 编码杰理OPUS文件
     */
    public void encodeJLOpusFile() {
        String inFilePath = "PCM文件路径";
        String outFilePath = "OPUS输出文件路径";
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isEncodeStream()) return; //正在编码中
            //执行编码文件接口
            opusManager.encodeFile(inFilePath, outFilePath, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始编码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //编码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //编码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 编码标准OPUS文件
     */
    public void encodeStandardOpusFile() {
        String inFilePath = "PCM文件路径";
        String outFilePath = "OPUS输出文件路径";
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isEncodeStream()) return; //正在编码中
            OpusOption option = new OpusOption()
                    .setHasHead(true)
                    .setSampleRate(16000)
                    .setChannel(1);
            //执行编码文件接口
            opusManager.encodeFile(inFilePath, outFilePath, option, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始编码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //编码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //编码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 编码PCM数据流成为杰理OPUS数据
     */
    public void encodeJLOpusStream() {
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isEncodeStream()) return; //正在编码中
            //执行编码流数据接口
            opusManager.startEncodeStream(new OnEncodeStreamCallback() {

                @Override
                public void onEncodeStream(byte[] data) {
                    //回调编码数据
                }

                @Override
                public void onStart() {
                    //开始编码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //编码成功
                    //outFilePath --- 结束信息
                }

                @Override
                public void onError(int code, String message) {
                    //编码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //添加编码数据
            byte[] pcmData = new byte[0]; //需要编码的PCM数据
            opusManager.writeEncodeStream(pcmData);
            //停止流式编码
            opusManager.stopEncodeStream();
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    /**
     * 编码PCM数据流成为标准OPUS数据
     */
    public void encodeStandardOpusStream() {
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isEncodeStream()) return; //正在编码中
            OpusOption option = new OpusOption()
                    .setHasHead(true)
                    .setSampleRate(16000)
                    .setChannel(1);
            //执行编码流数据接口
            opusManager.startEncodeStream(option, new OnEncodeStreamCallback() {

                @Override
                public void onEncodeStream(byte[] data) {
                    //回调编码数据
                }

                @Override
                public void onStart() {
                    //开始编码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //编码成功
                    //outFilePath --- 结束信息
                }

                @Override
                public void onError(int code, String message) {
                    //编码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //添加编码数据
            byte[] pcmData = new byte[0]; //需要编码的PCM数据
            opusManager.writeEncodeStream(pcmData);
            //停止流式编码
            opusManager.stopEncodeStream();
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    public void transcodingOggFile() {
        String inFilePath = "OPUS文件路径";
        String outFilePath = "OGG输出文件路径";
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isTranscoding()) return; //正在转码中
            OggConfigure configure = new OggConfigure(); //OGG封装配置
            //执行转码OGG文件接口
            opusManager.transcodingOggFile(inFilePath, outFilePath, configure, new OnStateCallback() {
                @Override
                public void onStart() {
                    //开始转码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //转码成功
                    //outFilePath --- 输出文件路径
                }

                @Override
                public void onError(int code, String message) {
                    //转码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }

    public void transcodingOggStream() {
        try {
            OpusManager opusManager = new OpusManager();
            if (opusManager.isTranscoding()) return; //正在转吗中
            OggConfigure configure = new OggConfigure(); //OGG封装配置
            //执行转码流数据接口
            opusManager.startTranscodingStream(configure, new OnDecodeStreamCallback() {
                @Override
                public void onDecodeStream(byte[] data) {
                    //回调转码数据
                }

                @Override
                public void onStart() {
                    //开始转码
                }

                @Override
                public void onComplete(String outFilePath) {
                    //转码成功
                    //outFilePath --- 结束信息
                }

                @Override
                public void onError(int code, String message) {
                    //转码失败
                    //code --- 错误码
                    //message --- 错误描述
                }
            });
            //添加转码数据
            byte[] opusData = new byte[0]; //需要转码的OPUS压缩数据
            opusManager.writeTransCodingStream(opusData);
            //停止流式转码
            opusManager.stopTranscodingStream();
            //销毁OPUS管理器
//            opusManager.release();
        } catch (OpusException e) {
            e.printStackTrace(); //初始化失败
        }
    }
}
