package com.jieli.opus.ui;

import android.os.Bundle;

import com.jieli.component.utils.SystemUtil;
import com.jieli.jl_audio_decode.constant.DecodeConstant;
import com.jieli.opus.R;
import com.jieli.opus.databinding.ActivityMainBinding;
import com.jieli.opus.ui.base.BaseActivity;
import com.jieli.opus.ui.ogg.OggFragment;
import com.jieli.opus.ui.opus.OpusFragment;

import java.util.Locale;

public class MainActivity extends BaseActivity {

    private ActivityMainBinding mMainBinding;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        mMainBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mMainBinding.getRoot());

        initUI();
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        finish();
    }

    private void initUI() {
        mMainBinding.viewTopBar.tvLeft.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
        mMainBinding.viewTopBar.tvTitle.setText(getString(R.string.app_name));

        mMainBinding.tvAppVersionName.setText(getString(R.string.app_version));
        mMainBinding.tvAppVersion.setText(String.format(Locale.ENGLISH, "V%s_%d", SystemUtil.getVersioName(this),
                SystemUtil.getVersion(this)));
        mMainBinding.tvLibVersionName.setText(getString(R.string.jl_audio_decode_lib_version));
        mMainBinding.tvLibVersion.setText(String.format(Locale.ENGLISH, "V%s_%d", DecodeConstant.getLibVersionName(),
                DecodeConstant.getLibVersionCode()));

        mMainBinding.btnOpus.setOnClickListener(v -> ContentActivity.startActivity(this, OpusFragment.class.getCanonicalName()));
        mMainBinding.btnOgg.setOnClickListener(v -> ContentActivity.startActivity(this, OggFragment.class.getCanonicalName()));
    }
}