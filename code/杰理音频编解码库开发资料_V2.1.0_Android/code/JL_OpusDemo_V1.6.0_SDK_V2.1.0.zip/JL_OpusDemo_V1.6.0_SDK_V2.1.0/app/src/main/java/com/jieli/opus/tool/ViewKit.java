package com.jieli.opus.tool;

import android.text.TextUtils;
import android.view.View;
import android.widget.EditText;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 控件工具类
 * @since 2024/1/23
 */
public class ViewKit {

    public static void setViewVisibility(View view, int visibility) {
        if (null == view) return;
        if (visibility != view.getVisibility()) {
            view.setVisibility(visibility);
        }
    }

    public static void show(View view) {
        setViewVisibility(view, View.VISIBLE);
    }

    public static void hide(View view) {
        setViewVisibility(view, View.INVISIBLE);
    }

    public static void gone(View view) {
        setViewVisibility(view, View.GONE);
    }

    public static boolean isShow(View view) {
        return view != null && view.getVisibility() == View.VISIBLE;
    }

    public static boolean isHide(View view) {
        return view != null && view.getVisibility() == View.INVISIBLE;
    }

    public static boolean isGone(View view) {
        return view != null && view.getVisibility() == View.GONE;
    }

    public static int getValueByEditView(EditText et) {
        if (null == et) return 0;
        String text = et.getText().toString().trim();
        if (!text.isEmpty() && TextUtils.isDigitsOnly(text)) {
            try {
                return Integer.parseInt(text);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return 0;
    }
}
