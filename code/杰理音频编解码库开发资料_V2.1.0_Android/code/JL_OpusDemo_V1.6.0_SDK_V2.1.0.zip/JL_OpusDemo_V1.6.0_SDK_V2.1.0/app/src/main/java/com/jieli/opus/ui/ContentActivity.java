package com.jieli.opus.ui;

import android.content.Context;
import android.content.Intent;
import android.os.Bundle;


import com.jieli.component.utils.SystemUtil;
import com.jieli.opus.ui.base.BaseActivity;
import com.jieli.opus.R;

import java.util.HashMap;
import java.util.Map;


/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 通用界面
 * @since 2024/1/22
 */
public class ContentActivity extends BaseActivity {

    public static final String FRAGMENT_TAG = "fragment_tag";
    public static final String FRAGMENT_DATA = "fragment_data";

    private static final long MIN_START_SPACE_TIME = 1000L;
    private static final Map<String, Long> fastClickLimit = new HashMap<>();

    public static void startActivity(Context context, String fragmentName) {
        startActivity(context, fragmentName, null);
    }

    public static void startActivity(Context context, String fragmentName, Bundle bundle) {
        if (null == context || null == fragmentName || fastStart(fragmentName)) return;
        Intent intent = new Intent(context, ContentActivity.class);
        intent.putExtra(FRAGMENT_TAG, fragmentName);
        if (null != bundle) {
            intent.putExtra(FRAGMENT_DATA, bundle);
        }
        context.startActivity(intent);
    }

    private static boolean fastStart(String fragmentName) {
        Long startTime = fastClickLimit.get(fragmentName);
        long currentTime = System.currentTimeMillis();
        if (startTime != null && currentTime - startTime < MIN_START_SPACE_TIME) {
            return true;
        }
        fastClickLimit.put(fragmentName, currentTime);
        return false;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        setContentView(R.layout.activity_content);
        if (null == getIntent()) {
            finish();
            return;
        }
        String fragmentName = getIntent().getStringExtra(FRAGMENT_TAG);
        if (null == fragmentName) {
            finish();
            return;
        }
        Bundle data = getIntent().getParcelableExtra(FRAGMENT_DATA);
        replaceFragment(R.id.fl_container, fragmentName, data);
    }

    @Override
    public void onBackPressed() {
//        super.onBackPressed();
        finish();
    }
}