package com.jieli.opus.ui.ogg;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.jieli.jl_audio_decode.opus.model.OggConfigure;
import com.jieli.opus.R;
import com.jieli.opus.data.constant.Constants;
import com.jieli.opus.data.model.opus.OggParam;
import com.jieli.opus.data.model.opus.OggResult;
import com.jieli.opus.data.model.resource.PlayerState;
import com.jieli.opus.data.model.resource.ResourceInfo;
import com.jieli.opus.data.model.result.StateResult;
import com.jieli.opus.databinding.FragmentOggTranscodingBinding;
import com.jieli.opus.tool.AppUtil;
import com.jieli.opus.tool.ViewKit;
import com.jieli.opus.ui.base.BaseFragment;
import com.jieli.opus.ui.base.SelectFileAdapter;
import com.jieli.opus.ui.dialog.TipsDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * OggTranscodingFragment
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OGG转码界面
 */
public class OggTranscodingFragment extends BaseFragment {

    private final OggViewModel mViewModel;
    private FragmentOggTranscodingBinding mBinding;
    private SelectFileAdapter mAdapter;

    private TipsDialog mResultDialog;

    /**
     * 是否正在读取资源
     */
    private boolean isReadRes;

    private final Observer<StateResult<OggResult>> transcodingStateObserver = result -> {
        if (result.getState() == StateResult.STATE_WORKING) {
            requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            mBinding.btnTranscoding.setText(getString(R.string.stop_transcoding));
            OggResult transcodingResult = result.getData();
            if (null != transcodingResult && transcodingResult.getWay() == Constants.WAY_FILE) {
                showLoading(getString(R.string.transcoding));
            }
            return;
        }
        if (result.getState() == StateResult.STATE_FINISH) {
            dismissLoading();
            requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            mBinding.btnTranscoding.setText(getString(R.string.start_transcoding));
            showResultDialog(result);
        }
    };

    public OggTranscodingFragment(OggViewModel viewModel) {
        mViewModel = viewModel;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentOggTranscodingBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
        addObserver();

        readFileList();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        dismissResultDialog();
        mViewModel.transcodingStateMLD.removeObserver(transcodingStateObserver);
    }

    private void initUI() {
        mBinding.btnRefresh.setOnClickListener(v -> readFileList());
        mBinding.btnAudioPp.setOnClickListener(v -> {
            if (mViewModel.isPlayAudio()) {
                mViewModel.pauseAudio();
            } else {
                mViewModel.playAudio(null);
            }
        });
        mBinding.btnTranscoding.setOnClickListener(v -> tryToTranscoding());

        mAdapter = new SelectFileAdapter();
        final View emptyView = LayoutInflater.from(requireContext()).inflate(R.layout.view_empty_tips, null, false);
        TextView tvTips = emptyView.findViewById(R.id.tv_tips);
        tvTips.setText(String.format(Locale.ENGLISH, "%s[%s]", getString(R.string.store_file_tips),
                AppUtil.getOpusFileDirPath(requireContext())));
        emptyView.findViewById(R.id.tv_refresh).setOnClickListener(v -> readFileList());
        mAdapter.setEmptyView(emptyView);
        mAdapter.setOnItemClickListener((adapter, view, position) -> {
            if (mViewModel.isTranscoding()) return;
            ResourceInfo resource = mAdapter.getItem(position);
            if (null == resource) return;
            if (mAdapter.isSelectedItem(resource)) {
                resource = null;
            }
            mViewModel.stopAudioPlay();
            mAdapter.updateSelectedItem(resource);
        });
        mBinding.rvOpusFile.setLayoutManager(new LinearLayoutManager(requireContext()));
        mBinding.rvOpusFile.setAdapter(mAdapter);
        updatePlayBtn(new PlayerState());
    }

    private void addObserver() {
        mViewModel.syncStateMLD.observe(this, result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            if (result.isSuccess()) {
                readFileList();
                return;
            }
            showTips(String.format(Locale.ENGLISH, "syncStateMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.resourceListMLD.observe(getViewLifecycleOwner(), result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            if (!isReadRes) return;
            if (result.isSuccess()) {
                if (!Constants.DIR_OPUS.equals(result.getMessage())) return;
                isReadRes = false;
                List<ResourceInfo> list = new ArrayList<>();
                List<ResourceInfo> src = result.getData();
                if (null != src) {
                    for (ResourceInfo resource : src) {
                        if (resource.getType() == ResourceInfo.TYPE_OPUS) {
                            list.add(resource);
                        }
                    }
                }
                mAdapter.setList(list);
                mAdapter.updateSelectedItem(null);
                return;
            }
            isReadRes = false;
            showTips(String.format(Locale.ENGLISH, "resourceListMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.transcodingStateMLD.observeForever(transcodingStateObserver);
        mViewModel.playStateMLD.observe(getViewLifecycleOwner(), this::updatePlayBtn);
    }

    private void readFileList() {
        if (mViewModel.isSyncResourceSuccess() && !isReadRes) {
            isReadRes = true;
            mViewModel.readFileList(requireContext(), Constants.DIR_OPUS);
        }
    }

    private void tryToTranscoding() {
        if (mViewModel.isTranscoding()) {
            mViewModel.stopTranscoding();
            return;
        }
        final ResourceInfo resource = mAdapter.getResource();
        if (null == resource) {
            showTips(getString(R.string.select_file_tips));
            return;
        }
        try {
            int packetLen = ViewKit.getValueByEditView(mBinding.etPacket);
            int pageCount = ViewKit.getValueByEditView(mBinding.etPageCount);
            int way = mBinding.rgDecodeWay.getCheckedRadioButtonId() == R.id.rbtn_file_way ?
                    Constants.WAY_FILE : Constants.WAY_STREAM;
            boolean isPlayAudio = mBinding.cbPlayAudio.isChecked();
            OggParam oggParam = new OggParam(new OggConfigure().setFrameLen(packetLen).setPageFrameCount(pageCount))
                    .setWay(way).setPlayAudio(isPlayAudio);
            mViewModel.startTranscoding(requireContext(), resource.getPath(), oggParam);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updatePlayBtn(PlayerState state) {
        mBinding.btnAudioPp.setEnabled(!state.isStop());
        mBinding.btnAudioPp.setBackgroundResource(state.isStop() ? R.drawable.bg_btn_8_gray_shape : R.drawable.bg_btn_blue_gray_8_selector);
        mBinding.btnAudioPp.setText(state.isPlay() ? getString(R.string.audio_pause) : getString(R.string.audio_play));
    }

    private String getTranscodingWay(int way) {
        if (way == Constants.WAY_FILE) {
            return getString(R.string.way_file);
        }
        return getString(R.string.way_data_stream);
    }

    private void showResultDialog(StateResult<OggResult> result) {
        if (!isValid()) return;
        dismissResultDialog();
        OggResult oggResult = result.getData();
        String title = getString(result.isSuccess() ? R.string.transcoding_success : R.string.transcoding_fail);
        String content;
        if (result.isSuccess()) {
            if (oggResult == null) {
                content = "None Data";
            } else {
                StringBuilder builder = new StringBuilder();
                builder.append("|=============================\n")
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.input_file), oggResult.getInFilePath()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.output_content), oggResult.getOutFilePath()))
                        .append("|=============================\n")
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.transcoding_way), getTranscodingWay(oggResult.getWay())))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %d\n", getString(R.string.packet_len), oggResult.getOggParam().getConfigure().getFrameLen()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %d\n", getString(R.string.page_count), oggResult.getOggParam().getConfigure().getPageFrameCount()))
                        .append("|=============================\n");
                content = builder.toString();
            }
        } else {
            content = String.format(Locale.ENGLISH, "%s : %d(0x%X)\n%s : %s", getString(R.string.error_code), result.getCode(), result.getCode(),
                    getString(R.string.error_msg), result.getMessage());
        }
        mResultDialog = (TipsDialog) new TipsDialog.Builder()
                .title(title)
                .content(content, false, 0, Gravity.START)
                .confirmBtn((dialog, view) -> dismissResultDialog())
                .setCancelable(false)
                .setWidthRate(0.9f)
                .build();
        mResultDialog.show(getChildFragmentManager(), "Result Dialog");
    }

    private void dismissResultDialog() {
        if (mResultDialog == null) return;
        if (mResultDialog.isShow() && isValid()) {
            mResultDialog.dismiss();
        }
        mResultDialog = null;
    }
}