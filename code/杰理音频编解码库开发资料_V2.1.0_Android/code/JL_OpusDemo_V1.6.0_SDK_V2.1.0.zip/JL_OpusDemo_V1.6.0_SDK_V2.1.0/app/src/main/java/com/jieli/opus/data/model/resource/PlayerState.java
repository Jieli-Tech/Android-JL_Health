package com.jieli.opus.data.model.resource;

/**
 * PlayerState
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 播放器状态
 */
public class PlayerState {
    private boolean isStop;
    private boolean isPlay;
    private boolean isPause;

    public PlayerState(){
        this(true, false, false);
    }

    public PlayerState(boolean isStop, boolean isPlay, boolean isPause) {
        this.isStop = isStop;
        this.isPlay = isPlay;
        this.isPause = isPause;
    }

    public boolean isStop() {
        return isStop;
    }

    public PlayerState setStop(boolean stop) {
        isStop = stop;
        return this;
    }

    public boolean isPlay() {
        return isPlay;
    }

    public PlayerState setPlay(boolean play) {
        isPlay = play;
        return this;
    }

    public boolean isPause() {
        return isPause;
    }

    public PlayerState setPause(boolean pause) {
        isPause = pause;
        return this;
    }

    @Override
    public String toString() {
        return "PlayerState{" +
                "isStop=" + isStop +
                ", isPlay=" + isPlay +
                ", isPause=" + isPause +
                '}';
    }
}
