package com.jieli.opus.ui.opus;

import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.jieli.opus.R;
import com.jieli.opus.data.constant.Constants;
import com.jieli.opus.data.model.opus.OpusConfiguration;
import com.jieli.opus.data.model.opus.OpusParam;
import com.jieli.opus.data.model.opus.OpusResult;
import com.jieli.opus.data.model.resource.PlayerState;
import com.jieli.opus.data.model.resource.ResourceInfo;
import com.jieli.opus.data.model.result.StateResult;
import com.jieli.opus.databinding.FragmentOpusDecodeBinding;
import com.jieli.opus.tool.AppUtil;
import com.jieli.opus.tool.ViewKit;
import com.jieli.opus.ui.base.BaseFragment;
import com.jieli.opus.ui.base.SelectFileAdapter;
import com.jieli.opus.ui.dialog.TipsDialog;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * OPUS解码界面
 */
public class OpusDecodeFragment extends BaseFragment {

    @NonNull
    private final OpusViewModel mViewModel;
    private FragmentOpusDecodeBinding mBinding;
    private SelectFileAdapter mAdapter;

    private TipsDialog mResultDialog;

    /**
     * 是否正在读取资源
     */
    private boolean isReadRes;

    public OpusDecodeFragment(@NonNull OpusViewModel viewModel) {
        mViewModel = viewModel;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentOpusDecodeBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
        observerCallback();

        readFileList();
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        dismissResultDialog();
        mViewModel.decodeStateMLD.removeObserver(decodeStateObserver);
    }

    private final Observer<StateResult<OpusResult>> decodeStateObserver = result -> {
        if (result.getState() == StateResult.STATE_WORKING) {
            requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            mBinding.btnDecode.setText(getString(R.string.stop_decoding));
            OpusResult decodeResult = result.getData();
            if (null != decodeResult && decodeResult.getWay() == Constants.WAY_FILE) {
                showLoading(getString(R.string.decoding));
            }
            return;
        }
        if (result.getState() == StateResult.STATE_FINISH) {
            dismissLoading();
            requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
            mBinding.btnDecode.setText(getString(R.string.start_decoding));
            showResultDialog(result);
        }
    };

    private void initUI() {
        mBinding.btnRefresh.setOnClickListener(v -> readFileList());
        mBinding.btnAudioPp.setOnClickListener(v -> {
            if (mViewModel.isPlayAudio()) {
                mViewModel.pause();
            } else {
                mViewModel.play();
            }
        });
        mBinding.btnDecode.setOnClickListener(v -> tryToDecode());

        mBinding.cbHasHeaders.setOnCheckedChangeListener((buttonView, isChecked) -> mBinding.llPacketLen.setVisibility(isChecked ? View.GONE : View.VISIBLE));
        mBinding.spinnerSampleRate.setSelection(2); //默认是16000 Hz

        mAdapter = new SelectFileAdapter();
        final View emptyView = LayoutInflater.from(requireContext()).inflate(R.layout.view_empty_tips, null, false);
        TextView tvTips = emptyView.findViewById(R.id.tv_tips);
        tvTips.setText(String.format(Locale.ENGLISH, "%s[%s]", getString(R.string.store_file_tips),
                AppUtil.getOpusFileDirPath(requireContext())));
        emptyView.findViewById(R.id.tv_refresh).setOnClickListener(v -> readFileList());
        mAdapter.setEmptyView(emptyView);
        mAdapter.setOnItemClickListener((adapter, view, position) -> {
            if (mViewModel.isDecoding()) return;
            ResourceInfo resource = mAdapter.getItem(position);
            if (null == resource) return;
            if (mAdapter.isSelectedItem(resource)) {
                resource = null;
            }
            mAdapter.updateSelectedItem(resource);
        });
        mBinding.rvOpusFile.setLayoutManager(new LinearLayoutManager(requireContext()));
        mBinding.rvOpusFile.setAdapter(mAdapter);

        mBinding.llChannelNum.setVisibility(Constants.IS_SUPPORT_DUAL_CHANNEL ? View.VISIBLE : View.GONE);
        updatePlayBtn(new PlayerState());
    }

    private void observerCallback() {
        mViewModel.syncStateMLD.observe(this, result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            if (result.isSuccess()) {
                readFileList();
                return;
            }
            showTips(String.format(Locale.ENGLISH, "syncStateMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.resourceListMLD.observe(getViewLifecycleOwner(), result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            if (!isReadRes) return;
            if (result.isSuccess()) {
                if (!Constants.DIR_OPUS.equals(result.getMessage())) return;
                isReadRes = false;
                List<ResourceInfo> list = new ArrayList<>();
                List<ResourceInfo> src = result.getData();
                if (null != src) {
                    for (ResourceInfo resource : src) {
                        if (resource.getType() == ResourceInfo.TYPE_OPUS) {
                            list.add(resource);
                        }
                    }
                }
                mAdapter.setList(list);
                mAdapter.updateSelectedItem(null);
                return;
            }
            isReadRes = false;
            showTips(String.format(Locale.ENGLISH, "resourceListMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.decodeStateMLD.observeForever(decodeStateObserver);
        mViewModel.playStateMLD.observe(getViewLifecycleOwner(), this::updatePlayBtn);
    }

    private void readFileList() {
        if (mViewModel.isSyncResourceSuccess() && !isReadRes) {
            isReadRes = true;
            mViewModel.readFileList(requireContext(), Constants.DIR_OPUS);
        }
    }

    private void tryToDecode() {
        if (mViewModel.isDecoding()) {
            mViewModel.stopDecode();
            return;
        }
        final ResourceInfo resource = mAdapter.getResource();
        if (null == resource) {
            showTips(getString(R.string.select_file_tips));
            return;
        }
        try {
            boolean hasHeaders = mBinding.cbHasHeaders.isChecked();
            int packetLen = ViewKit.getValueByEditView(mBinding.etPacket);
            int sampleRate = Integer.parseInt((String) mBinding.spinnerSampleRate.getSelectedItem());
            int channel = mBinding.rgChannelNum.getCheckedRadioButtonId() == R.id.rbtn_dual_channel ?
                    OpusConfiguration.CHANNEL_DUAL : OpusConfiguration.CHANNEL_MONO;
            int decodeWay = mBinding.rgDecodeWay.getCheckedRadioButtonId() == R.id.rbtn_file_way ?
                    Constants.WAY_FILE : Constants.WAY_STREAM;
            boolean isPlayAudio = mBinding.cbPlayAudio.isChecked();
            OpusParam param = new OpusParam(new OpusConfiguration().setHasHead(hasHeaders).setPacketSize(packetLen)
                    .setSampleRate(sampleRate).setChannel(channel))
                    .setWay(decodeWay).setPlayAudio(isPlayAudio);
            mViewModel.startDecode(requireContext(), resource.getPath(), param);
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void updatePlayBtn(PlayerState state) {
        mBinding.btnAudioPp.setEnabled(!state.isStop());
        mBinding.btnAudioPp.setBackgroundResource(state.isStop() ? R.drawable.bg_btn_8_gray_shape : R.drawable.bg_btn_blue_gray_8_selector);
        mBinding.btnAudioPp.setText(state.isPlay() ? getString(R.string.audio_pause) : getString(R.string.audio_play));
    }

    private String getDecodeWay(int way) {
        if (way == Constants.WAY_FILE) {
            return getString(R.string.way_file);
        }
        return getString(R.string.way_data_stream);
    }

    private void showResultDialog(StateResult<OpusResult> result) {
        if (!isValid()) return;
        dismissResultDialog();
        OpusResult opusResult = result.getData();
        String title = getString(result.isSuccess() ? R.string.decoding_success : R.string.decoding_fail);
        String content;
        if (result.isSuccess()) {
            if (opusResult == null) {
                content = "None Data";
            } else {
                StringBuilder builder = new StringBuilder();
                builder.append("|=============================\n")
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.input_file), opusResult.getInFilePath()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.output_content), opusResult.getOutFilePath()))
                        .append("|=============================\n")
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.decode_way), getDecodeWay(opusResult.getOpusParam().getWay())))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %s\n", getString(R.string.whether_has_headers), opusResult.getOpusParam().getOption().isHasHead()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %d\n", getString(R.string.audio_sample_rate), opusResult.getOpusParam().getOption().getSampleRate()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %d\n", getString(R.string.channel_num), opusResult.getOpusParam().getOption().getChannel()))
                        .append(String.format(Locale.ENGLISH, "|\t%s: %d\n", getString(R.string.packet_len), opusResult.getOpusParam().getOption().getPacketSize()))
                        .append("|=============================\n");
                content = builder.toString();
            }
        } else {
            content = String.format(Locale.ENGLISH, "%s : %d(0x%X)\n%s : %s", getString(R.string.error_code), result.getCode(), result.getCode(),
                    getString(R.string.error_msg), result.getMessage());
        }
        mResultDialog = (TipsDialog) new TipsDialog.Builder()
                .title(title)
                .content(content, false, 0, Gravity.START)
                .confirmBtn((dialog, view) -> dismissResultDialog())
                .setCancelable(false)
                .setWidthRate(0.9f)
                .build();
        mResultDialog.show(getChildFragmentManager(), "Result Dialog");
    }

    private void dismissResultDialog() {
        if (mResultDialog == null) return;
        if (mResultDialog.isShow() && isValid()) {
            mResultDialog.dismiss();
        }
        mResultDialog = null;
    }
}