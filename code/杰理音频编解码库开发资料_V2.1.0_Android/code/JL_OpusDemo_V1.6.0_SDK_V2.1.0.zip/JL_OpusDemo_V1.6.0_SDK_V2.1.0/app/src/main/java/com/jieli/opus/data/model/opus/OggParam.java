package com.jieli.opus.data.model.opus;

import androidx.annotation.NonNull;

import com.jieli.jl_audio_decode.opus.model.OggConfigure;
import com.jieli.opus.data.constant.Constants;

/**
 * OggParam
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OGG转码参数
 */
public class OggParam {

    /**
     * OPUS选项
     */
    @NonNull
    private final OggConfigure configure;
    /**
     * 操作方式
     */
    private int way = Constants.WAY_STREAM;
    /**
     * 是否播放音频
     */
    private boolean isPlayAudio;

    public OggParam() {
        this(new OggConfigure());
    }

    public OggParam(@NonNull OggConfigure configure) {
        this.configure = configure;
    }

    @NonNull
    public OggConfigure getConfigure() {
        return configure;
    }

    public int getWay() {
        return way;
    }

    public OggParam setWay(int way) {
        this.way = way;
        return this;
    }

    public boolean isPlayAudio() {
        return isPlayAudio;
    }

    public OggParam setPlayAudio(boolean playAudio) {
        isPlayAudio = playAudio;
        return this;
    }

    @Override
    public String toString() {
        return "OggParam{" +
                "configure=" + configure +
                ", way=" + way +
                ", isPlayAudio=" + isPlayAudio +
                '}';
    }
}
