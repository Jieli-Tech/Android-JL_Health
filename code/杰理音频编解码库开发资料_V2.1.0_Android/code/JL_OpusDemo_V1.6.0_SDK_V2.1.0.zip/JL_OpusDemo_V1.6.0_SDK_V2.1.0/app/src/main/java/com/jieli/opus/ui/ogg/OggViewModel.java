package com.jieli.opus.ui.ogg;

import android.content.Context;
import android.media.MediaPlayer;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;

import com.jieli.jl_audio_decode.callback.OnDecodeStreamCallback;
import com.jieli.jl_audio_decode.callback.OnStateCallback;
import com.jieli.jl_audio_decode.constant.ErrorCode;
import com.jieli.jl_audio_decode.exceptions.OpusException;
import com.jieli.jl_audio_decode.opus.OpusManager;
import com.jieli.logcat.JL_Log;
import com.jieli.opus.data.constant.Constants;
import com.jieli.opus.data.model.opus.OggParam;
import com.jieli.opus.data.model.opus.OggResult;
import com.jieli.opus.data.model.resource.PlayerState;
import com.jieli.opus.data.model.result.StateResult;
import com.jieli.opus.tool.AppUtil;
import com.jieli.opus.ui.base.ResourceViewModel;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * OggViewModel
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OGG转码逻辑实现
 */
public class OggViewModel extends ResourceViewModel {

    private static final int BLOCK_MTU = 200;
    private static final int SEND_INTERVAL = 10;
    private static final long WAITING_TIMEOUT = 1000L;

    private static final int MSG_WAITING_DATA_TIMEOUT = 0x1234;

    /**
     * OPUS编解码器
     */
    private OpusManager mOpusManager;
    /**
     * 音频播放器
     */
    private final MediaPlayer mMediaPlayer;
    /**
     * OGG转码参数
     */
    private OggParam mOggParam;
    /**
     * 文件输出流
     */
    private FileOutputStream foutStream;

    /**
     * 解码状态回调
     */
    public final MutableLiveData<StateResult<OggResult>> transcodingStateMLD = new MutableLiveData<>();
    /**
     * 播放状态回调
     */
    public final MutableLiveData<PlayerState> playStateMLD = new MutableLiveData<>();
    /**
     * UI处理
     */
    private final Handler uiHandler = new Handler(Looper.getMainLooper(), msg -> {
        if (MSG_WAITING_DATA_TIMEOUT == msg.what) {
            stopTranscoding();
        }
        return true;
    });

    public OggViewModel() {
        try {
            mOpusManager = new OpusManager();
        } catch (OpusException e) {
            e.printStackTrace();
            mOpusManager = null;
        }
        mMediaPlayer = new MediaPlayer();
        mMediaPlayer.setOnPreparedListener(mp -> {
            mp.start();
            callbackPlayState(new PlayerState(false, true, false));
        });
        mMediaPlayer.setOnCompletionListener(mp -> {
            callbackPlayState(new PlayerState());
            mp.reset();
        });
        mMediaPlayer.setOnErrorListener((mp, what, extra) -> {
            callbackPlayState(new PlayerState());
            mp.stop();
            mp.reset();
            return true;
        });
    }

    @Override
    protected void onCleared() {
        super.onCleared();
        uiHandler.removeCallbacksAndMessages(null);
        closeFileStream();
        stopAudioPlay();
        mMediaPlayer.release();
        if (mOpusManager != null) {
            mOpusManager.release();
            mOpusManager = null;
        }
    }

    /**
     * 是否正在转码
     *
     * @return boolean 结果
     */
    public boolean isTranscoding() {
        if (mOpusManager == null) return false;
        if (mOpusManager.isTranscoding()) return true;
        return getTranscodingState().getState() == StateResult.STATE_WORKING;
    }

    /**
     * 开始解码
     *
     * @param context    上下文
     * @param inFilePath 输入文件路径
     * @param param      解码参数
     */
    public void startTranscoding(@NonNull Context context, @NonNull String inFilePath, @NonNull OggParam param) {
        if (isTranscoding()) {
            JL_Log.i(tag, "startTranscoding", "It is decoding.");
            return;
        }
        String inFileName = AppUtil.getFileNameByPath(inFilePath);
        if (inFileName == null || (!inFileName.endsWith(".opus") && !inFileName.endsWith(".OPUS"))) {
            callbackTranscodingFinish(ErrorCode.ERR_BAD_ARGS, "Bad File. " + inFileName);
            return;
        }
        stopAudioPlay();
        String outFilePath = AppUtil.getOutputFileDirPath(context) + File.separator + AppUtil.getNameNoSuffix(inFileName);
        if (param.getWay() == Constants.WAY_STREAM) {
            outFilePath += "_steam.ogg";
            callbackTranscodingWorking(inFilePath, outFilePath, param);
            transcodingOpusStream(inFilePath, outFilePath, param);
        } else {
            outFilePath += "_file.ogg";
            callbackTranscodingWorking(inFilePath, outFilePath, param);
            transcodingOpusFile(inFilePath, outFilePath, param);
        }
    }

    /**
     * 停止解码
     *
     * @return boolean 结果
     */
    public boolean stopTranscoding() {
        if (null == mOpusManager || !isTranscoding()) return false;
        if (null != mOggParam && mOggParam.getWay() == Constants.WAY_STREAM) {
            mOpusManager.stopTranscodingStream();
            return true;
        }
        return false;
    }

    public boolean isPlayAudio() {
        return mMediaPlayer.isPlaying();
    }

    public boolean isPauseAudio() {
        PlayerState state = playStateMLD.getValue();
        return state != null && state.isPause();
    }

    public void playAudio(String path) {
        if (null == path) {
            if (isPauseAudio()) {
                mMediaPlayer.start();
                callbackPlayState(new PlayerState(false, true, false));
            }
            return;
        }
        stopAudioPlay();
        try {
            mMediaPlayer.reset();
            mMediaPlayer.setDataSource(path);
            mMediaPlayer.prepare();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void pauseAudio() {
        if (mMediaPlayer.isPlaying()) {
            mMediaPlayer.pause();
            callbackPlayState(new PlayerState(false, false, true));
        }
    }

    public void stopAudioPlay() {
        if (mMediaPlayer.isPlaying()) {
            mMediaPlayer.stop();
            callbackPlayState(new PlayerState());
        }
    }

    @NonNull
    private StateResult<OggResult> getTranscodingState() {
        StateResult<OggResult> result = transcodingStateMLD.getValue();
        if (null == result) {
            result = new StateResult<>();
        }
        return result;
    }

    private void callbackPlayState(PlayerState state) {
        PlayerState cacheState = playStateMLD.getValue();
        if (cacheState != state) {
            playStateMLD.postValue(state);
        }
    }

    private void callbackTranscodingWorking(@NonNull String inFilePath, @NonNull String outFilePath,
                                            @NonNull OggParam param) {
        mOggParam = param;
        StateResult<OggResult> stateResult = getTranscodingState();
        stateResult.setState(StateResult.STATE_WORKING)
                .setCode(0)
                .setData(new OggResult(inFilePath, outFilePath, param));
        transcodingStateMLD.postValue(stateResult);
    }

    private void callbackTranscodingFinish(int code, String message) {
        JL_Log.d(tag, "callbackTranscodingFinish", "code : " + code + ", " + message);
        StateResult<OggResult> result = getTranscodingState();
        result.setState(StateResult.STATE_FINISH).setCode(code).setMessage(message);
        transcodingStateMLD.postValue(result);
        if (code != 0) {
            OggResult resultData = result.getData();
            if (null != resultData) {
                AppUtil.deleteFile(new File(resultData.getOutFilePath()));
            }
        }
        mOggParam = null;
    }

    private void transcodingOpusStream(@NonNull String inFilePath, @NonNull String outFilePath, @NonNull OggParam param) {
        if (null == mOpusManager) return;
        createFileStream(outFilePath);
        final OnDecodeStreamCallback callback = new OnDecodeStreamCallback() {
            @Override
            public void onDecodeStream(byte[] data) {
                uiHandler.removeMessages(MSG_WAITING_DATA_TIMEOUT);
                uiHandler.sendEmptyMessageDelayed(MSG_WAITING_DATA_TIMEOUT, WAITING_TIMEOUT);
                writeFileData(data);
            }

            @Override
            public void onStart() {
                writeOpusDataHandle(inFilePath);
            }

            @Override
            public void onComplete(String message) {
                JL_Log.d(tag, "transcodingOpusStream", "onComplete : " + outFilePath);
                closeFileStream();
                callbackTranscodingFinish(0, "Success");
                if (param.isPlayAudio()) {
                    playAudio(outFilePath);
                }
            }

            @Override
            public void onError(int code, String message) {
                JL_Log.i(tag, "transcodingOpusStream", "onError : " + code + ", " + message);
                closeFileStream();
                callbackTranscodingFinish(code, message);
            }
        };
        mOpusManager.startTranscodingStream(callback);
    }

    private void transcodingOpusFile(@NonNull String inFilePath, @NonNull String outFilePath, @NonNull OggParam param) {
        if (null == mOpusManager) return;
        File file = new File(inFilePath);
        if (file.exists() && file.isFile()) {
            JL_Log.w(tag, "transcodingOpusFile", "file size : " + file.length());
        }
        final OnStateCallback callback = new OnStateCallback() {
            @Override
            public void onStart() {

            }

            @Override
            public void onComplete(String message) {
                callbackTranscodingFinish(0, "Success");
                if (param.isPlayAudio()) {
                    playAudio(outFilePath);
                }
            }

            @Override
            public void onError(int code, String message) {
                callbackTranscodingFinish(code, message);
            }
        };
        mOpusManager.transcodingOggFile(inFilePath, outFilePath, callback);
    }

    private void writeOpusDataHandle(String filePath) {
        if (null == mOpusManager) return;
        threadPool.submit(() -> {
            try {
                FileInputStream fin = new FileInputStream(filePath);
                int size;
                byte[] buf = new byte[BLOCK_MTU];
                while ((size = fin.read(buf)) != -1) {
                    if (size == 0) continue;
                    if (!isTranscoding()) break;
                    byte[] data = new byte[size];
                    System.arraycopy(buf, 0, data, 0, size);
                    mOpusManager.writeTransCodingStream(data);
                    try {
                        Thread.sleep(SEND_INTERVAL); //模拟小机发送数据间隔
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                        break;
                    }
                }
                fin.close();
            } catch (IOException e) {
                e.printStackTrace();
            }
        });
    }

    private void createFileStream(String filePath) {
        closeFileStream();
        try {
            foutStream = new FileOutputStream(filePath);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }

    private boolean writeFileData(byte[] data) {
        if (null == foutStream) return false;
        try {
            foutStream.write(data, 0, data.length);
            return true;
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    private void closeFileStream() {
        if (null == foutStream) return;
        try {
            foutStream.close();
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            foutStream = null;
        }
    }

}