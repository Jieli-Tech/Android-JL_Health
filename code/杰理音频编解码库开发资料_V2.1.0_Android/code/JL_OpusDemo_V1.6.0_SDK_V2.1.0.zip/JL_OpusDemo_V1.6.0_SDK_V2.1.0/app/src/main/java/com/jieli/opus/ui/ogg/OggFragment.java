package com.jieli.opus.ui.ogg;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.lifecycle.Lifecycle;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.jieli.logcat.JL_Log;
import com.jieli.opus.R;
import com.jieli.opus.data.model.opus.OggResult;
import com.jieli.opus.data.model.opus.OpusResult;
import com.jieli.opus.data.model.result.StateResult;
import com.jieli.opus.databinding.FragmentOggBinding;
import com.jieli.opus.ui.base.BaseFragment;

import java.util.ArrayList;
import java.util.List;

/**
 * OggFragment
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OGG测试界面
 */
public class OggFragment extends BaseFragment {

    private static final boolean IS_ALLOW_SCROLL = false;

    private FragmentOggBinding mBinding;
    private OggViewModel mViewModel;

    /**
     * Fragment集合
     */
    private final List<BaseFragment> fragments = new ArrayList<>();
    /**
     * 选中的Tab位置
     */
    private int selectedPos = 0;

    public static OggFragment newInstance() {
        return new OggFragment();
    }

    private final Observer<StateResult<OggResult>> transcodingObserver = result -> {
        if (result.getState() != StateResult.STATE_FINISH) return;
        if (!result.isSuccess()) {
            showResultDialog(getString(R.string.decoding_fail), result.getMessage(), null);
        }
    };

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mBinding = FragmentOggBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(OggViewModel.class);

        initUI();
        addObserver();
        mViewModel.syncResource(requireContext());
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        mViewModel.transcodingStateMLD.removeObserver(transcodingObserver);
    }

    private void initUI() {
        mBinding.viewTopBar.tvLeft.setOnClickListener(v -> requireActivity().finish());
        mBinding.viewTopBar.tvTitle.setText(getString(R.string.ogg_transcoding));

        mBinding.tlFunction.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                int position = tab.getPosition();
                boolean isTranscoding = mViewModel.isTranscoding();
                JL_Log.d(tag, "onTabSelected", "isTranscoding : " + isTranscoding);
                if (isTranscoding) {
                    if (position != selectedPos) {
                        mBinding.tlFunction.selectTab(mBinding.tlFunction.getTabAt(selectedPos));
                        mBinding.vp2Function.setCurrentItem(selectedPos);
                    }
                    return;
                }
                selectedPos = position;
                mBinding.vp2Function.setCurrentItem(position, true);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        fragments.add(new OggTranscodingFragment(mViewModel));
        fragments.add(new OggOutputFragment(mViewModel));

        mBinding.vp2Function.setAdapter(new MyAdapter(getChildFragmentManager(), getLifecycle(), fragments));
        if (!IS_ALLOW_SCROLL) mBinding.vp2Function.setUserInputEnabled(false);
        mBinding.vp2Function.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {

            @Override
            public void onPageSelected(int position) {
                if (IS_ALLOW_SCROLL) {
                    mBinding.tlFunction.selectTab(mBinding.tlFunction.getTabAt(position));
                }
            }

        });
    }

    private void addObserver() {
        mViewModel.transcodingStateMLD.observeForever(transcodingObserver);
    }

    private static class MyAdapter extends FragmentStateAdapter {
        private final List<BaseFragment> fragments;

        public MyAdapter(@NonNull FragmentManager fragmentManager, @NonNull Lifecycle lifecycle, @NonNull List<BaseFragment> list) {
            super(fragmentManager, lifecycle);
            fragments = list;
        }

        @NonNull
        @Override
        public Fragment createFragment(int position) {
            return fragments.get(position);
        }

        @Override
        public int getItemCount() {
            return fragments.size();
        }
    }
}