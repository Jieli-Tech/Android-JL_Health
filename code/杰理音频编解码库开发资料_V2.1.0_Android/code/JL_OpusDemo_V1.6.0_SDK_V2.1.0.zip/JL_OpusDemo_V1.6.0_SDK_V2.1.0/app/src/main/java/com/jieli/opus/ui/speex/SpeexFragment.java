package com.jieli.opus.ui.speex;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.opus.R;
import com.jieli.opus.ui.base.BaseFragment;

public class SpeexFragment extends BaseFragment {

    private SpeexViewModel mViewModel;

    public static SpeexFragment newInstance() {
        return new SpeexFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_speex, container, false);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(SpeexViewModel.class);
        // TODO: Use the ViewModel
    }

}