package com.jieli.opus.ui.ogg;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.jieli.logcat.JL_Log;
import com.jieli.opus.R;
import com.jieli.opus.data.constant.Constants;
import com.jieli.opus.data.model.resource.PlayerState;
import com.jieli.opus.data.model.resource.ResourceInfo;
import com.jieli.opus.data.model.result.StateResult;
import com.jieli.opus.databinding.FragmentOggOutputBinding;
import com.jieli.opus.tool.AppUtil;
import com.jieli.opus.ui.base.BaseFragment;
import com.jieli.opus.ui.base.SelectFileAdapter;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/**
 * OggOutputFragment
 * @author zqjasonZhong
 * @since 2025/5/19
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OGG输出界面
 */
public class OggOutputFragment extends BaseFragment {

    private final OggViewModel mViewModel;
    private FragmentOggOutputBinding mBinding;
    private SelectFileAdapter mAdapter;

    /**
     * 是否正在读取资源
     */
    private boolean isReadRes;

    public OggOutputFragment(OggViewModel viewModel) {
        mViewModel = viewModel;
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mBinding = FragmentOggOutputBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);
        initUI();
        addObserver();

        readFileList();
    }

    private void initUI() {
        mBinding.btnRefresh.setOnClickListener(v -> readFileList());
        mBinding.btnAudioPp.setOnClickListener(v -> tryToAudioPlayOrPause());

        mAdapter = new SelectFileAdapter();
        final View emptyView = LayoutInflater.from(requireContext()).inflate(R.layout.view_empty_tips, null, false);
        TextView tvTips = emptyView.findViewById(R.id.tv_tips);
        tvTips.setText(String.format(Locale.ENGLISH, "%s[%s]", getString(R.string.store_file_tips),
                AppUtil.getOutputFileDirPath(requireContext())));
        emptyView.findViewById(R.id.tv_refresh).setOnClickListener(v -> readFileList());
        mAdapter.setEmptyView(emptyView);
        mAdapter.setOnItemClickListener((adapter, view, position) -> {
            ResourceInfo resource = mAdapter.getItem(position);
            if (null == resource) return;
            if (mAdapter.isSelectedItem(resource)) {
                resource = null;
            }
            mAdapter.updateSelectedItem(resource);
        });
        mBinding.rvPcmFile.setLayoutManager(new LinearLayoutManager(requireContext()));
        mBinding.rvPcmFile.setAdapter(mAdapter);

        mBinding.btnAudioPp.setBackgroundResource(R.drawable.bg_btn_blue_gray_8_selector);
        updatePlayBtn(new PlayerState());
    }

    private void addObserver() {
        mViewModel.syncStateMLD.observe(getViewLifecycleOwner(), result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            if (result.isSuccess()) {
                readFileList();
                return;
            }
            showTips(String.format(Locale.ENGLISH, "syncStateMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.resourceListMLD.observe(getViewLifecycleOwner(), result -> {
            if (result.getState() != StateResult.STATE_FINISH) return;
            JL_Log.d(tag, "resourceListMLD", "isReadRes = " + isReadRes + ", result " + result.getMessage());
            if (!isReadRes) return;
            if (result.isSuccess()) {
                if (!Constants.DIR_OUTPUT.equals(result.getMessage())) return;
                isReadRes = false;
                List<ResourceInfo> list = new ArrayList<>();
                List<ResourceInfo> src = result.getData();
                if (null != src) {
                    for (ResourceInfo resource : src) {
                        if (resource.getType() == ResourceInfo.TYPE_OGG) {
                            list.add(resource);
                        }
                    }
                }
                mAdapter.setList(list);
                mAdapter.updateSelectedItem(null);
                return;
            }
            isReadRes = false;
            showTips(String.format(Locale.ENGLISH, "resourceListMLD: code = %d, %s", result.getCode(), result.getMessage()));
        });
        mViewModel.playStateMLD.observe(getViewLifecycleOwner(), this::updatePlayBtn);
    }

    public void readFileList() {
        if (mViewModel.isSyncResourceSuccess() && !isReadRes) {
            isReadRes = true;
            mViewModel.readFileList(requireContext(), Constants.DIR_OUTPUT);
        }
    }

    private void updatePlayBtn(PlayerState state) {
        mBinding.btnAudioPp.setText(state.isPlay() ? getString(R.string.audio_pause) : getString(R.string.audio_play));
    }

    private void tryToAudioPlayOrPause() {
        final ResourceInfo resource = mAdapter.getResource();
        if (null == resource) {
            showTips(getString(R.string.select_file_tips));
            return;
        }
        boolean isPlayAudio = mViewModel.isPlayAudio();
        JL_Log.d(tag, "tryToAudioPlayOrPause", "isPlayAudio : " + isPlayAudio);
        if (isPlayAudio) {
            mViewModel.stopAudioPlay();
            return;
        }
        mViewModel.playAudio(resource.getPath());
    }
}