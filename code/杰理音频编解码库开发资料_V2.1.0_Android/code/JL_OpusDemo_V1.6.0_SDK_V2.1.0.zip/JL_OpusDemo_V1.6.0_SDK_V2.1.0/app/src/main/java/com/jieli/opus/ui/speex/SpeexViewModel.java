package com.jieli.opus.ui.speex;

import com.jieli.opus.ui.base.ResourceViewModel;

/**
 * SpeexViewModel
 *
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc SPEEX逻辑实现
 * @since 2024/5/10
 */
public class SpeexViewModel extends ResourceViewModel {


}