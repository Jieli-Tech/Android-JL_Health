package com.jieli.opus.data.model.opus;

import com.jieli.opus.data.constant.Constants;

/**
 * OggResult
 *
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc Ogg转码结果
 * @since 2025/6/6
 */
public class OggResult {
    /**
     * 输入文件路径
     */
    private final String inFilePath;
    /**
     * 输出文件路径
     */
    private final String outFilePath;
    /**
     * OGG转码参数
     */
    private final OggParam oggParam;

    public OggResult(String inFilePath, String outFilePath, OggParam oggParam) {
        this.inFilePath = inFilePath;
        this.outFilePath = outFilePath;
        this.oggParam = oggParam;
    }

    public String getInFilePath() {
        return inFilePath;
    }

    public String getOutFilePath() {
        return outFilePath;
    }

    public OggParam getOggParam() {
        return oggParam;
    }

    public int getWay() {
        if(null == oggParam) return Constants.WAY_FILE;
        return oggParam.getWay();
    }

    @Override
    public String toString() {
        return "OggResult{" +
                "inFilePath='" + inFilePath + '\'' +
                ", outFilePath='" + outFilePath + '\'' +
                ", oggParam=" + oggParam +
                '}';
    }
}
