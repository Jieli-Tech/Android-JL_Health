package com.jieli.opus.data.model.opus;

import com.jieli.opus.data.constant.Constants;

/**
 * OpusDecodeResult
 *
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OPUS解码结果
 * @since 2024/5/10
 */
public class OpusResult {

    /**
     * 输入文件路径
     */
    private final String inFilePath;
    /**
     * 输出文件路径
     */
    private final String outFilePath;
    /**
     * OPUS编码参数
     */
    private final OpusParam opusParam;

    public OpusResult(String inFilePath, String outFilePath, OpusParam param) {
        this.inFilePath = inFilePath;
        this.outFilePath = outFilePath;
        this.opusParam = param;
    }

    public String getInFilePath() {
        return inFilePath;
    }

    public String getOutFilePath() {
        return outFilePath;
    }

    public OpusParam getOpusParam() {
        return opusParam;
    }

    public int getWay() {
        if(null == opusParam) return Constants.WAY_FILE;
        return opusParam.getWay();
    }

    @Override
    public String toString() {
        return "OpusDecodeResult{" +
                "inFilePath='" + inFilePath + '\'' +
                ", outFilePath='" + outFilePath + '\'' +
                ", opusParam=" + opusParam +
                '}';
    }
}
