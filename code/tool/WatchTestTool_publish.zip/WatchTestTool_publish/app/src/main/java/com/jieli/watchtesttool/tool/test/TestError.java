package com.jieli.watchtesttool.tool.test;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 6/4/21
 * @desc : 错误类
 */
public class TestError {

    public static final TestError SUCCESS = new TestError(0, "测试完成");
    public static final TestError FAILED = new TestError(-1, "测试失败");

    public int code;
    public String msg;


    public TestError(int code, String msg) {
        this.code = code;
        this.msg = msg;
    }


    @Override
    public String toString() {
        return "TestError{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                '}';
    }
}
