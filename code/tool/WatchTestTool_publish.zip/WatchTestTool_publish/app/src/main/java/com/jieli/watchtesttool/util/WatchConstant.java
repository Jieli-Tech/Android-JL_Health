package com.jieli.watchtesttool.util;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc
 * @since 2021/4/20
 */
public class WatchConstant {

    public final static int REQUEST_CODE_PERMISSIONS = 2333;
    public final static int REQUEST_CODE_CHECK_GPS = 2334;

    public final static int DEFAULT_CONNECT_WAY = BluetoothConstant.PROTOCOL_TYPE_SPP;

    public final static boolean BAN_AUTO_TEST = true;
    //测试OTA相关功能
    public final static boolean TEST_OTA_FUNC = false;

    public final static String DIR_WATCH = "watch";  //表盘测试文件夹
    public final static String DIR_WATCH_BG = "watch_bg"; //表盘自定义背景测试文件夹
    public final static String DIR_MUSIC = "music"; //音乐文件测试文件夹
    public final static String DIR_CONTACTS = "contacts"; //联系人测试文件夹
    public final static String DIR_UPDATE = "upgrade"; //升级文件

    public final static String DIR_BR23 = "BR23";
    public final static String DIR_BR28 = "BR28";

    public final static String KEY_FORCED_UPDATE_FLAG = "forced_update_flag";  //强制更新资源标志
}
