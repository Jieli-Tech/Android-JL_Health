package com.jieli.watchtesttool.ui.file;

import android.bluetooth.BluetoothDevice;
import android.util.Log;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.component.utils.ToastUtil;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.tool.bluetooth.BluetoothEventListener;
import com.jieli.watchtesttool.tool.watch.WatchManager;

import com.jieli.jl_filebrowse.FileBrowseConstant;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.FileStruct;
import com.jieli.jl_filebrowse.bean.Folder;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_filebrowse.interfaces.DeleteCallback;
import com.jieli.jl_filebrowse.interfaces.FileObserver;
import com.jieli.jl_rcsp.constant.AttrAndFunCode;
import com.jieli.jl_rcsp.constant.Command;
import com.jieli.jl_rcsp.constant.RcspConstant;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.interfaces.rcsp.RcspCommandCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.base.CommandBase;
import com.jieli.jl_rcsp.model.command.sys.GetSysInfoCmd;
import com.jieli.jl_rcsp.model.response.SysInfoResponse;
import com.jieli.jl_rcsp.util.CommandBuilder;
import com.jieli.watchtesttool.ui.file.model.MusicNameInfo;
import com.jieli.watchtesttool.ui.file.model.MusicPlayInfo;
import com.jieli.watchtesttool.ui.file.model.MusicStatusInfo;
import com.jieli.watchtesttool.ui.file.model.PlayModeInfo;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/15/21 5:42 PM
 * @desc :
 */
public class DeviceFileViewModel extends ViewModel implements FileObserver {
    static final int STATE_START = 0;
    static final int STATE_END = 1;//单次读取完成
    static final int STATE_FAILED = 2;
    static final int STATE_FINISH = 3;//改目录读取完成


    MutableLiveData<List<SDCardBean>> SDCardsMutableLiveData = new MutableLiveData<>();
    MutableLiveData<Folder> currentFolderMutableLiveData = new MutableLiveData<>();
    MutableLiveData<List<FileStruct>> filesMutableLiveData = new MutableLiveData<>();
    MutableLiveData<Integer> readStateMutableLiveData = new MutableLiveData<>();
    MutableLiveData<MusicPlayInfo> musicPlayInfoLiveData = new MutableLiveData<>(new MusicPlayInfo());


    public DeviceFileViewModel() {
        FileBrowseManager.getInstance().addFileObserver(this);
        SDCardsMutableLiveData.postValue(FileBrowseManager.getInstance().getOnlineDev());
        WatchManager.getInstance().registerOnRcspCallback(musicInfoHandler);
    }


    public void getCurrentInfo(SDCardBean sdCardBean) {
        Folder folder = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (folder == null) {
            Log.e("sen", "当前目录为null");
            return;
        } else {
            Log.e("sen", "当前目录不为null");
        }
        currentFolderMutableLiveData.postValue(folder);
        filesMutableLiveData.postValue(folder.getChildFileStructs());
        if (!folder.isLoadFinished(false) && folder.getChildFileStructs().size() < 1) {
            loadMore(sdCardBean);
        } else if (folder.isLoadFinished(false)) {
            readStateMutableLiveData.postValue(STATE_FINISH);
        }
    }


    public void append(SDCardBean sdCardBean, FileStruct fileStruct) {
        int ret = FileBrowseManager.getInstance().appenBrowse(fileStruct, sdCardBean);
        if (ret == FileBrowseConstant.ERR_READING) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
        } else if (ret == FileBrowseConstant.ERR_OFFLINE) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_offline);
        } else if (ret == FileBrowseConstant.ERR_BEYOND_MAX_DEPTH) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_beyond_max_depth);
        } else if (ret == FileBrowseConstant.SUCCESS) {
            filesMutableLiveData.postValue(new ArrayList<>());
            currentFolderMutableLiveData.postValue(FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean));
        }
    }


    public void back(SDCardBean sdCardBean, FileStruct fileStruct) {
        Folder current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (current == null) {
            return;
        }
        //当前文件返回
        if (current.getFileStruct().getCluster() == fileStruct.getCluster()) {
            return;
        }
        //遍历父文件夹，直到父文件夹是选中文件夹。
        while (current.getParent() != null && current.getParent().getFileStruct().getCluster() != fileStruct.getCluster()) {
            FileBrowseManager.getInstance().backBrowse(sdCardBean, false);
            current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        }

        //清空文件列表
        filesMutableLiveData.postValue(new ArrayList<>());
        FileBrowseManager.getInstance().backBrowse(sdCardBean, true);
        currentFolderMutableLiveData.postValue(FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean));
    }

    public void play(SDCardBean sdCardBean, FileStruct fileStruct) {
        if (FileBrowseManager.getInstance().isReading()) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
            return;
        }
        FileBrowseManager.getInstance().playFile(fileStruct, sdCardBean);

    }

    public void delete(SDCardBean sdCardBean, FileStruct fileStruct) {
        if (FileBrowseManager.getInstance().isReading()) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
            return;
        }
        List<FileStruct> list = new ArrayList<>();
        list.add(fileStruct);

        FileBrowseManager.getInstance().deleteFile(sdCardBean, list, sdCardBean.getType() > SDCardBean.USB, new DeleteCallback() {
            @Override
            public void onSuccess(FileStruct fileStruct) {
                ToastUtil.showToastShort("删除成功");
                filesMutableLiveData.postValue(new ArrayList<>());
            }

            @Override
            public void onError(int code, FileStruct fileStruct) {
                ToastUtil.showToastShort("删除失败");
            }

            @Override
            public void onFinish() {

            }
        });

    }


    public void loadMore(SDCardBean sdCardBean) {
        int ret = FileBrowseManager.getInstance().loadMore(sdCardBean);
        if (ret == FileBrowseConstant.ERR_LOAD_FINISHED) {
            readStateMutableLiveData.postValue(STATE_FINISH);
        } else if (ret == FileBrowseConstant.ERR_READING) {
            readStateMutableLiveData.postValue(STATE_END);
        } else if (ret != FileBrowseConstant.SUCCESS) {
            readStateMutableLiveData.postValue(STATE_FAILED);
        }
    }

    public void getMusicInfo() {
        WatchManager.getInstance().sendRcspCommand(WatchManager.getInstance().getConnectedDevice(), CommandBuilder.buildGetMusicSysInfoCmd(), RcspConstant.DEFAULT_SEND_CMD_TIMEOUT, new RcspCommandCallback() {
            @Override
            public void onCommandResponse(BluetoothDevice device, CommandBase cmd) {
                if (cmd.getId() != Command.CMD_GET_SYS_INFO) return;
                if (cmd.getStatus() != StateCode.STATUS_SUCCESS) {
                    onErrCode(null, null);
                    return;
                }
                GetSysInfoCmd sysInfoCmd = (GetSysInfoCmd) cmd;
                SysInfoResponse sysInfoResponse = sysInfoCmd.getResponse();
                if (sysInfoResponse.getFunction() != AttrAndFunCode.SYS_INFO_FUNCTION_MUSIC) return;
                musicInfoHandler.parseMusicData(device, sysInfoResponse.getAttrs());
            }

            @Override
            public void onErrCode(BluetoothDevice device, BaseError error) {
                ToastUtil.showToastShort(R.string.get_music_info_failed);
            }
        });
    }


    @Override
    protected void onCleared() {
        FileBrowseManager.getInstance().removeFileObserver(this);
        WatchManager.getInstance().unregisterOnRcspCallback(musicInfoHandler);
        super.onCleared();
    }

    @Override
    public void onFileReceiver(List<FileStruct> fileStructs) {
        filesMutableLiveData.getValue().addAll(fileStructs);
        filesMutableLiveData.postValue(filesMutableLiveData.getValue());
    }

    @Override
    public void onFileReadStop(boolean isEnd) {
        Log.e("sen", "onFileReadStop--->" + isEnd);
        if (isEnd) {
            readStateMutableLiveData.postValue(STATE_FINISH);
        } else {
            readStateMutableLiveData.postValue(STATE_END);
        }
    }

    @Override
    public void onFileReadStart() {
        readStateMutableLiveData.postValue(STATE_START);
    }

    @Override
    public void onFileReadFailed(int reason) {
        readStateMutableLiveData.postValue(STATE_FAILED);

    }

    @Override
    public void onSdCardStatusChange(List<SDCardBean> onLineCards) {


    }


    @Override
    public void OnFlayCallback(boolean success) {
        getMusicInfo();

    }

    private BluetoothEventListener listener = new BluetoothEventListener() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            super.onConnection(device, status);
            if (status != StateCode.CONNECTION_OK && status != StateCode.CONNECTION_CONNECTED) {
                SDCardsMutableLiveData.postValue(new ArrayList<>());
            }
        }
    };

    private MusicInfoHandler musicInfoHandler = new MusicInfoHandler() {
        @Override
        protected void onMusicNameChange(MusicNameInfo musicNameInfo) {
            super.onMusicNameChange(musicNameInfo);
            MusicPlayInfo info = musicPlayInfoLiveData.getValue();
            info.setMusicNameInfo(musicNameInfo);
            musicPlayInfoLiveData.postValue(info);

        }

        @Override
        protected void onPlayModeChange(PlayModeInfo playModeInfo) {
            super.onPlayModeChange(playModeInfo);
            MusicPlayInfo info = musicPlayInfoLiveData.getValue();
            info.setPlayModeInfo(playModeInfo);
            musicPlayInfoLiveData.postValue(info);

        }

        @Override
        protected void onMusicStatusChange(MusicStatusInfo musicStatusInfo) {
            super.onMusicStatusChange(musicStatusInfo);
            MusicPlayInfo info = musicPlayInfoLiveData.getValue();
            info.setMusicStatusInfo(musicStatusInfo);
            musicPlayInfoLiveData.postValue(info);
        }

        @Override
        protected void onDeviceModeChange(int mode) {
            super.onDeviceModeChange(mode);
            MusicPlayInfo info = musicPlayInfoLiveData.getValue();
            info.setDeviceMode(mode);
            musicPlayInfoLiveData.postValue(info);
        }
    };
}
