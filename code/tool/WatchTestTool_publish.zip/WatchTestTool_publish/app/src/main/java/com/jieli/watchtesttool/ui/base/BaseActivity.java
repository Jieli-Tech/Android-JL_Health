package com.jieli.watchtesttool.ui.base;

import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;

/**
 * Des:
 * Author: Bob
 * Date:21-3-2
 * UpdateRemark:
 */
public abstract class BaseActivity extends AppCompatActivity {
    protected final String tag = getClass().getSimpleName();


    public void replaceFragment(int containerId, String fragmentName) {
        replaceFragment(containerId, fragmentName, null);
    }

    public void replaceFragment(int containerId, String fragmentName, Bundle bundle) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(fragmentName);
        if (fragment == null && fragmentName != null) {
            try {
                fragment = (Fragment) Class.forName(fragmentName).newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (fragment != null) {
            fragment.setArguments(getIntent().getExtras());
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

            for (Fragment f : getSupportFragmentManager().getFragments()) {
                fragmentTransaction.hide(f);
            }

            if (!fragment.isAdded()) {
                fragmentTransaction.add(containerId, fragment, fragmentName);
            }
            if (null != bundle) {
                fragment.setArguments(bundle);
            }

            fragmentTransaction.show(fragment);
            fragmentTransaction.commitAllowingStateLoss();
        }
    }

}
