package com.jieli.watchtesttool.ui.home;

import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.view.View;
import android.view.WindowManager;

import androidx.lifecycle.ViewModelProvider;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.component.utils.FileUtil;
import com.jieli.component.utils.SystemUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.jl_bt_ota.util.PreferencesHelper;
import com.jieli.jl_fatfs.utils.FatUtil;
import com.jieli.jl_rcsp.util.JL_Log;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.data.bean.WatchOpData;
import com.jieli.watchtesttool.databinding.ActivityMainBinding;
import com.jieli.watchtesttool.tool.permission.PermissionsHelper;
import com.jieli.watchtesttool.tool.test.TestActivity;
import com.jieli.watchtesttool.ui.ContentActivity;
import com.jieli.watchtesttool.ui.device.AddDeviceFragment;
import com.jieli.watchtesttool.ui.widget.dialog.ResultDialog;
import com.jieli.watchtesttool.ui.widget.dialog.WaitingDialog;
import com.jieli.watchtesttool.util.AppUtil;
import com.jieli.watchtesttool.util.WatchConstant;

import java.io.File;
import java.util.Locale;

public class MainActivity extends TestActivity {

    private ActivityMainBinding mBinding;
    private MainViewModel mViewModel;
    private PermissionsHelper mPermissionsHelper;

    private WaitingDialog mWaitingDialog;
    private ResultDialog mResultDialog;

    private Thread mSyncResThread;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        mBinding = ActivityMainBinding.inflate(getLayoutInflater());
        setContentView(mBinding.getRoot());
        initTestList(mBinding.llTest);


        mBinding.viewMainTopbar.tvTopbarTitle.setText(R.string.test_function);
        mBinding.viewMainTopbar.tvTopbarLeft.setOnClickListener(v -> toAddDeviceFragment());
        mBinding.viewMainTopbar.tvTopbarRight.setText(SystemUtil.getVersioName(getApplicationContext()));

        mViewModel = new ViewModelProvider(this).get(MainViewModel.class);
        mViewModel.mConnectionDataMLD.observe(this, deviceConnectionData -> {
            runOnUiThread(() -> updateConnectionStatus(deviceConnectionData.getStatus() == BluetoothConstant.CONNECT_STATE_CONNECTED, deviceConnectionData.getDevice()));
        });
        mViewModel.mWatchRestoreSysMLD.observe(this, this::handleWatchOpData);

        if (!PermissionsHelper.checkAppPermissionsIsAllow(getApplicationContext())) {
            mPermissionsHelper = new PermissionsHelper(MainActivity.this);
            mPermissionsHelper.checkAppRequestPermissions(PermissionsHelper.sPermissions, new PermissionsHelper.OnPermissionListener() {
                @Override
                public void onPermissionsSuccess(String[] permissions) {
                    //26版本以上，默认重新安装需要强制升级资源一次
                    boolean isUpdate = PreferencesHelper.getSharedPreferences(getApplicationContext()).getBoolean(WatchConstant.KEY_FORCED_UPDATE_FLAG, true);
                    if (isUpdate) {
                        mBinding.btnSyncResource.performClick();
                    }
                    updateConnectionStatus(mViewModel.isConnected(), mViewModel.getConnectedDevice());
                }

                @Override
                public void onPermissionFailed(String permission) {
                    ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
                }
            });
        } else {
            updateConnectionStatus(mViewModel.isConnected(), mViewModel.getConnectedDevice());
        }
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
    }


    @Override
    protected void onDestroy() {
        getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        super.onDestroy();
        mBinding = null;
        mViewModel.destroy();
        if (mPermissionsHelper != null) {
            mPermissionsHelper.destroy();
            mPermissionsHelper = null;
        }
    }

    public void syncResource(View view) {
        if (mSyncResThread == null) {
            mSyncResThread = new Thread(() -> {
                runOnUiThread(this::showWaitingDialog);
                String[] dirArray = new String[]{WatchConstant.DIR_WATCH, WatchConstant.DIR_WATCH_BG, WatchConstant.DIR_MUSIC, WatchConstant.DIR_CONTACTS};
                //26版本以上，默认重新安装需要强制升级资源一次
                boolean isUpdate = PreferencesHelper.getSharedPreferences(getApplicationContext()).getBoolean(WatchConstant.KEY_FORCED_UPDATE_FLAG, true);
                for (String dirName : dirArray) {
                    String dirPath = AppUtil.createFilePath(getApplicationContext(), dirName);
                    File dir = new File(dirPath);
                    if (isUpdate) {
                        if (dir.exists()) {
                            FileUtil.deleteFile(dir);//删除旧的资源文件
                            JL_Log.w(tag, String.format(Locale.getDefault(), "delete dir[%s]", dir.getPath()));
                        }
                        AppUtil.copyAssets(getApplicationContext(), dirName, dirPath);
                    } else {
                        File[] files = dir.listFiles();
                        if (files == null || files.length == 0) {
                            AppUtil.copyAssets(getApplicationContext(), dirName, dirPath);
                        }
                    }
                }
                if (isUpdate) {
                    PreferencesHelper.putBooleanValue(getApplicationContext(), WatchConstant.KEY_FORCED_UPDATE_FLAG, false);
                }
                runOnUiThread(() -> {
                    dismissWaitingDialog();
                    ToastUtil.showToastShort("资源已同步");
                });
                mSyncResThread = null;
            });
            mSyncResThread.start();
        }
    }

    private void toAddDeviceFragment() {
        ContentActivity.startContentActivity(this, AddDeviceFragment.class.getCanonicalName());
    }

    private void updateConnectionStatus(boolean isDevConnected, BluetoothDevice device) {
        mBinding.viewMainTopbar.tvTopbarLeft.setCompoundDrawablesRelativeWithIntrinsicBounds(isDevConnected ? R.drawable.ic_bluetooth_connected_blue :
                R.drawable.ic_bluetooth_disconnect_gray, 0, 0, 0);
        updateDeviceInfo(isDevConnected, device);
        if (isDevConnected) {
            initTestList(mBinding.llTest);
        }
    }

    private void handleWatchOpData(WatchOpData data) {
        if (data.getOp() != WatchOpData.OP_RESTORE_SYS) return;
        switch (data.getState()) {
            case WatchOpData.STATE_START:
                showWaitingDialog();
                break;
            case WatchOpData.STATE_PROGRESS:
//                showRestoreSysDialog(Math.round(data.getProgress()));
                break;
            case WatchOpData.STATE_END:
                dismissWaitingDialog();
                boolean isOk = data.getResult() == 0;
                int res = isOk ? R.drawable.ic_success_green : R.drawable.ic_fail_yellow;
                String text = isOk ? "恢复系统成功" : "恢复系统失败，原因：" + FatUtil.getFatFsErrorCodeMsg(data.getResult());
                if (isOk) ToastUtil.showToastLong(text);
                showResultDialog(isOk, res, text);
                break;
        }
    }

    private void showWaitingDialog() {
        if (isDestroyed()) return;
        if (null == mWaitingDialog) {
            mWaitingDialog = new WaitingDialog();
        }
        if (!mWaitingDialog.isShow()) {
            mWaitingDialog.show(getSupportFragmentManager(), WaitingDialog.class.getSimpleName());
        }
    }

    private void dismissWaitingDialog() {
        if (isDestroyed()) return;
        if (null != mWaitingDialog) {
            if (mWaitingDialog.isShow()) mWaitingDialog.dismiss();
            mWaitingDialog = null;
        }
    }

    private void showResultDialog(boolean result, int res, String text) {
        if (isDestroyed() || isFinishing()) return;
        if (null == mResultDialog) {
            mResultDialog = new ResultDialog.Builder()
                    .setImgId(res)
                    .setOk(result)
                    .setResult(text)
                    .setCancel(false)
                    .setBtnText(getString(R.string.sure))
                    .create();
            mResultDialog.setOnResultListener(isOk -> {
                dismissResultDialog();
                if (!isOk) {
                    mViewModel.disconnectDevice(mViewModel.getConnectedDevice());
                }
            });
        }
        if (!mResultDialog.isShow()) {
            mResultDialog.show(getSupportFragmentManager(), ResultDialog.class.getSimpleName());
        }
    }

    private void dismissResultDialog() {
        if (isDestroyed() || isFinishing()) return;
        if (null != mResultDialog) {
            if (mResultDialog.isShow()) {
                mResultDialog.dismiss();
            }
            mResultDialog = null;
        }
    }

    /**
     * 更新设备信息
     *
     * @param device 设备对象
     */
    private void updateDeviceInfo(boolean isConnected, BluetoothDevice device) {
        mBinding.tvMainDevNameValue.setText(!isConnected ? "" : device.getName());
        mBinding.tvMainDevAddressValue.setText(!isConnected ? "" : device.getAddress());
        mBinding.tvMainDevStatusValue.setText(isConnected ? getString(R.string.bt_status_connected) : getString(R.string.bt_status_disconnected));
    }


}