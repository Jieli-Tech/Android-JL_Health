package com.jieli.watchtesttool.tool.bluetooth;

import android.bluetooth.BluetoothDevice;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.watchtesttool.data.bean.DeviceConnectionData;

/**
 * 蓝牙控制
 *
 * @author zqjasonZhong
 * @since 2021/3/8
 */
public class BluetoothViewModel extends ViewModel {
    public final BluetoothHelper mBluetoothHelper = BluetoothHelper.getInstance();
    public final MutableLiveData<DeviceConnectionData> mConnectionDataMLD = new MutableLiveData<>();

    public BluetoothViewModel(){
        mBluetoothHelper.addBluetoothEventListener(mEventListener);

        if(mBluetoothHelper.isConnectedDevice()){
            mConnectionDataMLD.setValue(new DeviceConnectionData(mBluetoothHelper.getConnectedBtDevice(), BluetoothConstant.CONNECT_STATE_CONNECTED));
        }
    }

    public void destroy(){
        mBluetoothHelper.removeBluetoothEventListener(mEventListener);
    }

    public int getDeviceConnection(BluetoothDevice device) {
        return mBluetoothHelper.getConnectionStatus(device);
    }

    public boolean isConnectedDevice(BluetoothDevice device) {
        return mBluetoothHelper.isConnectedBtDevice(device);
    }

    public boolean isUsingDevice(BluetoothDevice device) {
        return mBluetoothHelper.isUsedBtDevice(device);
    }

    public boolean isConnected() {
        return mBluetoothHelper.isConnectedDevice();
    }

    public BluetoothDevice getConnectedDevice() {
        return mBluetoothHelper.getConnectedBtDevice();
    }

    public void disconnectDevice(BluetoothDevice device) {
        mBluetoothHelper.disconnectDevice(device);
    }

    private final BluetoothEventListener mEventListener = new BluetoothEventListener() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            mConnectionDataMLD.setValue(new DeviceConnectionData(device, status));
        }
    };
}
