package com.jieli.watchtesttool;

import android.app.Application;

import com.jieli.component.ActivityManager;
import com.jieli.component.utils.ToastUtil;

import com.jieli.jl_rcsp.constant.WatchConstant;
import com.jieli.watchtesttool.tool.logcat.LogcatTask;
import com.jieli.watchtesttool.util.WLog;


/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 手表自动化测试入口
 * @since 2021/4/20
 */
public class WatchApplication extends Application {
    private static WatchApplication watchApplication;

    @Override
    public void onCreate() {
        super.onCreate();
        watchApplication = this;
//        WatchConstant.ENABLE_WRITE_DATA_CHECK = BuildConfig.DEBUG; //开启写数据校验
        ActivityManager.init(this);
        ToastUtil.init(this);
        WLog.configureLog(this, BuildConfig.DEBUG, false);
//        if (BuildConfig.DEBUG) {
        new LogcatTask(this).start();
//        }
    }

    public static WatchApplication getWatchApplication() {
        return watchApplication;
    }
}
