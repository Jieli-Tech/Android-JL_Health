package com.jieli.watchtesttool.tool.test;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc
 * @since 2021/4/25
 */
public interface OnTestLogCallback {

    void onLog(String log);
}
