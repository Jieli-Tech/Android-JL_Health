package com.jieli.watchtesttool.tool.sensor;

import android.annotation.SuppressLint;
import android.content.Context;

import androidx.room.Database;
import androidx.room.Room;
import androidx.room.RoomDatabase;

import com.jieli.jl_rcsp.util.CHexConver;
import com.jieli.watchtesttool.WatchApplication;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/7/21
 * @desc :
 */
@Database(entities = {SensorEntity.class}, version = 1)
public abstract class SensorDbBase extends RoomDatabase {
    private final static String DB_NAME = "jl_sensor.db";
    private volatile static SensorDbBase instance;

    public static SensorDbBase buildDb(Context context) {
        if (instance == null) {
            synchronized (SensorDbBase.class) {
                if (instance == null) {
                    instance = Room.databaseBuilder(context, SensorDbBase.class, DB_NAME)
                            .allowMainThreadQueries()
                            .build();
                }
            }
        }
        return instance;
    }


    public abstract SensorDao sensorDao();


    @SuppressLint("DefaultLocale")
    public static void test() {
        SensorDao sensorDao = buildDb(WatchApplication.getWatchApplication()).sensorDao();
        sensorDao.clean();
        for (int i = 0; i < 100; i++) {
            SensorEntity entity = new SensorEntity();
            entity.setMac(String.format("12:12:23:12:12:%02d", (i % 10)));
            entity.setDevName(String.format("name_%02d", (i % 10)));
            entity.setTime(System.currentTimeMillis());
            entity.setType(String.valueOf (i % 3));
            entity.setData(CHexConver.hexStr2Bytes("010203040506070809"+String.format("%02d",i%3)));
            sensorDao.insert(entity);
        }
    }


}
