package com.jieli.watchtesttool.tool.test.fragment;

import android.app.AlertDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.jieli.component.utils.ToastUtil;
import com.jieli.component.utils.ValueUtil;
import com.jieli.jl_fatfs.model.FatFile;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_rcsp.constant.JLChipFlag;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.WatchApplication;
import com.jieli.watchtesttool.tool.test.ITestTask;
import com.jieli.watchtesttool.tool.test.LogDialog;
import com.jieli.watchtesttool.tool.test.fattask.FatDeleteWatchTask;
import com.jieli.watchtesttool.tool.test.fattask.FatInsertBgTask;
import com.jieli.watchtesttool.tool.test.fattask.FatInsertWatchTask;
import com.jieli.watchtesttool.tool.watch.WatchManager;
import com.jieli.watchtesttool.util.AppUtil;
import com.jieli.watchtesttool.util.WLog;
import com.jieli.watchtesttool.util.WatchConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 6/9/21
 * @desc :
 */
public class WatchBrowFragment extends Fragment implements OnWatchOpCallback<ArrayList<FatFile>> {


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.fragment_watch_vrow, container, false);
    }


    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        WatchManager.getInstance().listWatchList(this);
    }

    @Override
    public void onSuccess(ArrayList<FatFile> fatFiles) {
        WLog.e("sen", "list watch success flash size = " + fatFiles.size());
        LinearLayout parent = requireView().findViewById(R.id.ll_watch_brow);
        parent.removeAllViews();
        parent.addView(createTestItem("添加表盘", v -> showAddDialog(false), null));
        parent.addView(createTestItem("添加表盘背景", v -> showAddDialog(true), null));
        for (FatFile f : fatFiles) {
            parent.addView(createTestItem(f.getName(), v -> selectWatch(f), v -> {
                delete(f);
                return true;
            }));
        }

    }


    @Override
    public void onFailed(BaseError baseError) {

    }


    private void showAddDialog(boolean isBg) {
        DeviceInfo deviceInfo = WatchManager.getInstance().getDeviceInfo();
        String subDir = null == deviceInfo ? WatchConstant.DIR_BR23 : deviceInfo.getSdkType() == JLChipFlag.JL_CHIP_FLAG_701X_WATCH ? WatchConstant.DIR_BR28 : WatchConstant.DIR_BR23;
        String dirPath = AppUtil.createFilePath(WatchApplication.getWatchApplication(), isBg ? WatchConstant.DIR_WATCH_BG : WatchConstant.DIR_WATCH, subDir);
        String[] files = new File(dirPath).list();
        AlertDialog alertDialog = new AlertDialog.Builder(getContext())
                .setTitle("选择")
                .setItems(files, (dialog, which) -> {
                    assert files != null;
                    String path = dirPath + File.separator + files[which];
                    ITestTask task = isBg ? new FatInsertBgTask(WatchManager.getInstance(), path) : new FatInsertWatchTask(WatchManager.getInstance(), path);
                    LogDialog logDialog = new LogDialog(v -> task.stopTest());
                    task.setOnTestLogCallback(logDialog);
                    task.setINextTask(error -> {
                        logDialog.setCancelable(true);
                        if (error.code == 0) {
                            ToastUtil.showToastShort("插入成功");
                            WatchManager.getInstance().listWatchList(WatchBrowFragment.this);
                        } else {
                            ToastUtil.showToastShort("插入失败");
                        }
                    });
                    logDialog.show(getChildFragmentManager(), dialog.getClass().getCanonicalName());
                    task.startTest();

                })
                .create();
        alertDialog.show();

    }


    protected void delete(final FatFile fatFile) {
        new AlertDialog.Builder(getContext())
                .setTitle(R.string.tips)
                .setMessage("是否要删除：" + fatFile.getName())
                .setCancelable(true)
                .setPositiveButton(R.string.confirm, (dialog, which) -> {
                    ITestTask task = new FatDeleteWatchTask(WatchManager.getInstance(), fatFile);
                    LogDialog logDialog = new LogDialog(v -> task.stopTest());
                    task.setOnTestLogCallback(logDialog);
                    task.setINextTask(error -> {
                        logDialog.setCancelable(true);
                        WLog.e("sen", "delete status-->" + error);
                        if (error.code == 0) {
                            ToastUtil.showToastShort("删除成功");
                            List<SDCardBean> list = FileBrowseManager.getInstance().getOnlineDev();
                            for (SDCardBean sdCardBean : list) {
                                if (sdCardBean.getType() == SDCardBean.FLASH) {
                                    FileBrowseManager.getInstance().cleanCache(sdCardBean);
                                }
                            }
                            WatchManager.getInstance().listWatchList(WatchBrowFragment.this);
                        } else {
                            ToastUtil.showToastShort("删除失败");
                        }

                    });
                    logDialog.show(getChildFragmentManager(), dialog.getClass().getCanonicalName());
                    task.startTest();
                })
                .setNegativeButton(R.string.cancel, (d, w) -> {

                })
                .create()
                .show();
    }

    protected void selectWatch(final FatFile fatFile) {
        WLog.i("zzc", "selectWatch-->" + fatFile.getPath());
        WatchManager.getInstance().setCurrentWatchInfo(fatFile.getPath(), new OnWatchOpCallback<FatFile>() {
            @Override
            public void onSuccess(FatFile fatFile) {
                ToastUtil.showToastShort("设置成功");
            }

            @Override
            public void onFailed(BaseError baseError) {
                ToastUtil.showToastShort("设置失败");
            }
        });
    }

    public View createTestItem(String name, View.OnClickListener listener, View.OnLongClickListener longClickListener) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
                ValueUtil.dp2px(requireContext(), 44));
        Button btn = new Button(getContext());
        if (listener != null) {
            btn.setOnClickListener(listener);
        }
        if (longClickListener != null) {
            btn.setOnLongClickListener(longClickListener);
        }
        btn.setText(name);
        btn.setLayoutParams(lp);
        return btn;
    }


}
