package com.jieli.watchtesttool.ui.upgrade;

import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Context;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.jl_bt_ota.constant.ErrorCode;
import com.jieli.jl_bt_ota.constant.StateCode;
import com.jieli.jl_bt_ota.interfaces.BtEventCallback;
import com.jieli.jl_bt_ota.interfaces.IUpgradeCallback;
import com.jieli.jl_bt_ota.model.base.BaseError;
import com.jieli.jl_bt_ota.util.FileUtil;
import com.jieli.jl_bt_ota.util.JL_Log;
import com.jieli.jl_rcsp.interfaces.watch.OnUpdateResourceCallback;
import com.jieli.watchtesttool.tool.upgrade.OTAManager;
import com.jieli.watchtesttool.tool.watch.WatchManager;
import com.jieli.watchtesttool.util.AppUtil;
import com.jieli.watchtesttool.util.WatchConstant;

import java.io.File;
import java.util.ArrayList;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc OTA逻辑实现
 * @since 2021/7/6
 */
public class UpgradeViewModel extends ViewModel {
    private final String tag = UpgradeViewModel.class.getSimpleName();
    private final WatchManager mWatchManager = WatchManager.getInstance();
    private final OTAManager mOTAManager;
    private boolean isInitOta;
    private String mUpgradeZipPath;

    @SuppressLint("StaticFieldLeak")
    private final Context mContext;

    public final MutableLiveData<OtaState> mOtaStateMLD = new MutableLiveData<>();
    public final MutableLiveData<ArrayList<File>> mOtaFileListMLD = new MutableLiveData<>();

    public UpgradeViewModel(Context context) {
        mContext = context;
        mOTAManager = new OTAManager(mContext);
        mOTAManager.registerBluetoothCallback(mBtEventCallback);
        mOtaStateMLD.setValue(new OtaState());
    }

    public boolean isConnected() {
        return mOTAManager.getConnectedDevice() != null;
    }

    public boolean isDevOta() {
        return mOTAManager.isOTA();
    }

    public String getOtaFilePath() {
        return mOTAManager.getBluetoothOption().getFirmwareFilePath();
    }

    public void release() {
        mOTAManager.unregisterBluetoothCallback(mBtEventCallback);
        mOTAManager.release();
    }

    public void readUpgradeFileList() {
        String dirPath = AppUtil.createFilePath(mContext, WatchConstant.DIR_UPDATE);
        if (FileUtil.checkFileExist(dirPath)) {
            File file = new File(dirPath);
            ArrayList<File> fileList = new ArrayList<>();
            if (file.isDirectory()) {
                File[] files = file.listFiles();
                if (files != null) {
                    for (File file1 : files) {
                        if (file1.isFile()) {
                            fileList.add(file1);
                        }
                    }
                }
            } else {
                fileList.add(file);
            }
            mOtaFileListMLD.postValue(fileList);
        } else {
            mOtaFileListMLD.postValue(new ArrayList<>());
        }
    }


    public void startOTA(String filePath) {
        if (!isInitOta) {
            postOtaFailed(new BaseError(ErrorCode.SUB_ERR_PARAMETER, "Please wait for the ota lib to initialize."));
            return;
        }
        if (isDevOta()) {
            return;
        }
        /*
         * 根据文件后缀判断升级类型
         * 若是ufw文件或者buf文件，则认为是固件升级
         * 若是zip文件,则认为资源更新
         */
        boolean isOtaDev = filePath.endsWith(".ufw") || filePath.endsWith(".buf");
        if (isOtaDev) {
            otaFirmware(filePath);
        } else if (filePath.endsWith(".zip")) {
            otaResource(filePath);
        } else {
            postOtaFailed(new BaseError(ErrorCode.SUB_ERR_PARAMETER, "Ota File is error."));
        }
    }

    /**
     * 固件升级
     *
     * @param filePath 固件升级文件路径
     */
    public void otaFirmware(String filePath) {
        mOTAManager.getBluetoothOption().setFirmwareFilePath(filePath);
        mOTAManager.startOTA(new IUpgradeCallback() {
            @Override
            public void onStartOTA() {
                JL_Log.i(tag, "-otaFirmware- onStart >>>>>> ");
                OtaState otaState = mOtaStateMLD.getValue();
                if (otaState == null) return;
                otaState.setState(OtaState.OTA_STATE_START)
                        .setOtaType(OtaState.OTA_TYPE_OTA_READY);
                mOtaStateMLD.setValue(otaState);
            }

            @Override
            public void onNeedReconnect(String s, boolean var) {
                //TODO:允许客户自定义回连方式
            }

            @Override
            public void onProgress(int i, float v) {
                JL_Log.i(tag, "-otaFirmware- onProgress >>>>>> type = " + i + ", progress = " + v);
                if (v > 0) {
                    OtaState otaState = mOtaStateMLD.getValue();
                    if (otaState == null) return;
                    otaState.setState(OtaState.OTA_STATE_WORKING)
                            .setOtaType(i == 0 ? OtaState.OTA_TYPE_OTA_READY : OtaState.OTA_TYPE_OTA_UPGRADE_FIRMWARE)
                            .setOtaProgress(v);
                    mOtaStateMLD.setValue(otaState);
                }
            }

            @Override
            public void onStopOTA() {
                JL_Log.e(tag, "-otaFirmware- :: onStopOTA");
                OtaState otaState = mOtaStateMLD.getValue();
                if (otaState == null) return;
                otaState.setState(OtaState.OTA_STATE_STOP)
                        .setStopResult(OtaState.OTA_RES_SUCCESS)
                        .setOtaProgress(0f);
                mOtaStateMLD.setValue(otaState);
                if (mUpgradeZipPath != null) {
                    FileUtil.deleteFile(new File(filePath));
                    mUpgradeZipPath = null;
                }
            }

            @Override
            public void onCancelOTA() {
                OtaState otaState = mOtaStateMLD.getValue();
                if (otaState == null) return;
                otaState.setState(OtaState.OTA_STATE_STOP)
                        .setStopResult(OtaState.OTA_RES_CANCEL)
                        .setOtaProgress(0f);
                mOtaStateMLD.setValue(otaState);
                if (mUpgradeZipPath != null) {
                    FileUtil.deleteFile(new File(filePath));
                    mUpgradeZipPath = null;
                }
            }

            @Override
            public void onError(BaseError baseError) {
                JL_Log.e(tag, "-otaFirmware- :: onError, baseError = " + baseError);
                postOtaFailed(OtaState.OTA_TYPE_OTA_UPGRADE_FIRMWARE, baseError);
                if (mUpgradeZipPath != null) {
                    mUpgradeZipPath = null;
                }
            }
        });
    }

    /**
     * 资源差分升级
     *
     * @param filePath 压缩包路径
     */
    public void otaResource(final String filePath) {
        mWatchManager.updateWatchResource(filePath, new OnUpdateResourceCallback() {
            @Override
            public void onStart(String filePath, int total) {
                JL_Log.i(tag, "-otaResource- onStart >>>>>> filePath = " + filePath + ", total = " + total);
                OtaState otaState = mOtaStateMLD.getValue();
                if (otaState == null) return;
                otaState.setState(OtaState.OTA_STATE_START)
                        .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                        .setOtaTotal(total);
                mOtaStateMLD.setValue(otaState);
            }

            @Override
            public void onProgress(int index, String filePath, float progress) {
                if (progress > 0) {
                    OtaState otaState = mOtaStateMLD.getValue();
                    if (otaState == null) return;
                    otaState.setState(OtaState.OTA_STATE_WORKING)
                            .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                            .setOtaIndex(index + 1)
                            .setOtaFileInfo(AppUtil.getFileNameByPath(filePath))
                            .setOtaProgress(progress);
                    mOtaStateMLD.setValue(otaState);
                }
            }

            @Override
            public void onStop(String otaFilePath) {
                JL_Log.i(tag, "-otaResource- onStop >>>>>> otaFilePath = " + otaFilePath);
                if (otaFilePath == null) {
                    OtaState otaState = mOtaStateMLD.getValue();
                    if (otaState == null) return;
                    otaState.setState(OtaState.OTA_STATE_STOP)
                            .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                            .setStopResult(OtaState.OTA_RES_SUCCESS);
                    mOtaStateMLD.setValue(otaState);
                } else {
                    mUpgradeZipPath = filePath;
                    otaFirmware(otaFilePath);
                }
            }

            @Override
            public void onError(int code, String message) {
                postOtaFailed(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE, new BaseError(code, message));
            }
        });
    }

    private void postOtaFailed(BaseError error) {
        postOtaFailed(OtaState.OTA_TYPE_OTA_READY, error);
    }

    private void postOtaFailed(int otaType, BaseError error) {
        OtaState otaState = mOtaStateMLD.getValue();
        if (otaState == null) return;
        otaState.setState(OtaState.OTA_STATE_STOP)
                .setOtaType(otaType)
                .setStopResult(OtaState.OTA_RES_FAILED)
                .setOtaProgress(0f)
                .setError(error);
        mOtaStateMLD.setValue(otaState);
    }

    private final BtEventCallback mBtEventCallback = new BtEventCallback() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            JL_Log.e("zzc", "-onConnection- " + device + "\tstatus = " + status);
            if (status == StateCode.CONNECTION_OK) { //OTA库准备完成
                isInitOta = true;
                //准备完毕，可以升级
                OtaState otaState = mOtaStateMLD.getValue();
                if (otaState == null || otaState.getState() == OtaState.OTA_STATE_PREPARE) return;
                otaState.setState(OtaState.OTA_STATE_PREPARE);
                mOtaStateMLD.setValue(otaState);
            } else if (status == StateCode.CONNECTION_DISCONNECT && !isDevOta()) {
                postOtaFailed(new BaseError(ErrorCode.SUB_ERR_BLE_NOT_CONNECTED, "Device disconnected."));
            }
        }
    };

    public static class UpgradeViewModelFactory implements ViewModelProvider.Factory {
        private final Context mContext;

        public UpgradeViewModelFactory(Context context) {
            mContext = context;
        }

        @NonNull
        @Override
        public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
            return (T)(new UpgradeViewModel(mContext));
        }
    }
}
