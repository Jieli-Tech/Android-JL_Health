package com.jieli.watchtesttool.tool.test;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.component.utils.ToastUtil;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.ui.base.BaseDialogFragment;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 4/29/21
 * @desc :
 */
public class LogDialog extends BaseDialogFragment implements OnTaskChangeCallback, OnTestLogCallback ,INextTask{


    private ITestTask task;
    private int taskIndex = -1;
    private int size;


    private View.OnClickListener mCancelClickListener;

    public void setSize(int size) {
        this.size = size;
    }

    public LogDialog(View.OnClickListener cancelClickListener) {
        this.mCancelClickListener = cancelClickListener;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (getDialog() == null) return;
        Window window = getDialog().getWindow();
        if (window == null) return;
        WindowManager.LayoutParams mLayoutParams = window.getAttributes();
        mLayoutParams.gravity = Gravity.CENTER;
        mLayoutParams.dimAmount = 0.5f;
        mLayoutParams.flags |= WindowManager.LayoutParams.FLAG_DIM_BEHIND;

        mLayoutParams.width = (int) (getScreenWidth() * 0.9f);
        mLayoutParams.height = (int) (getScreenWidth() * 0.6f);

        window.setBackgroundDrawable(new ColorDrawable(getResources().getColor(R.color.text_transparent)));
        window.getDecorView().getRootView().setBackgroundColor(Color.WHITE);
        window.setAttributes(mLayoutParams);


        if (task != null) {
            TextView textView = getView().findViewById(R.id.tv_log_task);
            textView.setText(task.getName()  );
            TextView posTv = getView().findViewById(R.id.tv_log_task_pos);
            posTv.setText( "(" + taskIndex + "/" + size+")");
        }


        requireView().findViewById(R.id.btn_cancel_test).setOnClickListener(mCancelClickListener);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        setCancelable(false);
        return inflater.inflate(R.layout.dialog_log, container, false);
    }

    @Override
    public void onTaskChange(ITestTask task, int index) {
        this.task = task;
        this.taskIndex = index+1;
        if (getView() == null) return;
        TextView textView = getView().findViewById(R.id.tv_log_task);
        textView.setText(task.getName()  );
        TextView posTv = getView().findViewById(R.id.tv_log_task_pos);
        posTv.setText( "(" + taskIndex + "/" + size+")");
    }

    @Override
    public void onLog(String log) {
        if (getView() == null) return;
        TextView textView = getView().findViewById(R.id.tv_log_msg);
        textView.setText(log);
    }

    @Override
    public void next(TestError error) {
        setCancelable(true);
        ToastUtil.showToastShort(error.msg);
    }
}
