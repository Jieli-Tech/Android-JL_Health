package com.jieli.watchtesttool.ui.device;

import android.bluetooth.BluetoothDevice;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.swiperefreshlayout.widget.SwipeRefreshLayout;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.ui.CommonDecoration;
import com.jieli.component.utils.ToastUtil;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.data.bean.ScanDevice;
import com.jieli.watchtesttool.databinding.FragmentAddDeviceBinding;
import com.jieli.watchtesttool.tool.permission.PermissionsHelper;
import com.jieli.watchtesttool.ui.base.BaseFragment;
import com.jieli.watchtesttool.ui.widget.dialog.WaitingDialog;

import java.util.ArrayList;

/**
 * 添加设备界面
 */
public class AddDeviceFragment extends BaseFragment {

    private AddDeviceViewModel mViewModel;
    private FragmentAddDeviceBinding mBinding;

    private ScanDeviceAdapter mScanDeviceAdapter;
    private PermissionsHelper mPermissionsHelper;

    private WaitingDialog mWaitingDialog;

    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public static AddDeviceFragment newInstance() {
        return new AddDeviceFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mBinding = FragmentAddDeviceBinding.inflate(inflater, container, false);
        mBinding.srlAddDeviceRefresh.setColorSchemeColors(getResources().getColor(android.R.color.black),
                getResources().getColor(android.R.color.darker_gray),
                getResources().getColor(android.R.color.black),
                getResources().getColor(android.R.color.background_light));
        mBinding.srlAddDeviceRefresh.setProgressBackgroundColorSchemeColor(Color.WHITE);
        mBinding.srlAddDeviceRefresh.setSize(SwipeRefreshLayout.DEFAULT);
        return mBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mBinding.viewAddDeviceTopbar.tvTopbarTitle.setText(R.string.add_device);
        mBinding.viewAddDeviceTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().finish());
        mBinding.srlAddDeviceRefresh.setOnRefreshListener(() -> {
            scanDevice(true);
            mHandler.postDelayed(() -> mBinding.srlAddDeviceRefresh.setRefreshing(false), 800);
        });
        mBinding.rvAddDeviceList.setLayoutManager(new LinearLayoutManager(requireContext()));
        mBinding.rvAddDeviceList.addItemDecoration(new CommonDecoration(requireContext(), RecyclerView.VERTICAL));
        mScanDeviceAdapter = new ScanDeviceAdapter();
        mBinding.rvAddDeviceList.setAdapter(mScanDeviceAdapter);
        mScanDeviceAdapter.setOnItemClickListener((adapter, view, position) -> {
            ScanDevice scanDevice = mScanDeviceAdapter.getItem(position);
            if (scanDevice == null) return;
            if (scanDevice.getConnectStatus() == BluetoothConstant.CONNECT_STATE_DISCONNECT) {
                mViewModel.connectDevice(scanDevice.getDevice(), scanDevice.getBleScanMessage());
            } else if (scanDevice.getConnectStatus() == BluetoothConstant.CONNECT_STATE_CONNECTED) {
                mViewModel.disconnectDevice(scanDevice.getDevice());
            }
        });

        mViewModel = new ViewModelProvider(this).get(AddDeviceViewModel.class);
        mViewModel.mBtAdapterStatusMLD.observe(getViewLifecycleOwner(), aBoolean -> {
            if (!aBoolean) {
                resetScanDeviceList();
            } else if (!mViewModel.isScanning()) {
                scanDevice(false);
            }
        });
        mViewModel.mScanStatusMLD.observe(getViewLifecycleOwner(), aBoolean -> {
            requireActivity().runOnUiThread(() -> {
                if (aBoolean) {
                    mBinding.pbAddDeviceScanStatus.setVisibility(View.VISIBLE);
                    resetScanDeviceList();
                } else {
                    mBinding.pbAddDeviceScanStatus.setVisibility(View.INVISIBLE);
                }
            });
        });
        mViewModel.mScanDeviceMLD.observe(getViewLifecycleOwner(), this::updateScanDeviceList);
        mViewModel.mConnectionDataMLD.observe(getViewLifecycleOwner(), deviceConnectionData -> {
            updateScanDevice(deviceConnectionData.getDevice(), deviceConnectionData.getStatus());
            if (deviceConnectionData.getStatus() == BluetoothConstant.CONNECT_STATE_CONNECTING) {
                showWaitingDialog();
            } else {
                dismissWaitingDialog();
                scanDevice(false);
            }
        });
    }

    @Override
    public void onResume() {
        super.onResume();
        if (!mViewModel.isScanning()) {
            scanDevice(true);
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        if (mViewModel.isScanning()) {
            mViewModel.stopScan();
        }
    }

    @Override
    public void onDestroy() {
        dismissWaitingDialog();
        super.onDestroy();
        mViewModel.destroy();
        mBinding = null;
        if (mPermissionsHelper != null) {
            mPermissionsHelper.destroy();
            mPermissionsHelper = null;
        }
        mHandler.removeCallbacksAndMessages(null);
    }

    private void scanDevice(boolean isUser) {
        if (null == mPermissionsHelper) {
            mPermissionsHelper = new PermissionsHelper((AppCompatActivity) requireActivity());
        }
        if (PermissionsHelper.checkAppPermissionsIsAllow(requireContext())) {
            if (BluetoothUtil.isBluetoothEnable()) {
                if (!TextUtils.isEmpty(mBinding.etAddDeviceFilter.getText().toString().trim())) {
                    mViewModel.changeFilter(mBinding.etAddDeviceFilter.getText().toString().trim());
                }
                mViewModel.startScan();
            } else if (isUser) {
                BluetoothUtil.enableBluetooth();
            }
        } else if (isUser) {
            mPermissionsHelper.checkAppRequestPermissions(PermissionsHelper.sPermissions, new PermissionsHelper.OnPermissionListener() {
                @Override
                public void onPermissionsSuccess(String[] permissions) {
                    scanDevice(true);
                }

                @Override
                public void onPermissionFailed(String permission) {
                    ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
                }
            });
        }
    }

    private void updateScanDeviceList(final ScanDevice scanDevice) {
        if (null == mScanDeviceAdapter || null == scanDevice || isDetached() || !isAdded()) return;
        requireActivity().runOnUiThread(() -> {
            BluetoothDevice device = scanDevice.getDevice();
            int status = mViewModel.getDeviceConnection(device);
            ScanDevice item = mScanDeviceAdapter.getItemByDevice(device);
            if (null != item) {
                item.setConnectStatus(status);
                mScanDeviceAdapter.notifyDataSetChanged();
            } else {
                scanDevice.setConnectStatus(status);
                mScanDeviceAdapter.addData(scanDevice);
            }
        });
    }

    private void resetScanDeviceList() {
        if (mScanDeviceAdapter == null || isDetached() || !isAdded()) return;
        mScanDeviceAdapter.setNewInstance(new ArrayList<>());
    }

    private void updateScanDevice(BluetoothDevice device, int status) {
        if (mScanDeviceAdapter == null) return;
        mScanDeviceAdapter.updateScanDeviceConnectStatus(device, status);
    }

    private void showWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (null == mWaitingDialog) {
            mWaitingDialog = new WaitingDialog();
        }
        if (!mWaitingDialog.isShow()) {
            mWaitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getSimpleName());
        }
    }

    private void dismissWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (null != mWaitingDialog) {
            if (mWaitingDialog.isShow()) mWaitingDialog.dismiss();
            mWaitingDialog = null;
        }
    }
}