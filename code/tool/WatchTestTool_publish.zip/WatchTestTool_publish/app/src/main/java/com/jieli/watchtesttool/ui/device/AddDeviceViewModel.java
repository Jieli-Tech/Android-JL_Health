package com.jieli.watchtesttool.ui.device;

import android.bluetooth.BluetoothDevice;

import androidx.lifecycle.MutableLiveData;

import com.jieli.bluetooth_connect.bean.ble.BleScanMessage;
import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.watchtesttool.WatchApplication;
import com.jieli.watchtesttool.data.bean.ScanDevice;
import com.jieli.watchtesttool.tool.bluetooth.BluetoothEventListener;
import com.jieli.watchtesttool.tool.bluetooth.BluetoothViewModel;
import com.jieli.watchtesttool.util.WatchConstant;

import java.util.List;

public class AddDeviceViewModel extends BluetoothViewModel {
    public final MutableLiveData<Boolean> mBtAdapterStatusMLD = new MutableLiveData<>();
    public final MutableLiveData<Boolean> mScanStatusMLD = new MutableLiveData<>();
    public final MutableLiveData<ScanDevice> mScanDeviceMLD = new MutableLiveData<>();

    private final static int SCAN_DEVICE_TIMEOUT = 30 * 1000;

    public AddDeviceViewModel() {
        super();
        mBluetoothHelper.addBluetoothEventListener(mEventListener);
    }

    public void destroy() {
        super.destroy();
        mBluetoothHelper.removeBluetoothEventListener(mEventListener);
        stopScan();
    }

    public boolean isScanning() {
        return mBluetoothHelper.getBluetoothOp().isScanning();
    }

    public void changeFilter(String filter) {
        if (null == filter) return;
        mBluetoothHelper.getBluetoothOp().getBluetoothOption().setScanFilterData(filter);
    }

    public void startScan() {
        if (WatchConstant.DEFAULT_CONNECT_WAY == BluetoothConstant.PROTOCOL_TYPE_SPP) {
            mBluetoothHelper.getBluetoothOp().startDeviceScan(SCAN_DEVICE_TIMEOUT);
        } else {
            mBluetoothHelper.getBluetoothOp().startBLEScan(SCAN_DEVICE_TIMEOUT);
        }
    }

    public void stopScan() {
        mBluetoothHelper.getBluetoothOp().stopBLEScan();
        mBluetoothHelper.getBluetoothOp().stopDeviceScan();
    }

    public void connectDevice(BluetoothDevice device, BleScanMessage bleScanMessage) {
        mBluetoothHelper.connectDevice(device, bleScanMessage);
    }

    public void disconnectDevice(BluetoothDevice device) {
        mBluetoothHelper.disconnectDevice(device);
    }

    private boolean hasScanDevice(BluetoothDevice device) {
        if (device == null) return false;
        return mBluetoothHelper.getBluetoothOp().getDiscoveredBluetoothDevices().contains(device);
    }

    private void syncSystemBtDeviceList() {
        List<BluetoothDevice> mConnectedList = BluetoothUtil.getSystemConnectedBtDeviceList(WatchApplication.getWatchApplication());
        if (null == mConnectedList || mConnectedList.isEmpty()) return;
        String filterData = mBluetoothHelper.getBluetoothOp().getBluetoothOption().getScanFilterData();
        for (BluetoothDevice sysConnectDev : mConnectedList) {
            if (!mBluetoothHelper.isConnectedBtDevice(sysConnectDev) && !hasScanDevice(sysConnectDev)
                    && (sysConnectDev.getName() != null && filterData != null && sysConnectDev.getName().startsWith(filterData))) {
                mScanDeviceMLD.setValue(new ScanDevice(sysConnectDev, null));
            }
        }
    }

    private void syncSystemBleDeviceList() {
        List<BluetoothDevice> mConnectedList = BluetoothUtil.getConnectedBleDeviceList(WatchApplication.getWatchApplication());
        if (null == mConnectedList || mConnectedList.isEmpty()) return;
        for (BluetoothDevice sysConnectDev : mConnectedList) {
            if (!mBluetoothHelper.isConnectedBtDevice(sysConnectDev) && !hasScanDevice(sysConnectDev)) {
                mScanDeviceMLD.setValue(new ScanDevice(sysConnectDev, null));
            }
        }
    }

    private final BluetoothEventListener mEventListener = new BluetoothEventListener() {
        @Override
        public void onAdapterStatus(boolean bEnabled) {
            mBtAdapterStatusMLD.postValue(bEnabled);
        }

        @Override
        public void onBtDiscoveryStatus(boolean bBle, boolean bStart) {
            mScanStatusMLD.setValue(bStart);
            if (bStart) {
                if (mBluetoothHelper.isConnectedDevice() && !hasScanDevice(mBluetoothHelper.getConnectedBtDevice())) {
                    mScanDeviceMLD.setValue(new ScanDevice(mBluetoothHelper.getConnectedBtDevice(), null));
                }
                if (WatchConstant.DEFAULT_CONNECT_WAY == BluetoothConstant.PROTOCOL_TYPE_SPP) {
                    syncSystemBtDeviceList();
                } else {
                    syncSystemBleDeviceList();
                }
            }
        }

        @Override
        public void onBtDiscovery(BluetoothDevice device, BleScanMessage bleScanMessage) {
            mScanDeviceMLD.setValue(new ScanDevice(device, bleScanMessage));
        }
    };
}