package com.jieli.watchtesttool.ui.upgrade;

import android.view.View;
import android.widget.RadioButton;

import androidx.annotation.NonNull;

import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.jieli.watchtesttool.R;

import java.io.File;

/**
 * 文件选择适配器
 *
 * @author zqjasonZhong
 * @date 2019/10/22
 */
public class FileSelectorAdapter extends BaseQuickAdapter<File, BaseViewHolder> implements View.OnClickListener {

    private int selectedIndex = -1;

    public FileSelectorAdapter() {
        super(R.layout.item_file_selector, null);
    }


    public String getSelectFilePath() {
        if (selectedIndex == -1) return null;
        File file = getItem(selectedIndex);
        if (file == null || !file.exists() || !file.isFile()) return null;
        return file.getPath();
    }

    public int getSelectedIndex() {
        return selectedIndex;
    }

    public void resetSelectedIndex() {
        selectedIndex = -1;
        notifyDataSetChanged();
    }

    @Override
    protected void convert(@NonNull BaseViewHolder helper, File item) {
        if (item != null) {
            RadioButton rBtn = helper.getView(R.id.item_file_selector_rbtn);
            rBtn.setText(item.getName());
            int position = helper.getLayoutPosition() - getHeaderLayoutCount();
            rBtn.setTag(position);
            rBtn.setOnClickListener(this);
            if (selectedIndex == -1 && position == 0) {
                rBtn.setChecked(true);
                selectedIndex = 0;
            } else if (selectedIndex != position) {
                rBtn.setChecked(false);
            } else if (!rBtn.isChecked()) {
                rBtn.setChecked(true);
            }
            /*View line = helper.getView(R.id.item_file_selector_line);
            line.setVisibility((position == getData().size() - 1) ? View.GONE : View.VISIBLE);*/
        }
    }

    @Override
    public void onClick(View v) {
        if (v != null) {
            selectedIndex = (int) v.getTag();
            notifyDataSetChanged();
        }
    }

    public void selectFile(int index) {
        if (index >= 0 && index < getData().size() && selectedIndex != index) {
            selectedIndex = index;
            notifyDataSetChanged();
        }
    }
}
