package com.jieli.watchtesttool.tool.test;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;

import com.google.gson.Gson;
import com.jieli.component.utils.ToastUtil;
import com.jieli.component.utils.ValueUtil;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.watchtesttool.R;
import com.jieli.watchtesttool.tool.test.contacts.NewContestTestTask;
import com.jieli.watchtesttool.tool.test.fattask.FatFileTestTask;
import com.jieli.watchtesttool.tool.test.filetask.FileTransferTask;
import com.jieli.watchtesttool.tool.test.fragment.WatchBrowFragment;
import com.jieli.watchtesttool.tool.watch.WatchManager;
import com.jieli.watchtesttool.ui.ContentActivity;
import com.jieli.watchtesttool.ui.base.BaseActivity;
import com.jieli.watchtesttool.ui.file.FilesFragment;
import com.jieli.watchtesttool.ui.file.SmallFileTransferCmdFragmentTest;
import com.jieli.watchtesttool.ui.upgrade.UpgradeFragment;
import com.jieli.watchtesttool.util.WLog;
import com.jieli.watchtesttool.util.WatchConstant;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public abstract class TestActivity extends BaseActivity {


    protected void initTestList(@NonNull ViewGroup viewGroup) {
        viewGroup.removeAllViews();
//        viewGroup = findViewById(R.id.ll_test);

        viewGroup.addView(createTestItem(getString(R.string.func_file_transfer), v -> showDevSelectDialog(sdCardBean ->
                showFileSelect(file ->
                        showCountSelectDialog(count -> {
                            ITestTask task = new TestTaskQueue.Factory(count, new FileTransferTask.Factory(sdCardBean, file.getPath())).create();
                            startTaskWithDialog(task, true);
                        })
                )
        )));


        viewGroup.addView(createTestItem(getString(R.string.func_music_transfer), v -> showDevSelectDialog(sdCardBean -> showCountSelectDialog(count -> {
            ITestTask task = new TestTaskQueue.Factory(count, new FileTransferTask.RandomMusicFactory(sdCardBean)).create();
            startTaskWithDialog(task, true);
        }))));

        viewGroup.addView(createTestItem(getString(R.string.func_contacts), v -> {
//            List<SDCardBean> list = new ArrayList<>();
//            for (SDCardBean sdCardBean : FileBrowseManager.getInstance().getOnlineDev()) {
//                if (sdCardBean.getType() == SDCardBean.SD || sdCardBean.getType() == SDCardBean.FLASH_2) {
//                    list.add(0, sdCardBean);//倒序添加
//                }
//            }
//            if (list.size() < 1) {
//                ToastUtil.showToastShort(getString(R.string.msg_read_file_err_offline));
//                return;
//            }
//            SDCardBean sdCardBean = list.get(0);
            showCountSelectDialog(count -> {
                ITestTask task = new TestTaskQueue.Factory(count, new NewContestTestTask.Factory(getApplicationContext())).create();
                startTaskWithDialog(task, true);
            });

        }));

        viewGroup.addView(createTestItem(getString(R.string.func_insert_watch), v -> showCountSelectDialog(count -> {
            ITestTask task = new TestTaskQueue.Factory(count, new FatFileTestTask.Factory(false)).create();
            startTaskWithDialog(task, false);
        })));

        viewGroup.addView(createTestItem(getString(R.string.func_insert_watch_bg), v -> showCountSelectDialog(count -> {
            ITestTask task = new TestTaskQueue.Factory(count, new FatFileTestTask.Factory(true)).create();
            startTaskWithDialog(task, false);
        })));

        viewGroup.addView(createTestItem(getString(R.string.func_file_browse), v -> showDevSelectDialog(sdCardBean -> {
            Bundle args = new Bundle();
            String json = new Gson().toJson(sdCardBean);
            FileBrowseManager.getInstance().cleanCache(sdCardBean);
            args.putInt(FilesFragment.KEY_SDCARDBEAD_INDEX, sdCardBean.getIndex());
            ContentActivity.startContentActivity(TestActivity.this, FilesFragment.class.getCanonicalName(), args);
        })));


        viewGroup.addView(createTestItem(getString(R.string.func_watch_browse), v -> {
            if (checkDeviceIsDisconnected()) {
                return;
            }
            ContentActivity.startContentActivity(TestActivity.this, WatchBrowFragment.class.getCanonicalName());
        }));

        if (!WatchConstant.BAN_AUTO_TEST) {
            viewGroup.addView(createTestItem(getString(R.string.func_random_test), v -> {
                List<SDCardBean> list = FileBrowseManager.getInstance().getOnlineDev();
                if (list.size() < 1) {
                    ToastUtil.showToastShort(getString(R.string.msg_read_file_err_offline));
                    return;
                }
                showCountSelectDialog(count -> {
                    ITestTask task = new RandomTaskFactory(list.get(0), count).create();
                    startTaskWithDialog(task, true);
                });
            }));
        }

        if (WatchManager.getInstance().isWatchSystemOk() && WatchManager.getInstance().getDeviceInfo().isContactsTransferBySmallFile()) {
            viewGroup.addView(createTestItem("小文件传输", v -> ContentActivity.startContentActivity(TestActivity.this, SmallFileTransferCmdFragmentTest.class.getCanonicalName())));
        }


        if (WatchConstant.TEST_OTA_FUNC) {
            viewGroup.addView(createTestItem(getString(R.string.func_upgrade), v -> {
                if (checkDeviceIsDisconnected()) {
                    return;
                }
                ContentActivity.startContentActivity(TestActivity.this, UpgradeFragment.class.getCanonicalName());
            }));
        }
    }


    private void startTaskWithDialog(ITestTask testTask, boolean needCheckCard) {

        TextView tvDelay = findViewById(R.id.et_delay);

        final LogDialog dialog = new LogDialog(v -> testTask.stopTest());

        testTask.setOnTestLogCallback(dialog);
        testTask.setINextTask(dialog);

        if (testTask instanceof TestTaskQueue) {
            TestTaskQueue queue = (TestTaskQueue) testTask;
            dialog.setSize(queue.size());
            queue.setOnTaskChangeCallback(dialog);
            if (TextUtils.isEmpty(tvDelay.getText().toString())) {
                queue.delayTask = 3000;
            } else {
                queue.delayTask = Integer.parseInt(tvDelay.getText().toString());
            }
        }
        dialog.show(getSupportFragmentManager(), dialog.getClass().getCanonicalName());
        testTask.startTest();
    }


    public View createTestItem(String name, View.OnClickListener listener) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ValueUtil.dp2px(this, 44));
        Button btn = new Button(this);
        btn.setOnClickListener(listener);
        btn.setText(name);
        btn.setLayoutParams(lp);
        return btn;
    }


    public void showDevSelectDialog(OnSelect<SDCardBean> select) {
        if (checkDeviceIsDisconnected()) {
            return;
        }
        List<SDCardBean> tmp = FileBrowseManager.getInstance().getOnlineDev();
        List<SDCardBean> list = new ArrayList<>();
        for (SDCardBean sdCardBean : tmp) {
            if (sdCardBean.getType() != SDCardBean.FLASH || true) {
                list.add(sdCardBean);
            }
        }
        if (list.size() < 1) {
            ToastUtil.showToastShort(getString(R.string.msg_read_file_err_offline));
        } else if (list.size() == 1) {
            select.onSelect(list.get(0));
        } else {
            String[] item = new String[list.size()];
            for (int i = 0; i < item.length; i++) {
                SDCardBean sdCardBean = list.get(i);
                item[i] = sdCardBean.getName();
            }

            AlertDialog.Builder builder = new AlertDialog.Builder(this);
            builder.setTitle(getString(R.string.choose_device))
                    .setItems(item, (dialog, which) -> {
                        if (select != null) {
                            select.onSelect(list.get(which));
                        }
                    });
            builder.create().show();
        }


    }


    private void showCountSelectDialog(OnSelect<Integer> timeSelect) {
        if (!checkDeviceConnectedAndStorageExist()) {
            return;
        }

        if (WatchConstant.BAN_AUTO_TEST) {
            if (timeSelect != null) timeSelect.onSelect(1);
            return;
        }
        String[] item = new String[100];
        for (int i = 0; i < item.length; i++) {
            int count = Math.max(1, i * 5);
            item[i] = count + "";
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.choose_count))
                .setItems(item, (dialog, which) -> {
//                    WLog.e(tag, "which = " + which);
                    if (timeSelect != null) {
                        timeSelect.onSelect(Integer.parseInt(item[which]));
                    }
                });

        builder.create().show();

    }


    private void showFileSelect(OnSelect<File> onSelect) {
        if (!checkDeviceConnectedAndStorageExist()) {
            return;
        }

        List<File> files = new ArrayList<>();

        File file = getApplication().getExternalFilesDir(null);
        if (file == null || file.listFiles() == null) return;
        for (File f : file.listFiles()) {
            for (File f1 : f.listFiles()) {
                if (f1.isFile()) {
                    files.add(f1);
                }
            }
        }
        String[] names = new String[files.size()];
        for (int i = 0; i < files.size(); i++) {
            names[i] = files.get(i).getName();
        }
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle(getString(R.string.choose_file))
                .setItems(names, (dialog, which) -> {
                    WLog.e(tag, "which = " + files.get(which).getName());
                    if (onSelect != null) {
                        onSelect.onSelect(files.get(which));
                    }
                });

        builder.create().show();
    }


    private boolean checkDeviceIsDisconnected() {
        if (WatchManager.getInstance().getConnectedDevice() == null) {
            ToastUtil.showToastShort(getString(R.string.device_is_disconnected));
            return true;
        }
        return false;
    }

    private boolean checkDeviceConnectedAndStorageExist() {
        if (checkDeviceIsDisconnected()) {
            return false;
        }
        if (FileBrowseManager.getInstance().getOnlineDev().size() < 1) {
            ToastUtil.showToastShort(getString(R.string.msg_read_file_err_offline));
            return false;
        }
        return true;
    }

    private interface OnSelect<T> {
        void onSelect(T t);
    }

}