package com.jieli.watchtesttool.tool.watch;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.jl_bt_ota.constant.ErrorCode;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.interfaces.OnFatFileProgressListener;
import com.jieli.jl_fatfs.model.FatFile;
import com.jieli.jl_rcsp.constant.RcspConstant;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.impl.WatchOpImpl;
import com.jieli.jl_rcsp.interfaces.listener.ThreadStateListener;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.response.ExternalFlashMsgResponse;
import com.jieli.jl_rcsp.util.CHexConver;
import com.jieli.jl_rcsp.util.JL_Log;
import com.jieli.watchtesttool.data.bean.WatchInfo;
import com.jieli.watchtesttool.tool.bluetooth.BluetoothEventListener;
import com.jieli.watchtesttool.tool.bluetooth.BluetoothHelper;
import com.jieli.watchtesttool.tool.sensor.SensorDataListener;
import com.jieli.watchtesttool.util.AppUtil;
import com.jieli.watchtesttool.util.WLog;

import java.util.ArrayList;

/**
 * 手表管理类
 *
 * @author zqjasonZhong
 * @since 2021/3/8
 */
public class WatchManager extends WatchOpImpl {
    private final static String TAG = WatchManager.class.getSimpleName();
    private volatile static WatchManager instance;

    private final BluetoothHelper mBluetoothHelper = BluetoothHelper.getInstance();

    private BluetoothDevice mTargetDevice;
    private GetWatchMsgTask mGetWatchMsgTask;

    private final ArrayList<WatchInfo> watchInfoList = new ArrayList<>();
    private ArrayList<FatFile> devFatFileList;

    private WatchManager(int func) {
        super(func);
        sUseNewDataHandler = true;
        mBluetoothHelper.addBluetoothEventListener(mEventListener);

        if (mBluetoothHelper.isConnectedDevice()) {
            setTargetDevice(mBluetoothHelper.getConnectedBtDevice());
        }
        registerOnRcspEventListener(new SensorDataListener());
    }

    public static WatchManager getInstance() {
        if (null == instance) {
            synchronized (WatchManager.class) {
                if (null == instance) {
                    instance = new WatchManager(FUNC_WATCH);
                }
            }
        }
        return instance;
    }

    public boolean isWatchSystemInit(BluetoothDevice device) {
        if (null == device) return false;
        return BluetoothUtil.deviceEquals(getConnectedDevice(), device) && isWatchSystemOk();
    }

    @Override
    public BluetoothDevice getConnectedDevice() {
//        WLog.w(TAG, "-getConnectedDevice- " + BluetoothUtil.printBtDeviceInfo(mTargetDevice));
        return mTargetDevice;
    }

    @Override
    public boolean sendDataToDevice(BluetoothDevice device, byte[] data) {
        JL_Log.d("write data to device", CHexConver.byte2HexStr(data));
        return mBluetoothHelper.sendDataToDevice(device, data);
    }

    @Override
    public void release() {
        super.release();
        if (null != mGetWatchMsgTask) {
            mGetWatchMsgTask.interrupt();
            mGetWatchMsgTask = null;
        }
        mBluetoothHelper.removeBluetoothEventListener(mEventListener);
        instance = null;
    }

    public ArrayList<WatchInfo> getWatchInfoList() {
        return watchInfoList;
    }

    public ArrayList<FatFile> getDevFatFileList() {
        return devFatFileList;
    }

    public void listWatchFileList(final OnWatchOpCallback<ArrayList<WatchInfo>> callback) {
        if (watchInfoList.isEmpty()) {
            listWatchList(new OnWatchOpCallback<ArrayList<FatFile>>() {
                @Override
                public void onSuccess(ArrayList<FatFile> result) {
                    devFatFileList = result;
                    if (devFatFileList == null) devFatFileList = new ArrayList<>();
                    ArrayList<FatFile> list = getWatchList(result);
                    if (!list.isEmpty()) {
                        if (null == mGetWatchMsgTask) {
                            mGetWatchMsgTask = new GetWatchMsgTask(WatchManager.this, list, new CustomListWatchFileListCallback(callback), new ThreadStateListener() {
                                @Override
                                public void onStart(long threadId) {

                                }

                                @Override
                                public void onFinish(long threadId) {
                                    if (mGetWatchMsgTask != null && mGetWatchMsgTask.getId() == threadId) {
                                        mGetWatchMsgTask = null;
                                    }
                                }
                            });
                            mGetWatchMsgTask.start();
                        }
                    } else {
                        watchInfoList.clear();
                        if (callback != null) callback.onSuccess(new ArrayList<>());
                    }
                }

                @Override
                public void onFailed(BaseError error) {
                    watchInfoList.clear();
                    if (callback != null) callback.onFailed(error);
                }
            });
        } else {
            if (callback != null) callback.onSuccess(watchInfoList);
        }
    }

    public void updateWatchFileListByDevice(final OnWatchOpCallback<ArrayList<WatchInfo>> callback) {
        watchInfoList.clear();
        listWatchFileList(callback);
    }

    public void getCurrentWatchMsg(final OnWatchOpCallback<WatchInfo> callback) {
        listWatchFileList(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
            @Override
            public void onSuccess(ArrayList<WatchInfo> result) {
                if (!result.isEmpty()) {
                    getCurrentWatchInfo(new OnWatchOpCallback<FatFile>() {
                        @Override
                        public void onSuccess(FatFile result) {
                            WLog.d(TAG, "-getCurrentWatchMsg- result = " + result);
                            WatchInfo info = getWatchInfoByFatFile(result);
                            if (info != null) {
                                if (callback != null) callback.onSuccess(info);
                            } else {
                                if (callback != null)
                                    callback.onFailed(new BaseError(ErrorCode.SUB_ERR_PARAMETER, "not found watch info."));
                            }
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            if (callback != null) callback.onFailed(error);
                        }
                    });
                } else {
                    if (callback != null)
                        callback.onFailed(new BaseError(ErrorCode.SUB_ERR_PARAMETER, "not found watch info."));
                }
            }

            @Override
            public void onFailed(BaseError error) {
                if (callback != null) callback.onFailed(error);
            }
        });
    }

    public void enableWatchCustomBg(final String fatFilePath, final OnWatchOpCallback<FatFile> callback) {
        enableCustomWatchBg(fatFilePath, new OnWatchOpCallback<FatFile>() {
            @Override
            public void onSuccess(FatFile result) {
                final FatFile custom = result;
                getCurrentWatchMsg(new OnWatchOpCallback<WatchInfo>() {
                    @Override
                    public void onSuccess(WatchInfo result) {
                        result.setCustomBgFatPath(fatFilePath);
                        WLog.d(TAG, "-enableWatchCustomBg- result = " + result);
                        if (callback != null) callback.onSuccess(custom);
                    }

                    @Override
                    public void onFailed(BaseError error) {
                        if (callback != null) callback.onFailed(error);
                    }
                });
            }

            @Override
            public void onFailed(BaseError error) {
                if (callback != null) callback.onFailed(error);
            }
        });
    }

    public void deleteWatch(final WatchInfo info, final OnFatFileProgressListener listener) {
        if (null == info || null == info.getFatFile()) return;
        WLog.d(TAG, "-deleteWatch- info = " + info.toString());
        if (info.hasCustomBgFatPath()) { //有自定义背景，先删除自定义背景，再删除表盘文件
            WLog.w(TAG, "-deleteWatch- CustomBgFatPath = " + info.getCustomBgFatPath());
            deleteWatchFile(info.getCustomBgFatPath(), new OnFatFileProgressListener() {
                @Override
                public void onStart(String filePath) {
                    WLog.i(TAG, "-deleteWatch- onStart = " + filePath);
                    if (listener != null) listener.onStart(info.getFatFile().getPath());
                }

                @Override
                public void onProgress(float progress) {
                    float cProgress = progress * 100 / 200f;
                    WLog.d(TAG, "-deleteWatch- onProgress = " + cProgress);
                    if (listener != null) listener.onProgress(cProgress);
                }

                @Override
                public void onStop(int result) {
                    WLog.i(TAG, "-deleteWatch- onStop = " + result);
                    if (result == FatFsErrCode.RES_OK) {
                        WLog.d(TAG, "-deleteWatch- deleteWatchFile = " + info.getFatFile().getPath());
                        deleteWatchFile(info.getFatFile().getPath(), new OnFatFileProgressListener() {
                            @Override
                            public void onStart(String filePath) {
                                WLog.i(TAG, "-deleteWatch- onStart = " + filePath);
                            }

                            @Override
                            public void onProgress(float progress) {
                                float cProgress = (progress + 100) * 100 / 200f;
                                WLog.d(TAG, "-deleteWatch- onProgress = " + cProgress);
                                if (listener != null) listener.onProgress(cProgress);
                            }

                            @Override
                            public void onStop(int result) {
                                WLog.w(TAG, "-deleteWatch- onStop = " + result);
                                final int deleteResult = result;
                                updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                                    @Override
                                    public void onSuccess(ArrayList<WatchInfo> result) {
                                        if (listener != null) listener.onStop(deleteResult);
                                    }

                                    @Override
                                    public void onFailed(BaseError error) {
                                        if (listener != null)
                                            listener.onStop(FatFsErrCode.RES_RCSP_SEND);
                                    }
                                });
                            }
                        });
                    } else {
                        if (listener != null) listener.onStop(result);
                    }
                }
            });
            return;
        }
        WLog.d(TAG, "-deleteWatch- 111 deleteWatchFile = " + info.getFatFile().getPath());
        deleteWatchFile(info.getFatFile().getPath(), new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                WLog.i(TAG, "-deleteWatch- 111 onStart = " + filePath);
                if (listener != null) listener.onStart(filePath);
            }

            @Override
            public void onProgress(float progress) {
                WLog.d(TAG, "-deleteWatch-111  onProgress = " + progress);
                if (listener != null) listener.onProgress(progress);
            }

            @Override
            public void onStop(int result) {
                WLog.w(TAG, "-deleteWatch- 111 onStop = " + result);
                if (result == FatFsErrCode.RES_OK && (info.getFatFile().getName().startsWith("WATCH") ||
                        info.getFatFile().getName().startsWith("BGP"))) {
                    updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                        @Override
                        public void onSuccess(ArrayList<WatchInfo> result) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_OK);
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_RCSP_SEND);
                        }
                    });
                } else {
                    if (listener != null) listener.onStop(result);
                }
            }
        });
    }

    public DeviceInfo getDeviceInfo(BluetoothDevice device) {
        return mStatusManager.getDeviceInfo(device);
    }

    public boolean isExistSDCard() {
        DeviceInfo deviceInfo = getDeviceInfo(getConnectedDevice());
        if (deviceInfo == null) return false;
        boolean ret = deviceInfo.isSupportSd1();
        WLog.d(RcspConstant.DEBUG_LOG_TAG, "-isExistSDCard- ret = " + ret);
        return ret;
    }

    public ExternalFlashMsgResponse getExternalFlashMsg(BluetoothDevice device) {
        return mStatusManager.getExtFlashMsg(device);
    }

    private void setTargetDevice(BluetoothDevice device) {
        if (!BluetoothUtil.deviceEquals(device, mTargetDevice)) {
            mTargetDevice = device;
            BluetoothDevice connectedDevice = getTargetDevice();
            WLog.i(RcspConstant.DEBUG_LOG_TAG, "-setTargetDevice- device = " + BluetoothUtil.printBtDeviceInfo(device)
                    + ", connectedDevice = " + BluetoothUtil.printBtDeviceInfo(connectedDevice));
            if (device != null) {
                notifyBtDeviceConnection(device, StateCode.CONNECTION_OK);
            }
        }
    }

    private void updateHistoryRecordMsg(BluetoothDevice device) {
        if (!mBluetoothHelper.isConnectedBtDevice(device)) return;
        DeviceInfo deviceInfo = mStatusManager.getDeviceInfo(device);
        if (deviceInfo == null) return;
        int connectWay = mBluetoothHelper.getBluetoothOp().isConnectedSppDevice(device) ? BluetoothConstant.PROTOCOL_TYPE_SPP : BluetoothConstant.PROTOCOL_TYPE_BLE;
        String mappedAddress;
        if (connectWay == BluetoothConstant.PROTOCOL_TYPE_SPP) {
            mappedAddress = deviceInfo.getBleAddr();
        } else {
            mappedAddress = deviceInfo.getEdrAddr();
        }
        if (BluetoothAdapter.checkBluetoothAddress(mappedAddress)) {
            mBluetoothHelper.getBluetoothOp().getHistoryRecordHelper().updateDeviceInfo(device, deviceInfo.getSdkType(), mappedAddress);
        }
        if (deviceInfo.getVid() != 0 || deviceInfo.getPid() != 0) {
            mBluetoothHelper.getBluetoothOp().getHistoryRecordHelper().updateDeviceIDs(device, deviceInfo.getVid(), deviceInfo.getVid(), deviceInfo.getPid());
        }
    }

    private ArrayList<FatFile> getWatchList(ArrayList<FatFile> list) {
        if (null == list) return new ArrayList<>();
        ArrayList<FatFile> result = new ArrayList<>();
        for (FatFile fatFile : list) {
            if (fatFile.getName().startsWith("WATCH") || fatFile.getName().startsWith("watch")) {
                result.add(fatFile);
            }
        }
        return result;
    }

    public WatchInfo getWatchInfoByFatFile(FatFile fatFile) {
        if (fatFile == null || watchInfoList.isEmpty()) return null;
        WatchInfo result = null;
        for (WatchInfo watchInfo : watchInfoList) {
            WLog.d(TAG, "-getWatchInfoByList- watchInfo = " + watchInfo + ", target = " + fatFile);
            if (fatFile.getPath() != null && fatFile.getPath().equals(watchInfo.getFatFile().getPath())) {
                result = watchInfo;
                break;
            }
        }
        return result;
    }

    public WatchInfo getWatchInfoByPath(String fatFilePath) {
        if (null == fatFilePath || null == devFatFileList || devFatFileList.isEmpty()) return null;
        FatFile fatFile = null;
        for (FatFile file : devFatFileList) {
            if (fatFilePath.toUpperCase().equals(file.getPath())) {
                fatFile = file;
                break;
            }
        }
        return getWatchInfoByFatFile(fatFile);
    }

    private final BluetoothEventListener mEventListener = new BluetoothEventListener() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            status = AppUtil.convertWatchConnectStatus(status);
            if (status == StateCode.CONNECTION_OK) {
                updateHistoryRecordMsg(device);
                if (mBluetoothHelper.isUsedBtDevice(device)) {
                    setTargetDevice(device);
                }
            } else if (BluetoothUtil.deviceEquals(mTargetDevice, device)) {
                notifyBtDeviceConnection(device, status);
                if (status == StateCode.CONNECTION_FAILED || status == StateCode.CONNECTION_DISCONNECT) {
                    setTargetDevice(null);
                }
            }
        }

        @Override
        public void onReceiveData(BluetoothDevice device, byte[] data) {
            WLog.w("zzc", "-onReceiveData- device = " + BluetoothUtil.printBtDeviceInfo(device));
            if (BluetoothUtil.deviceEquals(device, getConnectedDevice())) {
                notifyReceiveDeviceData(device, data);
            }
        }

        @Override
        public void onSwitchConnectedDevice(BluetoothDevice device) {
            if (device != null) {
                setTargetDevice(device);
            }
        }
    };

    private final class CustomListWatchFileListCallback implements OnWatchOpCallback<ArrayList<WatchInfo>> {
        private final OnWatchOpCallback<ArrayList<WatchInfo>> mCallback;

        public CustomListWatchFileListCallback(OnWatchOpCallback<ArrayList<WatchInfo>> callback) {
            mCallback = callback;
        }

        @Override
        public void onSuccess(ArrayList<WatchInfo> result) {
            watchInfoList.clear();
            watchInfoList.addAll(result);
            if (mCallback != null) mCallback.onSuccess(result);
        }

        @Override
        public void onFailed(BaseError error) {
            watchInfoList.clear();
            if (mCallback != null) mCallback.onFailed(error);
        }
    }
}
