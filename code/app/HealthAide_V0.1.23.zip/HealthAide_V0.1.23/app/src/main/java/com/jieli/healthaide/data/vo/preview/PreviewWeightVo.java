package com.jieli.healthaide.data.vo.preview;

import com.jieli.healthaide.data.vo.weight.WeightDayVo;

/**
 * @ClassName: PreviewWeightVo
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/11/9 20:45
 */
public class PreviewWeightVo extends WeightDayVo {
}
