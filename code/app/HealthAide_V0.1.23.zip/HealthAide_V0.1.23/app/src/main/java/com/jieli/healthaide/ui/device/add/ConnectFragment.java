package com.jieli.healthaide.ui.device.add;

import android.bluetooth.BluetoothDevice;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.bluetooth_connect.bean.ble.BleScanMessage;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentConnectBinding;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.util.HealthUtil;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.util.JL_Log;

import org.jetbrains.annotations.NotNull;

/**
 * 连接界面
 */
public class ConnectFragment extends BaseFragment {
    private FragmentConnectBinding mConnectBinding;
    private DeviceConnectViewModel mViewModel;

    public final static String KEY_CONNECT_DEV = "connect_dev";
    public final static String KEY_CONNECT_BLE_MSG = "connect_ble_msg";

    private final Handler mHandler = new Handler(Looper.getMainLooper());


    public ConnectFragment() {
        // Required empty public constructor
    }


    public static ConnectFragment newInstance() {
        return new ConnectFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(@NotNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mConnectBinding = FragmentConnectBinding.inflate(inflater, container, false);
        initTopBar();
        return mConnectBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        if (getArguments() == null) {
            requireActivity().finish();
            return;
        }
        BluetoothDevice device = getArguments().getParcelable(KEY_CONNECT_DEV);
        if (device == null) {
            requireActivity().finish();
            return;
        }
        BleScanMessage scanMessage = (BleScanMessage) getArguments().getSerializable(KEY_CONNECT_BLE_MSG);

        mConnectBinding.tvConnectDeviceMsg.setText(getString(R.string.cur_dev_msg, HealthUtil.getDeviceName(device)));

        mViewModel = new ViewModelProvider(this).get(DeviceConnectViewModel.class);
        mViewModel.mConnectionDataMLD.observe(getViewLifecycleOwner(), deviceConnectionData -> requireActivity().runOnUiThread(() -> updateStateUI(deviceConnectionData.getStatus())));

        mViewModel.connectDevice(device, scanMessage);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mHandler.removeCallbacksAndMessages(null);
        mViewModel.release();
        mConnectBinding = null;
    }

    private void initTopBar() {
        mConnectBinding.clConnectTopbar.tvTopbarLeft.setVisibility(View.VISIBLE);
        mConnectBinding.clConnectTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().finish());
        mConnectBinding.clConnectTopbar.tvTopbarTitle.setText(R.string.connect_device);
    }

    private void updateStateUI(int status) {
        if (isDetached() || !isAdded()) return;
        JL_Log.e(tag, "updateStateUI ==> status = " + status);
        if (status == StateCode.CONNECTION_CONNECTING) {
            mConnectBinding.tvConnectStatus.setText(R.string.dev_connecting);
            mConnectBinding.tvConnectDesc.setText(R.string.dev_connecting_desc);
            mConnectBinding.ivConnectImg.setImageResource(R.drawable.ic_device_pairing);
        } else {
            switch (status) {
                case StateCode.CONNECTION_OK:
                    mConnectBinding.tvConnectStatus.setText(R.string.dev_connect_success);
                    mConnectBinding.tvConnectDesc.setText("");
                    mConnectBinding.ivConnectImg.setImageResource(R.drawable.ic_device_connect_success);

                    mHandler.postDelayed(() -> requireActivity().finish(), 2000);
                    break;
                case StateCode.CONNECTION_DISCONNECT:
                case StateCode.CONNECTION_FAILED:
                    mConnectBinding.tvConnectStatus.setText(R.string.dev_connect_fail);
                    mConnectBinding.tvConnectDesc.setText(R.string.dev_connect_fail_desc);
                    mConnectBinding.ivConnectImg.setImageResource(R.drawable.ic_device_connect_fail);
                    break;
            }
        }
    }
}