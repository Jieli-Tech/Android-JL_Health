package com.jieli.healthaide.ui.login;

import android.os.Bundle;

import androidx.annotation.Nullable;

import com.jieli.component.utils.SystemUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.ui.base.DoubleClickBackExitActivity;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/22/21 5:13 PM
 * @desc :
 */
public class LoginActivity extends DoubleClickBackExitActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        setContentView(R.layout.activity_login);


        replaceFragment(R.id.launcher_container, LoginByPasswordFragment.class.getCanonicalName());
    }
}
