package com.jieli.healthaide.ui.device.file;

import android.bluetooth.BluetoothDevice;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.ui.device.bean.DeviceConnectionData;
import com.jieli.healthaide.ui.device.file.model.MusicPlayInfo;
import com.jieli.jl_filebrowse.FileBrowseConstant;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.FileStruct;
import com.jieli.jl_filebrowse.bean.Folder;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_filebrowse.interfaces.DeleteCallback;
import com.jieli.jl_filebrowse.interfaces.FileObserver;
import com.jieli.jl_filebrowse.interfaces.SimpleFileObserver;
import com.jieli.jl_rcsp.constant.AttrAndFunCode;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.constant.WatchConstant;
import com.jieli.jl_rcsp.interfaces.rcsp.OnRcspEventListener;
import com.jieli.jl_rcsp.interfaces.rcsp.RcspCommandCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.base.CommandBase;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.device.MusicNameInfo;
import com.jieli.jl_rcsp.model.device.MusicStatusInfo;
import com.jieli.jl_rcsp.model.device.PlayModeInfo;
import com.jieli.jl_rcsp.util.CommandBuilder;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/15/21 5:42 PM
 * @desc :
 */
public class DeviceFileViewModel extends ViewModel implements FileObserver {
    public static final String DOWNLOAD_DIR = "download";
    static final int STATE_START = 0;
    static final int STATE_END = 1;//单次读取完成
    static final int STATE_FAILED = 2;
    static final int STATE_FINISH = 3;//改目录读取完成

    private final WatchManager mWatchManager;
    MutableLiveData<DeviceConnectionData> mConnectionDataMLD = new MutableLiveData<>();
    MutableLiveData<List<SDCardBean>> SDCardsMutableLiveData = new MutableLiveData<>();
    MutableLiveData<Folder> currentFolderMutableLiveData = new MutableLiveData<>();
    MutableLiveData<List<FileStruct>> filesMutableLiveData = new MutableLiveData<>(new ArrayList<>());
    MutableLiveData<Integer> readStateMutableLiveData = new MutableLiveData<>();
    MutableLiveData<MusicPlayInfo> musicPlayInfoLiveData = new MutableLiveData<>();


    public DeviceFileViewModel() {
        mWatchManager = WatchManager.getInstance();
        FileBrowseManager.getInstance().addFileObserver(this);
        SDCardsMutableLiveData.postValue(FileBrowseManager.getInstance().getOnlineDev());
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
        mWatchManager.registerOnRcspEventListener(onRcspEventListener);
        DeviceInfo deviceInfo = mWatchManager.getDeviceInfo(mWatchManager.getConnectedDevice());
        MusicPlayInfo musicPlayInfo = new MusicPlayInfo();
        if (deviceInfo != null) {
            musicPlayInfo.setDeviceMode(deviceInfo.getCurFunction());
            musicPlayInfo.setMusicNameInfo(deviceInfo.getMusicNameInfo());
            musicPlayInfo.setMusicStatusInfo(deviceInfo.getMusicStatusInfo());
            musicPlayInfo.setPlayModeInfo(deviceInfo.getPlayModeInfo());
            //没有缓存信息则读取
            if (deviceInfo.getCurFunction() == AttrAndFunCode.SYS_INFO_FUNCTION_MUSIC && musicPlayInfo.getMusicNameInfo() == null) {
                getMusicInfo();
            }
        }
        //跳转到
        musicPlayInfoLiveData.postValue(musicPlayInfo);
    }


    //自动跳转到下载目录
    private void browToDownLoadDir(SDCardBean sdCardBean) {

        Folder current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (current == null) {
            return;
        }

        // 返回根目录
        //遍历父文件夹，直到父文件夹是选中文件夹。
        while (current.getParent() != null) {
            FileBrowseManager.getInstance().backBrowse(sdCardBean, false);
            current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        }

        List<FileStruct> childs = current.getChildFileStructs();
        FileStruct downloadDir = Util.getDownloadDir(childs);
        if (downloadDir != null) {
            append(sdCardBean, downloadDir);
        } else if (!current.isLoadFinished(false)) {
            SimpleFileObserver simpleFileObserver = new SimpleFileObserver() {
                @Override
                public void onSdCardStatusChange(List<SDCardBean> onLineCards) {
                    super.onSdCardStatusChange(onLineCards);
                    FileBrowseManager.getInstance().removeFileObserver(this);
                }

                @Override
                public void onFileReadStop(boolean isEnd) {
                    super.onFileReadStop(isEnd);
                    FileBrowseManager.getInstance().addFileObserver(DeviceFileViewModel.this);
                    FileBrowseManager.getInstance().removeFileObserver(this);
                    browToDownLoadDir(sdCardBean);
                }

                @Override
                public void onFileReadFailed(int reason) {
                    super.onFileReadFailed(reason);
                    FileBrowseManager.getInstance().addFileObserver(DeviceFileViewModel.this);
                    FileBrowseManager.getInstance().removeFileObserver(this);
                }
            };
            FileBrowseManager.getInstance().addFileObserver(simpleFileObserver);
            int ret = FileBrowseManager.getInstance().loadMore(sdCardBean);
            if (ret == FileBrowseConstant.SUCCESS) {
                FileBrowseManager.getInstance().removeFileObserver(this);
            } else {
                FileBrowseManager.getInstance().removeFileObserver(simpleFileObserver);
            }
        } else {
            readStateMutableLiveData.postValue(STATE_FINISH);
        }

    }


    public void getCurrentInfo(SDCardBean sdCardBean) {
        Folder folder = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (folder == null) return;
        if (folder.getName().equalsIgnoreCase(DOWNLOAD_DIR) && folder.getLevel() == 1) {
            currentFolderMutableLiveData.postValue(folder);
            onFileReceiver(folder.getChildFileStructs());
            if (!folder.isLoadFinished(false) && folder.getChildFileStructs().size() < 1) {
                loadMore(sdCardBean);
            } else if (folder.isLoadFinished(false)) {
                readStateMutableLiveData.postValue(STATE_FINISH);
            }
            return;
        }
        loadMore(sdCardBean);
    }


    public void append(SDCardBean sdCardBean, FileStruct fileStruct) {
        //清除download目录
        int ret = FileBrowseManager.getInstance().appenBrowse(fileStruct, sdCardBean);
        if (ret == FileBrowseConstant.ERR_READING) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
        } else if (ret == FileBrowseConstant.ERR_OFFLINE) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_offline);
        } else if (ret == FileBrowseConstant.ERR_BEYOND_MAX_DEPTH) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_beyond_max_depth);
        } else if (ret == FileBrowseConstant.SUCCESS) {
            filesMutableLiveData.setValue(new ArrayList<>());
            currentFolderMutableLiveData.setValue(FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean));
        }
    }


    public void back(SDCardBean sdCardBean, FileStruct fileStruct) {
        Folder current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (current == null) {
            return;
        }
        //当前文件返回
        if (current.getFileStruct().getCluster() == fileStruct.getCluster()) {
            return;
        }
        //遍历父文件夹，直到父文件夹是选中文件夹。
        while (current.getParent() != null && current.getParent().getFileStruct().getCluster() != fileStruct.getCluster()) {
            FileBrowseManager.getInstance().backBrowse(sdCardBean, false);
            current = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        }
        //清空文件列表
        filesMutableLiveData.setValue(new ArrayList<>());
        FileBrowseManager.getInstance().backBrowse(sdCardBean, true);
        currentFolderMutableLiveData.postValue(FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean));
    }

    public void play(SDCardBean sdCardBean, FileStruct fileStruct) {
        if (FileBrowseManager.getInstance().isReading()) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
            return;
        }
        FileBrowseManager.getInstance().playFile(fileStruct, sdCardBean);

    }

    public void delete(SDCardBean sdCardBean, FileStruct fileStruct) {
        if (FileBrowseManager.getInstance().isReading()) {
            ToastUtil.showToastShort(R.string.msg_read_file_err_reading);
            return;
        }
        List<FileStruct> list = new ArrayList<>();
        list.add(fileStruct);
        FileBrowseManager.getInstance().deleteFile(sdCardBean, list, false, new DeleteCallback() {
            @Override
            public void onSuccess(FileStruct fileStruct) {
                ToastUtil.showToastShort("删除成功");
                filesMutableLiveData.setValue(new ArrayList<>());
            }

            @Override
            public void onError(int code, FileStruct fileStruct) {
                ToastUtil.showToastShort("删除失败");
            }

            @Override
            public void onFinish() {

            }
        });

    }


    public void loadMore(SDCardBean sdCardBean) {
        Folder folder = FileBrowseManager.getInstance().getCurrentReadFile(sdCardBean);
        if (folder == null || !folder.getName().equalsIgnoreCase(DOWNLOAD_DIR) || folder.getLevel() != 1) {
            browToDownLoadDir(sdCardBean);
            return;
        }
        int ret = FileBrowseManager.getInstance().loadMore(sdCardBean);
        if (ret == FileBrowseConstant.ERR_LOAD_FINISHED) {
            if (filesMutableLiveData.getValue() != null && filesMutableLiveData.getValue().isEmpty()) {
                filesMutableLiveData.setValue(folder.getChildFileStructs());
            }
            readStateMutableLiveData.postValue(STATE_FINISH);
        } else if (ret == FileBrowseConstant.ERR_READING) {
            readStateMutableLiveData.postValue(STATE_END);
        } else if (ret != FileBrowseConstant.SUCCESS) {
            readStateMutableLiveData.postValue(STATE_FAILED);
        }
    }


    public void cleanDownloadCache(SDCardBean sdCardBean) {
        filesMutableLiveData.setValue(new ArrayList<>());
        loadMore(sdCardBean);
    }

    public void getMusicInfo() {
        mWatchManager.sendCommandAsync(CommandBuilder.buildGetMusicSysInfoCmd(), WatchConstant.DEFAULT_SEND_CMD_TIMEOUT, new RcspCommandCallback() {
            @Override
            public void onCommandResponse(BluetoothDevice device, CommandBase cmd) {

            }

            @Override
            public void onErrCode(BluetoothDevice device, BaseError error) {
                ToastUtil.showToastShort(R.string.get_music_info_failed);
            }
        });
    }

    @Override
    protected void onCleared() {
        FileBrowseManager.getInstance().removeFileObserver(this);
        mWatchManager.unregisterOnRcspEventListener(onRcspEventListener);
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        super.onCleared();
    }

    @Override
    public void onFileReceiver(List<FileStruct> fileStructs) {
        JL_Log.d("Sen", "onFileReceiver");
        filesMutableLiveData.getValue().addAll(Util.filter(fileStructs));
        filesMutableLiveData.postValue(filesMutableLiveData.getValue());
    }

    @Override
    public void onFileReadStop(boolean isEnd) {
        if (isEnd) {
            readStateMutableLiveData.postValue(STATE_FINISH);
        } else {
            readStateMutableLiveData.postValue(STATE_END);
        }
    }

    @Override
    public void onFileReadStart() {
        readStateMutableLiveData.postValue(STATE_START);
    }

    @Override
    public void onFileReadFailed(int reason) {
        readStateMutableLiveData.postValue(STATE_FAILED);

    }

    @Override
    public void onSdCardStatusChange(List<SDCardBean> onLineCards) {

    }


    @Override
    public void OnFlayCallback(boolean success) {
        getMusicInfo();
    }

    private MusicPlayInfo getMusicPlayInfo() {
        MusicPlayInfo info = musicPlayInfoLiveData.getValue();
        if (info == null) {
            info = new MusicPlayInfo();
        }
        return info;
    }

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {
        @Override
        public void onConnectStateChange(BluetoothDevice device, int status) {
            if (status != StateCode.CONNECTION_OK) {
                mConnectionDataMLD.setValue(new DeviceConnectionData(device, status));
            }
        }

        @Override
        public void onWatchSystemInit(int code) {
            if (code == 0) {
                mConnectionDataMLD.setValue(new DeviceConnectionData(mWatchManager.getConnectedDevice(), StateCode.CONNECTION_OK));
            }
        }
    };


    private final OnRcspEventListener onRcspEventListener = new OnRcspEventListener() {
        @Override
        public void onMusicNameChange(BluetoothDevice device, MusicNameInfo nameInfo) {
            MusicPlayInfo info = getMusicPlayInfo();
            info.setMusicNameInfo(nameInfo);
            musicPlayInfoLiveData.postValue(info);
        }

        @Override
        public void onPlayModeChange(BluetoothDevice device, PlayModeInfo playModeInfo) {
            MusicPlayInfo info = getMusicPlayInfo();
            info.setPlayModeInfo(playModeInfo);
            musicPlayInfoLiveData.postValue(info);
        }

        @Override
        public void onMusicStatusChange(BluetoothDevice device, MusicStatusInfo statusInfo) {
            MusicPlayInfo info = getMusicPlayInfo();
            info.setMusicStatusInfo(statusInfo);
            musicPlayInfoLiveData.postValue(info);
        }

        @Override
        public void onDeviceModeChange(BluetoothDevice device, int mode) {
            MusicPlayInfo info = getMusicPlayInfo();
            info.setDeviceMode(mode);
            musicPlayInfoLiveData.postValue(info);
        }


    };

}
