package com.jieli.healthaide.ui.login;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.ui.login.bean.SmsCounter;
import com.jieli.healthaide.ui.widget.CustomTextWatcher;
import com.jieli.healthaide.util.FormatUtil;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/9/21 4:10 PM
 * @desc :
 */
public abstract class SmsCodeFragment extends BaseFragment {

    private SmsCodeViewModel mViewModel;
    private WaitingDialog waitingDialog;
    private EditText etRegisterPhoneNumber;
    private EditText etRegisterVerificationCode;
    private TextView tvRegisterSendSms;
    private ImageView ivRegisterClearVerificationCode;

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(SmsCodeViewModel.class);
        init();

    }

    private void init() {
        if (getView() == null) return;
        View root = requireView();

        etRegisterPhoneNumber = root.findViewById(R.id.et_phone_number);
        etRegisterVerificationCode = root.findViewById(R.id.et_verification_code);
        tvRegisterSendSms = root.findViewById(R.id.tv_send_sms);
        ivRegisterClearVerificationCode = root.findViewById(R.id.iv_clear_verification_code);

        etRegisterVerificationCode.addTextChangedListener(mVerificationCodeTextWatcher);
        etRegisterPhoneNumber.addTextChangedListener(mPhoneTextWatcher);
        etRegisterPhoneNumber.setOnFocusChangeListener(mOnFocusChangeListener);
        etRegisterVerificationCode.setOnFocusChangeListener(mOnFocusChangeListener);


        tvRegisterSendSms.setOnClickListener(v -> handleSendSmsCodeClick());

        ivRegisterClearVerificationCode.setOnClickListener(v -> {
            etRegisterVerificationCode.setText("");
            etRegisterVerificationCode.setFocusable(true);
            etRegisterVerificationCode.requestFocus();
        });

        mViewModel.smsCounterMutableLiveData.observe(getViewLifecycleOwner(), new Observer<SmsCounter>() {
            @Override
            public void onChanged(SmsCounter smsCounter) {
                switch (smsCounter.getOp()) {
                    case SmsCounter.OP_IDLE:
                        tvRegisterSendSms.setText(getString(R.string.send_sms_code));
                        tvRegisterSendSms.setTextColor(getResources().getColor(R.color.main_color));
                        tvRegisterSendSms.setEnabled(true);
                        ivRegisterClearVerificationCode.setVisibility(View.INVISIBLE);
                        break;
                    case SmsCounter.OP_COUNTER:
                        tvRegisterSendSms.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                        tvRegisterSendSms.setEnabled(false);
                        ivRegisterClearVerificationCode.setVisibility(View.VISIBLE);

                        String timeFormat = Math.round(smsCounter.getTime()) + "s";
                        JL_Log.d("sms", "-onCountDown- timeFormat = " + timeFormat);
                        String text = getString(R.string.resend_sms_code, timeFormat);
                        tvRegisterSendSms.setText(text);
                        break;
                    case SmsCounter.OP_SEND_CODE:
                        if (waitingDialog == null) {
                            waitingDialog = new WaitingDialog();
                        }
                        waitingDialog.show(getChildFragmentManager(), waitingDialog.getClass().getCanonicalName());
                        break;
                    case SmsCounter.OP_SEND_CODE_FINISH:
                    case SmsCounter.OP_SEND_CODE_ERROR:
                        if (waitingDialog != null) {
                            waitingDialog.dismiss();
                        }
                        break;
                }
            }
        });
    }


    private void showEditError(EditText editText, String error) {
        if (null == editText) return;
        editText.setError(error);
    }


    private final TextWatcher mPhoneTextWatcher = new CustomTextWatcher() {


        @Override
        public void afterTextChanged(Editable s) {
            if (null == s) return;
            String text = s.toString();
            boolean ret = FormatUtil.checkPhoneNumber(text);
            if (ret || text.length() < 11) {
                showEditError(etRegisterPhoneNumber, null);
            } else {
                showEditError(etRegisterPhoneNumber, getString(R.string.phone_tips_format_err));
            }
        }
    };

    private final TextWatcher mVerificationCodeTextWatcher = new CustomTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            if (null == s) return;
            String text = s.toString();
            boolean ret = FormatUtil.checkSmsCode(text);
            if (ret || text.length() < 6) {
                showEditError(etRegisterVerificationCode, null);
            } else {
                showEditError(etRegisterVerificationCode, getString(R.string.sms_code_tips_format_err));
            }
        }
    };


    private final View.OnFocusChangeListener mOnFocusChangeListener = new View.OnFocusChangeListener() {
        @Override
        public void onFocusChange(View v, boolean hasFocus) {
            if (hasFocus) return;
            if (v == etRegisterPhoneNumber) {
                if (!FormatUtil.checkPhoneNumber(etRegisterPhoneNumber.getText().toString().trim())) {
                    showEditError(etRegisterPhoneNumber, getString(R.string.phone_tips_format_err));
                }
            } else if (v == etRegisterVerificationCode) {
                if (!FormatUtil.checkSmsCode(etRegisterVerificationCode.getText().toString().trim())) {
                    showEditError(etRegisterVerificationCode, getString(R.string.sms_code_tips_format_err));
                }
            }
        }
    };

    private void handleSendSmsCodeClick() {
        String phoneNumber = etRegisterPhoneNumber.getText().toString().trim();
        if (FormatUtil.checkPhoneNumber(phoneNumber)) {
            mViewModel.sendSmsCode(phoneNumber);
        } else {
            ToastUtil.showToastShort(R.string.phone_tips_format_err);
        }
    }

}