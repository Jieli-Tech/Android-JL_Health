package com.jieli.healthaide.ui.health.sleep.charts.day;

import com.github.mikephil.charting.data.BarLineScatterCandleBubbleData;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/3/21 4:09 PM
 * @desc :
 */
public class SleepDayData extends BarLineScatterCandleBubbleData<ISleepDayDataSet> {
}
