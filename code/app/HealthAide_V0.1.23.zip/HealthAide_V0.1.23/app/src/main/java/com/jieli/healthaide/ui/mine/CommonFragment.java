package com.jieli.healthaide.ui.mine;

import com.jieli.healthaide.ui.base.BaseFragment;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/10/21 9:13 AM
 * @desc :
 */
class CommonFragment extends BaseFragment {
}
