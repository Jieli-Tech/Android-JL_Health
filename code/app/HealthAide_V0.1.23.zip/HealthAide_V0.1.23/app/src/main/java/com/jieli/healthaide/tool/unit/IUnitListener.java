package com.jieli.healthaide.tool.unit;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 5/26/21
 * @desc :
 */
public interface IUnitListener {

    void onChange(double value, String unit);

}
