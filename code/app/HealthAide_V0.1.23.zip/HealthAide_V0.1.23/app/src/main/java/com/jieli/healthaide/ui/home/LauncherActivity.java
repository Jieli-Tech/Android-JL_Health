package com.jieli.healthaide.ui.home;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.HandlerManager;
import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.SystemUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.permission.PermissionsHelper;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.healthaide.ui.login.LoginActivity;
import com.jieli.healthaide.ui.mine.about.WebFragment;
import com.jieli.healthaide.ui.widget.UserServiceDialog;
import com.jieli.jl_rcsp.util.JL_Log;


public final class LauncherActivity extends BaseActivity implements UserServiceDialog.OnUserServiceListener {
    private final static String KEY_POLICY_AND_USER_ARGEEMENT = "KEY_POLICY_AND_USER_ARGEEMENT";

    private LauncherViewModel mViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        setContentView(R.layout.activity_launcher);

        mViewModel = new ViewModelProvider(this, new ViewModelProvider.AndroidViewModelFactory(getApplication())).get(LauncherViewModel.class);
        mViewModel.tokenStateLiveData.observe(this, effective -> {
            final Intent intent = new Intent(LauncherActivity.this, effective ? HomeActivity.class : LoginActivity.class);
            HandlerManager.getInstance().getMainHandler().postDelayed(() -> {
                startActivity(intent);
                finish();
            }, 1000);
        });
        checkAppStatus();
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        checkAppStatus();
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void checkAppStatus(){
        if (PreferencesHelper.getSharedPreferences(getApplicationContext()).getBoolean(KEY_POLICY_AND_USER_ARGEEMENT, false)) {
            onAgree(null);
        } else {
            showPolicyDialog();
        }
    }

    private void showPolicyDialog() {
        UserServiceDialog userServiceDialog = new UserServiceDialog();
        userServiceDialog.setCancelable(false);
        userServiceDialog.show(getSupportFragmentManager(), userServiceDialog.getClass().getCanonicalName());
        userServiceDialog.setOnUserServiceListener(this);
    }


    @Override
    protected void onDestroy() {
        super.onDestroy();
    }


    @Override
    public void onUserService() {
        WebFragment.start(this, getString(R.string.user_agreement), getString(R.string.user_agreement_url));
    }

    @Override
    public void onPrivacyPolicy() {
        WebFragment.start(this, getString(R.string.privacy_policy), getString(R.string.app_privacy_policy));
    }

    @Override
    public void onExit(DialogFragment dialogFragment) {
        onBackPressed();
    }

    @Override
    public void onAgree(DialogFragment dialogFragment) {
        PreferencesHelper.putBooleanValue(getApplicationContext(), KEY_POLICY_AND_USER_ARGEEMENT, true);
        PermissionsHelper permissionsHelper = new PermissionsHelper(this);
        permissionsHelper.checkAppRequestPermissions(new PermissionsHelper.OnPermissionListener() {
            @Override
            public void onPermissionsSuccess(String[] permissions) {
                mViewModel.refreshToken();
            }

            @Override
            public void onPermissionFailed(String permission) {
                JL_Log.w(tag, "-onPermissionFailed- " + permission);
                mViewModel.refreshToken();
            }
        });
    }
}