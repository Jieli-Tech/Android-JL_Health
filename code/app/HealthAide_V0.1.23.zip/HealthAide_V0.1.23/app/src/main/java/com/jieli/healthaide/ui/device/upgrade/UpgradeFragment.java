package com.jieli.healthaide.ui.device.upgrade;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.FileUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentUpgradeBinding;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.widget.ResultDialog;
import com.jieli.healthaide.ui.widget.upgrade_dialog.UpdateResourceDialog;
import com.jieli.healthaide.ui.widget.upgrade_dialog.UpgradeDescDialog;
import com.jieli.healthaide.ui.widget.upgrade_dialog.UpgradeProgressDialog;
import com.jieli.jl_dialog.Jl_Dialog;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.util.JL_Log;


public class UpgradeFragment extends BaseFragment {

    private FragmentUpgradeBinding mUpgradeBinding;
    private UpgradeViewModel mViewModel;
    private BaseActivity mActivity;

    private UpgradeDescDialog mUpgradeDescDialog;
    private UpdateResourceDialog mUpdateResourceDialog;
    private UpgradeProgressDialog mUpgradeProgressDialog;
    private ResultDialog mResultDialog;
    //    private WaitingDialog mWaitingDialog;
    private Jl_Dialog mWarningTipsDialog;

    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public final static String KEY_OTA_FLAG = "ota_flag";
    public final static String KEY_OTA_FILE_PATH = "ota_file_path";

    public final static int OTA_FLAG_NORMAL = 0;
    public final static int OTA_FLAG_FIRMWARE = 1;
    public final static int OTA_FLAG_RESOURCE = 2;

    public static UpgradeFragment newInstance() {
        return new UpgradeFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mUpgradeBinding = FragmentUpgradeBinding.inflate(inflater, container, false);
        return mUpgradeBinding.getRoot();
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (context instanceof BaseActivity) {
            mActivity = (BaseActivity) context;
        }
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (mActivity == null && requireActivity() instanceof BaseActivity) {
            mActivity = (BaseActivity) requireActivity();
        }
        mUpgradeBinding.clUpgradeTopbar.tvTopbarTitle.setText(R.string.upgrade);
        mUpgradeBinding.clUpgradeTopbar.tvTopbarLeft.setOnClickListener(v -> {
            if (mActivity != null) mActivity.onBackPressed();
        });
        mUpgradeBinding.tvUpgradeBtn.setOnClickListener(v -> {
            if (mViewModel.mOtaState.getState() != OtaState.OTA_STATE_PREPARE) {
                mViewModel.otaPrepare();
            } else {
                showUpgradeDescDialog(getString(R.string.new_ota_version, mViewModel.mOtaState.getMessage().getVersion()), mViewModel.mOtaState.getMessage().getExplain());
            }
        });

        mViewModel = new ViewModelProvider(this).get(UpgradeViewModel.class);
        mViewModel.mOtaStateMLD.observe(getViewLifecycleOwner(), otaState -> mHandler.post(() -> updateOtaState(otaState)));
        mViewModel.mOtaInitMLD.observe(getViewLifecycleOwner(), aBoolean -> {
            if (aBoolean) {
                if (getArguments() != null) {
                    mViewModel.mOtaFlag = getArguments().getInt(KEY_OTA_FLAG, OTA_FLAG_NORMAL);
                    if (mViewModel.mOtaFlag != OTA_FLAG_NORMAL) {
                        String otaFilePath = getArguments().getString(KEY_OTA_FILE_PATH, mViewModel.mOtaState.getOtaFilePath());
                        JL_Log.e(tag, "mOtaFlag : " + mViewModel.mOtaFlag + ", otaFilePath = " + otaFilePath);
                        if (!FileUtil.checkFileExist(otaFilePath)) {
                            JL_Log.w(tag, "file not exist, enter otaPrepare");
                            mViewModel.otaPrepare();
                        } else {
                            switch (mViewModel.mOtaFlag) {
                                case OTA_FLAG_FIRMWARE:
                                    mViewModel.otaFirmware(otaFilePath);
                                    break;
                                case OTA_FLAG_RESOURCE:
                                    mViewModel.otaResource(otaFilePath);
                                    break;
                            }
                        }
                    }
                }
            }
        });

        if (mActivity != null) {
            mActivity.setOnBackPressIntercept(() -> {
                if (mViewModel.mOtaFlag != OTA_FLAG_NORMAL) {
                    showExitMandatoryUpgradeDialog(mViewModel.mOtaFlag);
                    return true;
                }
                return false;
            });
        }
        DeviceInfo deviceInfo = mViewModel.getDeviceInfo();
        if (null == deviceInfo) {
            if (mActivity != null) {
                mActivity.onBackPressed();
            }
            return;
        }
        mUpgradeBinding.tvUpgradeDevVersion.setText(deviceInfo.getVersionName());

    }

    @Override
    public void onDestroy() {
        super.onDestroy();
//        dismissWaitingDialog();
        dismissResultDialog();
        dismissUpgradeDescDialog();
        dismissUpdateResourceDialog();
        dismissUpgradeProgressDialog();
        mViewModel.release();
        mUpgradeBinding = null;
    }

    @SuppressLint("UseCompatLoadingForColorStateLists")
    private void updateOtaState(OtaState otaState) {
        if (null == otaState || !isFragmentValid()) return;
//        JL_Log.i("UpgradeViewModel", "-updateOtaState- otaState >>>>>> " + otaState);
        switch (otaState.getState()) {
            case OtaState.OTA_STATE_IDLE:
                if (otaState.getStopResult() == OtaState.OTA_RES_SUCCESS) {
                    ToastUtil.showToastShort(R.string.latest_version);
                }
                mUpgradeBinding.tvUpgradeBtn.setEnabled(true);
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.check_update);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColorStateList(R.color.text_white_2_purple_selector));
                mUpgradeBinding.tvUpgradeBtn.setBackgroundResource(R.drawable.bg_purple_2_gray_selector);
                break;
            case OtaState.OTA_STATE_PREPARE:
                mUpgradeBinding.tvUpgradeBtn.setEnabled(true);
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.upgrade);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColorStateList(R.color.text_white_2_purple_selector));
                mUpgradeBinding.tvUpgradeBtn.setBackgroundResource(R.drawable.bg_purple_2_gray_selector);
                showUpgradeDescDialog(getString(R.string.new_ota_version, otaState.getMessage().getVersion()), otaState.getMessage().getExplain());
                break;
            case OtaState.OTA_STATE_DOWNLOAD:
                showUpgradeProgressDialog(getString(R.string.ota_state_ready), Math.round(otaState.getOtaProgress()));
                mUpgradeBinding.tvUpgradeBtn.setEnabled(false);
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_ready);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                mUpgradeBinding.tvUpgradeBtn.setBackgroundColor(getResources().getColor(R.color.text_transparent));
                break;
            case OtaState.OTA_STATE_UPGRADE:
                dismissUpgradeDescDialog();
                showUpgradeProgressDialog(getString(R.string.ota_state_ready), 99);
                mUpgradeBinding.tvUpgradeBtn.setEnabled(false);
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_ready);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                mUpgradeBinding.tvUpgradeBtn.setBackgroundColor(getResources().getColor(R.color.text_transparent));
                break;
            case OtaState.OTA_STATE_START:
                if (requireActivity().getWindow() != null) {
                    requireActivity().getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
//                dismissWaitingDialog();
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_check_file);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                String txt = getString(R.string.ota_state_check_file);
                if (otaState.getOtaType() == OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE) {
                    txt = getString(R.string.update_resource_tips, otaState.getOtaIndex(), otaState.getOtaTotal());
                    dismissUpgradeProgressDialog();
                    showUpdateResourceDialog(txt, otaState.getOtaFileInfo(), 0);
                } else {
                    showUpgradeProgressDialog(txt, 0);
                }
                break;
            case OtaState.OTA_STATE_WORKING:
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_updating);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                String text;
                if (otaState.getOtaType() == OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE) {
                    text = getString(R.string.update_resource_tips, otaState.getOtaIndex(), otaState.getOtaTotal());
                    showUpdateResourceDialog(text, otaState.getOtaFileInfo(), Math.round(otaState.getOtaProgress()));
                } else {
                    text = otaState.getOtaType() == OtaState.OTA_TYPE_OTA_READY ? getString(R.string.ota_state_check_file) : getString(R.string.ota_state_updating);
                    showUpgradeProgressDialog(text, Math.round(otaState.getOtaProgress()));
                }
                break;
            case OtaState.OTA_STATE_STOP:
                mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_finish);
                mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                dismissUpdateResourceDialog();
                dismissUpgradeProgressDialog();
                int resId = R.drawable.ic_fail_yellow;
                String message = getString(R.string.ota_result_failed);
                switch (otaState.getStopResult()) {
                    case OtaState.OTA_RES_SUCCESS:
                        resId = R.drawable.ic_success_green;
                        message = getString(R.string.ota_result_success);
                        break;
                    case OtaState.OTA_RES_CANCEL:
                        message = getString(R.string.ota_result_cancel);
                        break;
                    case OtaState.OTA_RES_FAILED:
                        if (otaState.getError() != null && otaState.getError().getMessage() != null) {
                            message = otaState.getError().getMessage();
                        }
                        break;
                }
                if (requireActivity().getWindow() != null) {
                    requireActivity().getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
                }
                int resultCode = otaState.getStopResult();
                int errorCode = 0;
                if(resultCode == OtaState.OTA_RES_FAILED && otaState.getError() != null){
                    errorCode = otaState.getError().getSubCode();
                }
                showResultDialog(resultCode, resId, message, errorCode);
                break;
        }
    }

    private void showUpgradeDescDialog(String title, String content) {
        if (!isFragmentValid()) return;
        if (mUpgradeDescDialog == null) {
            mUpgradeDescDialog = new UpgradeDescDialog.Builder()
                    .setTitle(title)
                    .setContent(content)
                    .setLeftText(getString(R.string.cancel))
                    .setRightText(getString(R.string.upgrade))
                    .create();
            mUpgradeDescDialog.setOnUpgradeDescListener(new UpgradeDescDialog.OnUpgradeDescListener() {
                @Override
                public void onLeftClick() {
                    dismissUpgradeDescDialog();
                }

                @Override
                public void onRightClick() {
                    dismissUpgradeDescDialog();
                    mUpgradeBinding.tvUpgradeBtn.setEnabled(false);
                    mUpgradeBinding.tvUpgradeBtn.setText(R.string.ota_state_ready);
                    mUpgradeBinding.tvUpgradeBtn.setTextColor(getResources().getColor(R.color.text_secondary_disable_color));
                    mUpgradeBinding.tvUpgradeBtn.setBackgroundColor(getResources().getColor(R.color.text_transparent));
                    mViewModel.otaPrepare();
                    showUpgradeProgressDialog(getString(R.string.ota_state_ready), 0);
//                    showWaitingDialog();
                }
            });
        } else {
            mUpgradeDescDialog.updateView(mUpgradeDescDialog.getBuilder()
                    .setTitle(title)
                    .setContent(content));
        }
        if (!mUpgradeDescDialog.isShow()) {
            mUpgradeDescDialog.show(getChildFragmentManager(), UpgradeDescDialog.class.getSimpleName());
        }
    }

    private void dismissUpgradeDescDialog() {
        if (!isFragmentValid()) return;
        if (mUpgradeDescDialog != null) {
            if (mUpgradeDescDialog.isShow()) {
                mUpgradeDescDialog.dismiss();
            }
            mUpgradeDescDialog = null;
        }
    }

    private void showUpgradeProgressDialog(String progressText, int progress) {
        if (!isFragmentValid()) return;
        if (mUpgradeProgressDialog == null) {
            mUpgradeProgressDialog = new UpgradeProgressDialog.Builder()
                    .setWidth(1f)
                    .setProgressText(progressText)
                    .setProgress(progress)
                    .setTips(getString(R.string.upgrade_warning))
                    .create();
        }
        mUpgradeProgressDialog.updateView(mUpgradeProgressDialog.getBuilder()
                .setProgressText(progressText)
                .setProgress(progress));
        dismissExitMandatoryUpgradeDialog();
        if (!mUpgradeProgressDialog.isShow()) {
            mUpgradeProgressDialog.show(getChildFragmentManager(), UpgradeProgressDialog.class.getSimpleName());
        }
    }

    private void dismissUpgradeProgressDialog() {
        if (!isFragmentValid()) return;
        if (mUpgradeProgressDialog != null) {
            if (mUpgradeProgressDialog.isShow()) {
                mUpgradeProgressDialog.dismiss();
            }
            mUpgradeProgressDialog = null;
        }
    }

    private void showResultDialog(int resultCode, int resId, String text, final int errorCode) {
        if (!isFragmentValid()) return;
        if (mResultDialog == null) {
            mResultDialog = new ResultDialog.Builder()
                    .setCancel(false)
                    .setResultCode(resultCode)
                    .setImgId(resId)
                    .setResult(text)
                    .setBtnText(getString(R.string.sure))
                    .create();
            mResultDialog.setOnResultListener(code -> {
                dismissResultDialog();
                //判断是否固件升级错误，如果是，断开设备
                if (code != OtaState.OTA_RES_SUCCESS && errorCode > 0 && mViewModel.checkNeedDisconnect(errorCode)) {
                    mViewModel.disconnectDevice(mViewModel.mTargetDevice);
                }
                requireActivity().finish();
            });
        }
        if (!mResultDialog.isShow()) {
            mResultDialog.show(getChildFragmentManager(), ResultDialog.class.getSimpleName());
        }
    }

    private void dismissResultDialog() {
        if (!isFragmentValid()) return;
        if (mResultDialog != null) {
            if (mResultDialog.isShow()) {
                mResultDialog.dismiss();
            }
            mResultDialog = null;
        }
    }

    private void showUpdateResourceDialog(String title, String name, int progress) {
        if (!isFragmentValid()) return;
        if (mUpdateResourceDialog == null) {
            mUpdateResourceDialog = new UpdateResourceDialog.Builder()
                    .setTitle(title)
                    .setName(name)
                    .setProgress(progress)
                    .create();
        } else {
            mUpdateResourceDialog.updateView(mUpdateResourceDialog.getBuilder().setTitle(title)
                    .setName(name)
                    .setProgress(progress));
        }
        dismissExitMandatoryUpgradeDialog();
        if (!mUpdateResourceDialog.isShow()) {
            mUpdateResourceDialog.show(getChildFragmentManager(), UpdateResourceDialog.class.getSimpleName());
        }
    }

    private void dismissUpdateResourceDialog() {
        if (!isFragmentValid()) return;
        if (mUpdateResourceDialog != null) {
            if (mUpdateResourceDialog.isShow()) {
                mUpdateResourceDialog.dismiss();
            }
            mUpdateResourceDialog = null;
        }
    }

    private void showExitMandatoryUpgradeDialog(int otaType) {
        if (!isFragmentValid()) return;
        String content = otaType == OTA_FLAG_FIRMWARE ? getString(R.string.firmware_mandatory_upgrade) : getString(R.string.resource_unfinished_tips);
        mWarningTipsDialog = Jl_Dialog.builder()
                .title(getString(R.string.upgrade_warning_tips))
                .content(content)
                .cancel(false)
                .left(getString(R.string.exit_and_disconnect))
                .leftColor(getResources().getColor(R.color.gray_B3B3B3))
                .leftClickListener((view, dialogFragment) -> {
                    dialogFragment.dismiss();
                    mViewModel.disconnectDevice(mViewModel.mTargetDevice);
                    mWarningTipsDialog = null;
                    requireActivity().finish();
                })
                .right(getString(R.string.continue_upgrade))
                .rightColor(getResources().getColor(R.color.red_D25454))
                .rightClickListener(((view, dialogFragment) -> {
                    dialogFragment.dismiss();
                    mWarningTipsDialog = null;
                }))
                .build();
        mWarningTipsDialog.show(getChildFragmentManager(), "tips_dialog");
    }

    private void dismissExitMandatoryUpgradeDialog() {
        if (!isFragmentValid()) return;
        if (mWarningTipsDialog != null) {
            if (mWarningTipsDialog.isShow()) {
                mWarningTipsDialog.dismiss();
            }
            mWarningTipsDialog = null;
        }
    }

    /*private void showWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (mWaitingDialog == null) {
            mWaitingDialog = new WaitingDialog();
        }
        if (!mWaitingDialog.isShow()) {
            mWaitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getSimpleName());
        }
    }

    private void dismissWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (mWaitingDialog != null) {
            if (mWaitingDialog.isShow()) {
                mWaitingDialog.dismiss();
            }
            mWaitingDialog = null;
        }
    }*/
}