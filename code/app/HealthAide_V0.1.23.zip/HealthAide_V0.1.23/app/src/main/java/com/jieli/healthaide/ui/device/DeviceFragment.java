package com.jieli.healthaide.ui.device;

import android.Manifest;
import android.annotation.SuppressLint;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import androidx.viewpager2.widget.ViewPager2;

import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.component.utils.ValueUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentDeviceBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.device.adapter.DeviceHistoryAdapter;
import com.jieli.healthaide.ui.device.adapter.WatchAdapter;
import com.jieli.healthaide.ui.device.adapter.WatchFuncAdapter;
import com.jieli.healthaide.ui.device.add.AddDeviceFragment;
import com.jieli.healthaide.ui.device.alarm.AlarmListFragment;
import com.jieli.healthaide.ui.device.bean.DeviceHistoryRecord;
import com.jieli.healthaide.ui.device.bean.FuncItem;
import com.jieli.healthaide.ui.device.bean.WatchInfo;
import com.jieli.healthaide.ui.device.bean.WatchOpData;
import com.jieli.healthaide.ui.device.contact.ContactFragment;
import com.jieli.healthaide.ui.device.file.DeviceFileContainerFragment;
import com.jieli.healthaide.ui.device.file.FilesFragment;
import com.jieli.healthaide.ui.device.health.HealthOptionFragment;
import com.jieli.healthaide.ui.device.more.MoreFragment;
import com.jieli.healthaide.ui.device.nfc.NFCActivity;
import com.jieli.healthaide.ui.device.nfc.fragment.NfcMsgFragment;
import com.jieli.healthaide.ui.device.upgrade.UpgradeFragment;
import com.jieli.healthaide.ui.dialog.RequireGPSDialog;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.healthaide.util.PermissionUtil;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_filebrowse.util.DeviceChoseUtil;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.model.device.BatteryInfo;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.response.TargetInfoResponse;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.ArrayList;
import java.util.List;

import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

/**
 * 设备管理界面
 */
@RuntimePermissions
public class DeviceFragment extends BaseFragment {
    private FragmentDeviceBinding mDeviceBinding;

    private DeviceHistoryAdapter mHistoryAdapter;
    private WatchAdapter mWatchAdapter;
    private WatchFuncAdapter mWatchFuncAdapter;

    private WatchViewModel mWatchViewModel;

    private WaitingDialog mWaitingDialog;


    private final static int REQUEST_CODE_WATCH_MARKET = 1234;

    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public DeviceFragment() {
        // Required empty public constructor
    }

    public static DeviceFragment newInstance() {
        return new DeviceFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mDeviceBinding = FragmentDeviceBinding.inflate(inflater, container, false);
        return mDeviceBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        initView();

        mWatchViewModel = new ViewModelProvider(this).get(WatchViewModel.class);
        mWatchViewModel.mConnectionDataMLD.observe(getViewLifecycleOwner(), deviceConnectionData -> {
            JL_Log.i(tag, "-observe- deviceConnectionData = " + deviceConnectionData);
            updateHistoryDeviceMsg(deviceConnectionData.getDevice(), deviceConnectionData.getStatus());
            if (deviceConnectionData.getStatus() != BluetoothConstant.CONNECT_STATE_CONNECTED) {
                updateWatchUI(false, null);
            }
            if (deviceConnectionData.getStatus() == BluetoothConstant.CONNECT_STATE_CONNECTING) {
                showWaitingDialog();
            } else {
                dismissWaitingDialog();
            }
        });
        mWatchViewModel.mWatchStatusMLD.observe(getViewLifecycleOwner(), watchStatus -> {
            boolean isShowWatchList = false;
            if (mWatchViewModel.isUsingDevice(watchStatus.getDevice())) {
                if (watchStatus.getException() != 0) {
                    String text = "手表系统初始化异常：" + watchStatus.getException();
                    ToastUtil.showToastShort(text);
                    JL_Log.e(tag, text);
                } else { //手表系统初始化正常
                    isShowWatchList = true;
                }
            } else {
                JL_Log.w(tag, "当前设备与表盘系统不一致， device : " + BluetoothUtil.printBtDeviceInfo(watchStatus.getDevice()) + ", connectDevice = " + BluetoothUtil.printBtDeviceInfo(mWatchViewModel.getConnectedDevice()));
            }
            if (isShowWatchList) {
                JL_Log.i(tag, "init watch system ok....");
                updateWatchUI(true, watchStatus.getDevice());
            }
        });
        mWatchViewModel.mWatchListMLD.observe(getViewLifecycleOwner(), this::updateWatchList);
        mWatchViewModel.mWatchOpDataMLD.observe(getViewLifecycleOwner(), this::updateWatchOpUI);
        mWatchViewModel.mDevPowerMsgMLD.observe(getViewLifecycleOwner(), devPowerMsg -> updateHistoryBattery(devPowerMsg.getDevice(), devPowerMsg.getBattery()));
        mWatchViewModel.mHistoryRecordListMLD.observe(getViewLifecycleOwner(), deviceHistoryRecords -> requireActivity().runOnUiThread(() -> {
            if (!isFragmentValid() || mHistoryAdapter == null) return;
            mHistoryAdapter.setList(deviceHistoryRecords.getList());
            mDeviceBinding.rvDeviceList.setCurrentItem(deviceHistoryRecords.getUsingIndex());
            updateDeviceScrollUI(deviceHistoryRecords.getList().size(), deviceHistoryRecords.getUsingIndex());
        }));
        mWatchViewModel.mHistoryRecordChangeMLD.observe(getViewLifecycleOwner(), integer -> mWatchViewModel.syncHistoryRecordList());
        mWatchViewModel.mHistoryConnectStatusMLD.observe(getViewLifecycleOwner(), historyConnectStatus -> {
            if (historyConnectStatus.getConnectStatus() == StateCode.CONNECTION_CONNECTING) {
                showWaitingDialog();
            } else {
                dismissWaitingDialog();
                if (historyConnectStatus.getConnectStatus() == StateCode.CONNECTION_OK) {
                    ToastUtil.showToastShort(R.string.history_connect_ok);
                } else {
                    ToastUtil.showToastShort(R.string.history_connect_failed);
                    mWatchViewModel.syncHistoryRecordList();
                }
            }
        });

        if (mWatchViewModel.isConnected() && mWatchViewModel.isWatchSystemInit(mWatchViewModel.getConnectedDevice())) {
            mWatchViewModel.listWatchList();
            updateWatchFuncList(mWatchViewModel.getDeviceInfo(mWatchViewModel.getConnectedDevice()));
        }
        mWatchViewModel.syncHistoryRecordList();
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        DeviceFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODE_WATCH_MARKET) {
            mWatchViewModel.listWatchList();
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mWatchViewModel.release();
        mDeviceBinding = null;
        mHistoryAdapter = null;
    }

    @SuppressLint("ClickableViewAccessibility")
    private void initView() {
        //init history list
        mHistoryAdapter = new DeviceHistoryAdapter();
        View emptyView = LayoutInflater.from(requireActivity()).inflate(R.layout.view_none_device, null);
        TextView tvAddDevice = emptyView.findViewById(R.id.tv_none_device_add_device);
        tvAddDevice.setOnClickListener(v -> ContentActivity.startContentActivity(requireActivity(), AddDeviceFragment.class.getCanonicalName()));
        mHistoryAdapter.setEmptyView(emptyView);
        mHistoryAdapter.setOnItemClickListener((adapter, view, position) -> {
            DeviceHistoryRecord historyRecord = mHistoryAdapter.getItem(position);
            if (null == historyRecord) return;
            if (historyRecord.getStatus() != BluetoothConstant.CONNECT_STATE_CONNECTING) { //设备未连接 或者 设备已连接
                Bundle bundle = new Bundle();
                bundle.putParcelable(HistoryRecordFragment.KEY_HISTORY_RECORD, historyRecord);
                ContentActivity.startContentActivity(requireContext(), HistoryRecordFragment.class.getCanonicalName(), bundle);
            }
        });
        mHistoryAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            DeviceHistoryRecord historyRecord = mHistoryAdapter.getItem(position);
            if (null == historyRecord) return;
            if (historyRecord.getStatus() == BluetoothConstant.CONNECT_STATE_DISCONNECT) { //回连设备
                DeviceFragmentPermissionsDispatcher.reconnectHistoryWithPermissionCheck(this, historyRecord);
//                reconnectHistory(historyRecord);
            }
        });
        mHistoryAdapter.registerAdapterDataObserver(new RecyclerView.AdapterDataObserver() {
            @Override
            public void onChanged() {
                super.onChanged();
                List<DeviceHistoryRecord> data = mHistoryAdapter.getData();
                if (data.isEmpty()) {
                    int padding16dp = ValueUtil.dp2px(requireContext(), 16);
                    updateDevicesListViewPager2Margin(padding16dp, padding16dp);
                } else if (data.size() == 1) {
                    int padding8dp = ValueUtil.dp2px(requireContext(), 8);
                    updateDevicesListViewPager2Margin(padding8dp, padding8dp);
                } else {
                    if (mDeviceBinding.rvDeviceList.getCurrentItem() == 0) {
                        int padding8dp = ValueUtil.dp2px(requireContext(), 8);
                        int padding26dp = ValueUtil.dp2px(requireContext(), 26);
                        updateDevicesListViewPager2Margin(padding8dp, padding26dp);
                    }
                }
            }
        });
        mDeviceBinding.rvDeviceList.setOffscreenPageLimit(3);
        mDeviceBinding.rvDeviceList.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageSelected(int position) {
                super.onPageSelected(position);
                updateDeviceScrollUI(mHistoryAdapter.getData().size(), position);
                lastOffset = 0;
                lastPosition = 0;
            }

            float lastOffset = 0;
            float lastPosition = 0;

            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                if (lastPosition != position) {
                    lastOffset = 0;
                    lastPosition = position;
                }
                if (Math.abs(lastOffset - positionOffset) < 0.1f) {
                    return;
                }
                lastOffset = positionOffset;
                boolean isScrollToFirst = false;
                boolean isScrollToLast = false;
                int finallyPosition = mHistoryAdapter.getData().size() - 1;
                if (position == 0 && positionOffset < 0.45f) {
                    isScrollToFirst = true;
                } else if (position == finallyPosition || (position == finallyPosition - 1 && (positionOffset > 0.55f))) {
                    isScrollToLast = true;
                }
                if (isScrollToFirst) {
                    updateViewPager2(0);
                } else if (isScrollToLast) {
                    updateViewPager2(finallyPosition);
                } else {
                    updateViewPager2(1);
                }
            }
        });
        mDeviceBinding.rvDeviceList.setAdapter(mHistoryAdapter);

        //init local watch
        mDeviceBinding.tvDeviceWatchMarketAll.setOnClickListener(v -> ContentActivity.startContentActivityForResult(this, WatchMarketFragment.class.getCanonicalName(), null, REQUEST_CODE_WATCH_MARKET));
        mDeviceBinding.rvDeviceWatchList.setLayoutManager(new LinearLayoutManager(requireActivity(), RecyclerView.HORIZONTAL, false));
        mWatchAdapter = new WatchAdapter();
        mWatchAdapter.setBanUpdate(true);
        mWatchAdapter.setOnItemLongClickListener((adapter, view, position) -> {
            mWatchAdapter.setEditMode(!mWatchAdapter.isEditMode());
            return true;
        });
        mWatchAdapter.setOnItemChildClickListener((adapter, view, position) -> {
            WatchInfo item = mWatchAdapter.getItem(position);
            if (null == item || null == item.getWatchFile()) return;
            if (view.getId() == R.id.tv_item_watch_btn) {
                if (item.getStatus() == WatchInfo.WATCH_STATUS_EXIST) {
                    mWatchViewModel.enableCurrentWatch(item.getWatchFile().getPath());
                }
            } else if (view.getId() == R.id.iv_item_watch_delete) {
                if (mWatchAdapter.getData().size() > 2) {
                    mWatchViewModel.deleteWatch(item);
                } else {
                    ToastUtil.showToastShort(R.string.delete_watch_tip);
                }
            } else if (view.getId() == R.id.tv_item_watch_edit) {
                Bundle bundle = new Bundle();
                bundle.putParcelable(CustomWatchBgFragment.KEY_CURRENT_WATCH_INFO, item);
                ContentActivity.startContentActivity(requireContext(), CustomWatchBgFragment.class.getCanonicalName(), bundle);
            }
        });
        mWatchAdapter.setOnItemClickListener((adapter, view, position) -> {
            if (mWatchAdapter != null && mWatchAdapter.isEditMode()) {
                mWatchAdapter.setEditMode(false);
            }
        });
        mDeviceBinding.rvDeviceWatchList.setAdapter(mWatchAdapter);
        mDeviceBinding.clDeviceWatchMarket.setOnTouchListener((v, event) -> {
            if (event.getAction() == MotionEvent.ACTION_DOWN) {
                if (mWatchAdapter != null && mWatchAdapter.isEditMode()) {
                    mWatchAdapter.setEditMode(false);
                }
            }
            return false;
        });

        //init func list
        mDeviceBinding.rvDeviceFuncList.setLayoutManager(new LinearLayoutManager(requireActivity()));
        mWatchFuncAdapter = new WatchFuncAdapter();
        mWatchFuncAdapter.setOnItemClickListener((adapter, view, position) -> {
            FuncItem funcItem = mWatchFuncAdapter.getItem(position);
            if (null == funcItem) return;
            switch (funcItem.getFunc()) {
                case FuncItem.FUNC_HEALTH:
                    ContentActivity.startContentActivity(requireContext(), HealthOptionFragment.class.getCanonicalName());
                    break;
                case FuncItem.FUNC_MUSIC:
                    ContentActivity.startContentActivity(requireContext(), FilesFragment.class.getCanonicalName());
                    break;
                case FuncItem.FUNC_ALARM:
                    ContentActivity.startContentActivity(requireContext(), AlarmListFragment.class.getCanonicalName());
                    break;
                case FuncItem.FUNC_CONTACTS:
                    ContentActivity.startContentActivity(requireContext(), ContactFragment.class.getCanonicalName());
                    break;
                case FuncItem.FUNC_FILE:
                    Bundle args = new Bundle();
                    args.putInt(DeviceFileContainerFragment.KEY_TYPE, SDCardBean.SD);
                    ContentActivity.startContentActivity(requireContext(), DeviceFileContainerFragment.class.getCanonicalName(), args);
                    break;
                case FuncItem.FUNC_OTA:
                    ContentActivity.startContentActivity(requireContext(), UpgradeFragment.class.getCanonicalName());
                    break;
                case FuncItem.FUNC_NFC:
                    if (HealthConstant.TEST_DEVICE_FUNCTION) {
                        ContentActivity.startContentActivity(requireContext(), NfcMsgFragment.class.getCanonicalName());
                    } else {
                        startActivity(new Intent(getContext(), NFCActivity.class));
                    }
                    break;
                case FuncItem.FUNC_MORE:
                    ContentActivity.startContentActivity(requireContext(), MoreFragment.class.getCanonicalName());
                    break;
            }
        });
        mDeviceBinding.rvDeviceFuncList.setAdapter(mWatchFuncAdapter);
    }

    private void updateViewPager2(int position) {
        List<DeviceHistoryRecord> data = mHistoryAdapter.getData();
        if (data.isEmpty()) return;
        int padding8dp = ValueUtil.dp2px(requireContext(), 8);
        int padding26dp = ValueUtil.dp2px(requireContext(), 26);
        if (position < 1) {
            if (data.size() == 1) {
                updateDevicesListViewPager2Margin(padding8dp, padding8dp);
            } else {
                updateDevicesListViewPager2Margin(padding8dp, padding26dp);
            }
        } else if (position >= mHistoryAdapter.getData().size() - 1) {
            updateDevicesListViewPager2Margin(padding26dp, padding8dp);
        } else {
            updateDevicesListViewPager2Margin(padding26dp, padding26dp);
        }
    }

    private void updateDevicesListViewPager2Margin(int marginStart, int marginEnd) {
        ViewGroup.MarginLayoutParams layoutParams = (ViewGroup.MarginLayoutParams) mDeviceBinding.rvDeviceList.getLayoutParams();
        layoutParams.setMarginStart(marginStart);
        layoutParams.setMarginEnd(marginEnd);
        mDeviceBinding.rvDeviceList.setLayoutParams(layoutParams);
    }

    @SuppressLint("NotifyDataSetChanged")
    private void updateHistoryDeviceMsg(BluetoothDevice device, int status) {
        if (mHistoryAdapter == null || isDetached() || !isAdded()) return;
        if (status == BluetoothConstant.CONNECT_STATE_CONNECTED) {
            //历史适配器为空 或者 检测连接设备的历史记录是否发生变化
            if (mHistoryAdapter.getData().isEmpty() || mHistoryAdapter.checkHistoryDataIsChange(device,
                    mWatchViewModel.getConnectedDeviceConnectWay(device))) {
                mWatchViewModel.syncHistoryRecordList();
                return;
            }
        }
        DeviceHistoryRecord historyRecord = mHistoryAdapter.getItemByDevice(device);
        if (historyRecord == null) return;
        historyRecord.setStatus(status);
        if (status == BluetoothConstant.CONNECT_STATE_CONNECTED) {
            historyRecord.setConnectedDev(device);
            TargetInfoResponse deviceInfo = mWatchViewModel.getDeviceInfo(device);
            if (deviceInfo != null) {
                int battery = deviceInfo.getQuantity();
                historyRecord.setBattery(battery);
            }
            mHistoryAdapter.getData().remove(historyRecord);
            mHistoryAdapter.getData().add(0, historyRecord);
            mDeviceBinding.rvDeviceList.setCurrentItem(0);
        }
        mHistoryAdapter.notifyDataSetChanged();
    }

    private void updateDeviceScrollUI(int dataSize, int pos) {
        if (isDetached() || !isAdded()) return;
        JL_Log.d(tag, "-updateDeviceScrollUI- dataSize = " + dataSize + ", pos = " + pos);
       /* if (dataSize <= 1) {
            mDeviceBinding.ivDeviceHead.setVisibility(View.GONE);
            mDeviceBinding.ivDeviceEnd.setVisibility(View.GONE);
        } else {
            mDeviceBinding.ivDeviceHead.setVisibility(pos == 0 ? View.GONE : View.VISIBLE);
            mDeviceBinding.ivDeviceEnd.setVisibility(pos == dataSize - 1 ? View.GONE : View.VISIBLE);
        }*/

        if (pos < dataSize) {
            DeviceHistoryRecord record = mHistoryAdapter.getItem(pos);
            updateWatchUI(record.getStatus() == BluetoothConstant.CONNECT_STATE_CONNECTED, record.getConnectedDev());
        }
    }

    private void updateWatchList(ArrayList<WatchInfo> watchList) {
        if (mWatchAdapter == null || isDetached() || !isAdded()) return;
        if (!mWatchViewModel.isConnected()) watchList = new ArrayList<>();
        mDeviceBinding.clDeviceWatchMarket.setVisibility(watchList != null && !watchList.isEmpty() ? View.VISIBLE : View.GONE);
        if (watchList == null) return;
        mWatchAdapter.setList(watchList);
    }

    private void updateWatchFuncList(DeviceInfo deviceInfo) {
        if (mWatchFuncAdapter == null || isDetached() || !isAdded()) return;
        mDeviceBinding.clDeviceFunc.setVisibility(deviceInfo != null ? View.VISIBLE : View.GONE);
        if (deviceInfo == null) return;
        boolean isSupportRTC = deviceInfo.isRTCEnable() || HealthConstant.TEST_DEVICE_FUNCTION;
        List<FuncItem> list = new ArrayList<>();
        FuncItem item;
        item = new FuncItem(FuncItem.FUNC_HEALTH);
        item.setName(getString(R.string.health_record));
        item.setResId(R.drawable.ic_health_green);
        list.add(item);


        if (DeviceChoseUtil.getTargetDev() != null) {
            item = new FuncItem(FuncItem.FUNC_MUSIC);
            item.setName(getString(R.string.music_manager));
            item.setResId(R.drawable.ic_music_orange);
            list.add(item);
        }

        if (isSupportRTC) {
            item = new FuncItem(FuncItem.FUNC_ALARM);
            item.setName(getString(R.string.alarm));
            item.setResId(R.drawable.ic_alarm_purple);
            list.add(item);
        }
        //当flash2存在的是否也支持联系人传输
        if (DeviceChoseUtil.getTargetDevFlash2First() != null || deviceInfo.isContactsTransferBySmallFile()) {
            item = new FuncItem(FuncItem.FUNC_CONTACTS);
            item.setName(getString(R.string.contacts));
            item.setResId(R.drawable.ic_contacts_orange);
            list.add(item);
        }

        if (HealthConstant.TEST_NFC_FUNCTION) {
            item = new FuncItem(FuncItem.FUNC_NFC);
            item.setName(getString(R.string.card_bag));
            item.setResId(R.drawable.ic_card_bag_purple);
            list.add(item);
        }

        item = new FuncItem(FuncItem.FUNC_OTA);
        item.setName(getString(R.string.firmware_upgrade));
        item.setResId(R.drawable.ic_firmware_upgrade_blue);
        list.add(item);

        item = new FuncItem(FuncItem.FUNC_MORE);
        item.setName(getString(R.string.more));
        item.setResId(R.drawable.ic_more_green);
        list.add(item);


        mWatchFuncAdapter.setList(list);
    }

    private void updateWatchOpUI(final WatchOpData data) {
        mHandler.post(() -> {
            if (data.getOp() != WatchOpData.OP_DELETE_FILE) return;
            switch (data.getState()) {
                case WatchOpData.STATE_START:
                    showWaitingDialog();
                    break;
                case WatchOpData.STATE_PROGRESS:
                    break;
                case WatchOpData.STATE_END:
                    JL_Log.e(tag, "watchOpData >>> " + data);
                    dismissWaitingDialog();
                    if (data.getResult() == FatFsErrCode.RES_OK) {
                        mWatchViewModel.listWatchList();
                    }
                    break;
            }
        });
    }

    @SuppressLint("NotifyDataSetChanged")
    private void updateHistoryBattery(BluetoothDevice device, BatteryInfo batteryInfo) {
        if (isDetached() || !isAdded() || mHistoryAdapter == null || device == null || batteryInfo == null)
            return;
        DeviceHistoryRecord record = mHistoryAdapter.getItemByDevice(device);
        if (record == null) return;
        record.setBattery(batteryInfo.getBattery());
        mHistoryAdapter.notifyDataSetChanged();
    }

    private void showWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (mWaitingDialog == null) {
            mWaitingDialog = new WaitingDialog(true);
        }
        if (!mWaitingDialog.isShow()) {
            mWaitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getSimpleName());
        }
    }

    private void dismissWaitingDialog() {
        if (isDetached() || !isAdded()) return;
        if (mWaitingDialog != null) {
            if (mWaitingDialog.isShow()) {
                mWaitingDialog.dismiss();
            }
            mWaitingDialog = null;
        }
    }

    public void updateWatchUI(boolean isConnected, BluetoothDevice device) {
        if (isConnected && mWatchViewModel.isWatchSystemInit(device)) {
            mWatchViewModel.listWatchList();
            updateWatchFuncList(mWatchViewModel.getDeviceInfo(device));
        } else {
            updateWatchList(null);
            updateWatchFuncList(null);
        }
    }

    @NeedsPermission({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void reconnectHistory(DeviceHistoryRecord record) {
        if (!PermissionUtil.checkGpsProviderEnable(getContext())) {
            showOpenGPSDialog();
        } else {
            if (BluetoothUtil.isBluetoothEnable()) {
                record.setStatus(BluetoothConstant.CONNECT_STATE_CONNECTING);
                mHistoryAdapter.notifyDataSetChanged();
                mWatchViewModel.reconnectHistory(record);
            } else {
                BluetoothUtil.enableBluetooth();
            }
        }
    }

    @OnShowRationale({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void showRelationForLocationPermission(PermissionRequest request) {
        showRequireGPSPermissionDialog(request);
    }

    @OnPermissionDenied({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void onLocationDenied() {
        ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
    }

    @OnNeverAskAgain({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void onLocationNeverAskAgain() {
        ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
    }

    private void showOpenGPSDialog() {
        showGPSDialog(null, true);
    }

    private void showRequireGPSPermissionDialog(PermissionRequest request) {
        showGPSDialog(request, false);
    }

    private void showGPSDialog(PermissionRequest request, boolean isLocationService) {
        RequireGPSDialog requireGPSDialog = new RequireGPSDialog(RequireGPSDialog.VIEW_TYPE_DEVICE, request);
        requireGPSDialog.setLocationService(isLocationService);
        requireGPSDialog.setCancelable(true);
        requireGPSDialog.show(getChildFragmentManager(), RequireGPSDialog.class.getCanonicalName());
    }
}