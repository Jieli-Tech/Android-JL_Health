package com.jieli.healthaide.ui.base;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentTransaction;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.healthaide.tool.net.NetworkStateHelper;

/**
 * Des:
 * Author: Bob
 * Date:21-3-2
 * UpdateRemark:
 */
public abstract class BaseActivity extends AppCompatActivity {
    protected final String tag = getClass().getSimpleName();
    protected NetWorkViewModel mNetWorkViewModel;
    private OnBackPressIntercept mOnBackPressIntercept;

    public void setOnBackPressIntercept(OnBackPressIntercept onBackPressIntercept) {
        this.mOnBackPressIntercept = onBackPressIntercept;
    }

    public void replaceFragment(int containerId, String fragmentName) {
        replaceFragment(containerId, fragmentName, null);
    }

    public void replaceFragment(int containerId, String fragmentName, Bundle bundle) {
        Fragment fragment = getSupportFragmentManager().findFragmentByTag(fragmentName);
        if (fragment == null && fragmentName != null) {
            try {
                fragment = (Fragment) Class.forName(fragmentName).newInstance();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        if (fragment != null) {
            fragment.setArguments(getIntent().getExtras());
            FragmentTransaction fragmentTransaction = getSupportFragmentManager().beginTransaction();

            for (Fragment f : getSupportFragmentManager().getFragments()) {
                fragmentTransaction.hide(f);
            }

            if (!fragment.isAdded()) {
                fragmentTransaction.add(containerId, fragment, fragmentName);
            }
            if (null != bundle) {
                fragment.setArguments(bundle);
            }

            fragmentTransaction.show(fragment);
            fragmentTransaction.commitAllowingStateLoss();
        }
    }

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        addNetWorkObserver();
    }


    private void addNetWorkObserver() {
        if (this instanceof NetworkStateHelper.Listener) {
            mNetWorkViewModel = new ViewModelProvider(this).get(NetWorkViewModel.class);
            mNetWorkViewModel.netWorkLiveData.observe(this, model -> {
                NetworkStateHelper.Listener listener = (NetworkStateHelper.Listener) BaseActivity.this;
                listener.onNetworkStateChange(model);
            });
        }
    }

    @Override
    public void onBackPressed() {

        if (mOnBackPressIntercept == null || !mOnBackPressIntercept.intercept()) {
            super.onBackPressed();
        }

    }

    public interface OnBackPressIntercept {

        boolean intercept();
    }

}
