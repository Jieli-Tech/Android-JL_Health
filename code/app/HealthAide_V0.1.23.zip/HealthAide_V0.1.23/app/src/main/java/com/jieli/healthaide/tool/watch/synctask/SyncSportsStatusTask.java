package com.jieli.healthaide.tool.watch.synctask;

import android.app.Activity;
import android.os.Bundle;

import com.jieli.component.ActivityManager;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.sports.ui.RunningParentFragment;
import com.jieli.jl_rcsp.impl.HealthOpImpl;
import com.jieli.jl_rcsp.interfaces.OnOperationCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.health.SportsInfo;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/11/4
 * @desc : 同步设备状态任务
 */
public class SyncSportsStatusTask extends DeviceSyncTask {
    private final HealthOpImpl mHealthOp;

    public SyncSportsStatusTask(SyncTaskFinishListener finishListener) {
        super(finishListener);
        mHealthOp = new HealthOpImpl(mWatchManager);
    }

    @Override
    public void start() {
        mHealthOp.readSportsInfo(mHealthOp.getConnectedDevice(), new OnOperationCallback<SportsInfo>() {
            @Override
            public void onSuccess(SportsInfo result) {
                toSportsUi(result.getMode());
                if (finishListener != null) finishListener.onFinish();
            }

            @Override
            public void onFailed(BaseError error) {
                JL_Log.w(tag, "获取运动状态失败：" + error);
                if (finishListener != null) finishListener.onFinish();
            }
        });
    }

    static void toSportsUi(int type) {
        JL_Log.d(SyncSportsStatusTask.class.getSimpleName(), "运动模式：" + type);
        if (type < 1) return;
        Activity activity = ActivityManager.getInstance().getTopActivity();
        if (activity == null) return;
        Bundle bundle = new Bundle();
        bundle.putInt(RunningParentFragment.KEY_RUNNING_TYPE, type);
        ContentActivity.startContentActivity(activity, RunningParentFragment.class.getCanonicalName(), bundle);
    }
}
