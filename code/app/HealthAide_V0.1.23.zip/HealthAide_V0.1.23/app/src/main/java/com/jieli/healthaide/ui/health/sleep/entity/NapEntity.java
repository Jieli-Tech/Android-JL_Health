package com.jieli.healthaide.ui.health.sleep.entity;

/**
 * @ClassName: NapEntity
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/11/3 10:31
 */
public class NapEntity {
    public int drawableSrc;
    public String type;
    public String timeSlot;
    public String duration;
}
