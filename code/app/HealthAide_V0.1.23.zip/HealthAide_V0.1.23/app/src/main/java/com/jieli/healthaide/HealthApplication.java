package com.jieli.healthaide;

import android.app.Application;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;

import com.jieli.component.ActivityManager;
import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.tool.unit.BaseUnitConverter;
import com.jieli.healthaide.ui.base.HealthAppViewModel;
import com.jieli.healthaide.ui.service.NetStateCheckService;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.healthaide.util.MultiLanguageUtils;
import com.jieli.healthaide.util.phone.PhoneUtil;
import com.jieli.jl_health_http.HttpClient;
import com.jieli.jl_health_http.test.MockClient;
import com.jieli.jl_rcsp.util.JL_Log;
import com.tencent.bugly.crashreport.CrashReport;

import static com.jieli.healthaide.ui.service.HealthService.EXTRA_ACTIVITY_CLASS;

/**
 * 健康助手应用入口
 *
 * @author zqjasonZhong
 * @since 2021/1/27
 */
public class HealthApplication extends Application {
    private static HealthAppViewModel sHealthAppViewModel;

    @Override
    public void onCreate() {
        super.onCreate();
        CrashReport.initCrashReport(getApplicationContext(), "44a5616453", false);
        sHealthAppViewModel = new HealthAppViewModel(this);
        ActivityManager.init(this);
        ToastUtil.init(this);
        BaseUnitConverter.setType(PreferencesHelper.getSharedPreferences(this).getInt("unit_converter_type", BaseUnitConverter.TYPE_METRIC));
        if (HealthConstant.USE_TEST_SERVER) {
            MockClient.getInstance().start();
        }
        HttpClient.init(this);
        PhoneUtil.init(this);
        new NetStateCheckService();
        JL_Log.setTagPrefix("health");

        JL_Log.configureLog(this, BuildConfig.DEBUG, BuildConfig.DEBUG);
        com.jieli.bluetooth_connect.util.JL_Log.setLogOutput(JL_Log::addLogOutput);
        IntentFilter intentFilter = new IntentFilter();
        intentFilter.addAction(EXTRA_ACTIVITY_CLASS);
        registerReceiver(broadcastReceiver, intentFilter);
        registerActivityLifecycleCallbacks(MultiLanguageUtils.callbacks);
    }

    public static HealthAppViewModel getAppViewModel() {
        return sHealthAppViewModel;
    }

    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            String action = intent.getAction();
            if (EXTRA_ACTIVITY_CLASS.equals(action)) {
                ActivityManager.getInstance().getCurrentActivity().startActivity(new Intent(getApplicationContext(), ActivityManager.getInstance().getCurrentActivity().getClass()));
            }
        }
    };
}
