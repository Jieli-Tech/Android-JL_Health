package com.jieli.healthaide.tool.notification;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;

import com.jieli.component.utils.PreferencesHelper;
import com.jieli.healthaide.HealthApplication;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc App信息管理
 * @since 2021/7/20
 */
public class AppInfoManager {
    @SuppressLint("StaticFieldLeak")
    private volatile static AppInfoManager manager;
    private final Context mContext;
    private final List<String> appList;

    private final static String KEY_ENABLE_NOTIFICATION = "enable_notification";
    private final static String KEY_APP_LIST = "app_list";
    private final static String KEY_ALLOW_OTHER_APP = "allow_other_app";

    private AppInfoManager() {
        mContext = HealthApplication.getAppViewModel().getApplication();
        String value = PreferencesHelper.getSharedPreferences(mContext).getString(KEY_APP_LIST, "");
        if (!TextUtils.isEmpty(value)) {
            String[] array = value.split(",");
            appList = new ArrayList<>();
            for (String s:array){
                appList.add(s);
            }
        } else {
            appList = new ArrayList<>();
        }
    }

    public static AppInfoManager getInstance() {
        if (null == manager) {
            synchronized (AppInfoManager.class) {
                if (null == manager) {
                    manager = new AppInfoManager();
                }
            }
        }
        return manager;
    }

    public List<String> getObservedAppList() {
        return appList;
    }

    public boolean saveObservedPackageName(String packageName) {
        if (TextUtils.isEmpty(packageName)) return false;
        boolean ret = appList.contains(packageName);
        if (!ret) {
            ret = appList.add(packageName);
            if (ret) {
                syncLocalCache(appList);
            }
        }
        return ret;
    }

    public boolean removeObservedPackageName(String packageName) {
        if (TextUtils.isEmpty(packageName)) return false;
        boolean ret = appList.remove(packageName);
        if (ret) {
            syncLocalCache(appList);
        }
        return ret;
    }

    public void release() {
        appList.clear();
        manager = null;
    }

    public boolean isNotificationEnable() {
        return PreferencesHelper.getSharedPreferences(mContext).getBoolean(KEY_ENABLE_NOTIFICATION, false);
    }

    public void saveNotificationEnable(boolean enable) {
        boolean oldValue = isNotificationEnable();
        if (oldValue != enable) {
            PreferencesHelper.putBooleanValue(mContext, KEY_ENABLE_NOTIFICATION, enable);
        }
    }

    public boolean isAllowOtherApp() {
        if (!isNotificationEnable()) return false;
        return PreferencesHelper.getSharedPreferences(mContext).getBoolean(KEY_ALLOW_OTHER_APP, false);
    }

    public void setAllowOtherApp(boolean allow){
        PreferencesHelper.putBooleanValue(mContext, KEY_ALLOW_OTHER_APP, allow);
    }

    private void syncLocalCache(List<String> list) {
        StringBuilder text = new StringBuilder();
        for (String packageName : list) {
            text.append(packageName).append(",");
        }
        PreferencesHelper.putStringValue(mContext, KEY_APP_LIST, text.toString());
    }
}
