package com.jieli.healthaide.data.vo.preview;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;

import com.jieli.healthaide.data.entity.HealthEntity;
import com.jieli.healthaide.data.vo.BaseLiveDataVo;
import com.jieli.healthaide.data.vo.parse.IParserModify;
import com.jieli.healthaide.data.vo.parse.ParseEntity;
import com.jieli.healthaide.data.vo.parse.SleepParseImpl;
import com.jieli.healthaide.data.vo.sleep.SleepBaseVo;
import com.jieli.healthaide.data.vo.sleep.SleepDayVo;
import com.jieli.healthaide.util.CalendarUtil;

import java.util.ArrayList;
import java.util.List;

/**
 * @ClassName: PreviewSleepVo
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/7/6 8:26
 */
public class PreviewSleepVo extends SleepDayVo {

}
