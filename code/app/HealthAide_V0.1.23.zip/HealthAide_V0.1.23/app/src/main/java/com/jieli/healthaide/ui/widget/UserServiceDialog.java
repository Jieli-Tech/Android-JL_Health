package com.jieli.healthaide.ui.widget;

import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.method.LinkMovementMethod;
import android.text.style.ClickableSpan;
import android.text.style.ForegroundColorSpan;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import com.jieli.component.utils.SystemUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.ui.base.BaseDialogFragment;


/**
 * 用户服务协议弹窗
 *
 * @author zqjasonZhong
 * @since 2020/5/20
 */
public class UserServiceDialog extends BaseDialogFragment {

    private TextView tvTitle;
    private TextView tvContent;
    private TextView tvAgree;
    private TextView tvExit;

    private OnUserServiceListener mOnUserServiceListener;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        if (getDialog() != null) {
            //设置dialog的基本样式参数
            getDialog().requestWindowFeature(Window.FEATURE_NO_TITLE);
            Window window = getDialog().getWindow();
            if (window != null) {
                //去掉dialog默认的padding
                window.getDecorView().setPadding(0, 0, 0, 0);
                WindowManager.LayoutParams lp = window.getAttributes();
                lp.width = WindowManager.LayoutParams.WRAP_CONTENT;
                lp.height = WindowManager.LayoutParams.WRAP_CONTENT;
                lp.gravity = Gravity.CENTER;
                //设置dialog的动画
                window.setAttributes(lp);
                window.setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
            }
        }
        View view = inflater.inflate(R.layout.dialog_user_service, container, false);
        tvTitle = view.findViewById(R.id.tv_user_service_title);
        tvContent = view.findViewById(R.id.tv_user_service_content);
        tvAgree = view.findViewById(R.id.tv_user_service_agree);
        tvExit = view.findViewById(R.id.tv_user_service_exit);
        tvAgree.setOnClickListener(mOnClickListener);
        tvExit.setOnClickListener(mOnClickListener);
        initView();
        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setCancelable(false);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
    }

    private final View.OnClickListener mOnClickListener = new View.OnClickListener() {
        @Override
        public void onClick(View v) {
            if (v == tvAgree) {
                onAgree();
            } else if (v == tvExit) {
                onExit();
            }
        }
    };

    public void setOnUserServiceListener(OnUserServiceListener onUserServiceListener) {
        mOnUserServiceListener = onUserServiceListener;
    }

    private void initView() {
        if (getContext() == null) return;
        String appName = getString(R.string.app_name);

        tvTitle.setText(getString(R.string.declaration, "\""+appName+"\""));
        String text = getString(R.string.user_declaration, appName, appName);
        String userService = getString(R.string.user_service_name);
        int startPos = text.indexOf(userService);
        int endPos = startPos + userService.length();
        SpannableString span = new SpannableString(text);
        span.setSpan(new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                onUserService();
            }
        }, startPos, endPos, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        span.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.auxiliary_widget)), startPos, endPos, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        String privacyPolicy = getString(R.string.privacy_policy_name);
        startPos = text.indexOf(privacyPolicy);
        endPos = startPos + privacyPolicy.length();
        span.setSpan(new ClickableSpan() {
            @Override
            public void onClick(@NonNull View widget) {
                onPrivacyPolicy();
            }
        }, startPos, endPos, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
        span.setSpan(new ForegroundColorSpan(getResources().getColor(R.color.auxiliary_widget)), startPos, endPos, Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);

        tvContent.append(span);
        tvContent.setMovementMethod(LinkMovementMethod.getInstance());
    }

    private void onUserService() {
        if (mOnUserServiceListener != null) {
            mOnUserServiceListener.onUserService();
        }
    }

    private void onPrivacyPolicy() {
        if (mOnUserServiceListener != null) {
            mOnUserServiceListener.onPrivacyPolicy();
        }
    }

    private void onExit() {
        if (mOnUserServiceListener != null) {
            mOnUserServiceListener.onExit(this);
        }
        dismiss();
    }

    private void onAgree() {
        if (mOnUserServiceListener != null) {
            mOnUserServiceListener.onAgree(this);
        }
        dismiss();
    }

    public interface OnUserServiceListener {
        void onUserService();

        void onPrivacyPolicy();

        void onExit(DialogFragment dialogFragment);

        void onAgree(DialogFragment dialogFragment);
    }

}
