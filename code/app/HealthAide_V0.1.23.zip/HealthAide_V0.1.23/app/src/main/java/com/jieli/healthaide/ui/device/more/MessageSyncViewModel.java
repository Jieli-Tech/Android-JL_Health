package com.jieli.healthaide.ui.device.more;

import android.text.TextUtils;

import com.jieli.healthaide.tool.notification.NotificationHelper;
import com.jieli.healthaide.ui.device.WatchViewModel;
import com.jieli.healthaide.util.HealthConstant;

import java.util.List;

public class MessageSyncViewModel extends WatchViewModel {


    public boolean isOpenMessageSync() {
        return NotificationHelper.getInstance().isEnableNotification();
    }

    public boolean isSyncWeChat() {
        return NotificationHelper.getInstance().isSelectedApp(HealthConstant.PACKAGE_NAME_WECHAT);
    }

    public boolean isSyncQQ() {
        return NotificationHelper.getInstance().isSelectedApp(HealthConstant.PACKAGE_NAME_QQ);
    }

    public boolean isSyncSms() {
        return NotificationHelper.getInstance().isSelectedApp(HealthConstant.PACKAGE_NAME_SYS_MESSAGE);
    }

    public boolean isSyncOther() {
        return NotificationHelper.getInstance().isAllowOther();
    }

    public List<String> getSelectedApp() {
        return NotificationHelper.getInstance().getPackageObserverList();
    }

    public void addAppPackage(String packageName) {
        if (TextUtils.isEmpty(packageName)) return;
        NotificationHelper.getInstance().addPackageName(packageName);
    }

    public void removeAppPackage(String packageName) {
        if (TextUtils.isEmpty(packageName)) return;
        NotificationHelper.getInstance().removePackageName(packageName);
    }

    public void setEnableNotification(boolean enable) {
        NotificationHelper.getInstance().setEnableNotification(enable);
    }

    public void setNotFilter(boolean value) {
        NotificationHelper.getInstance().setAllowOther(value);
    }

}