package com.jieli.healthaide.ui.device.upgrade;

import android.bluetooth.BluetoothDevice;
import android.os.Handler;

import androidx.lifecycle.MutableLiveData;

import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.upgrade.OTAManager;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.tool.watch.WatchServerCacheHelper;
import com.jieli.healthaide.ui.device.BluetoothViewModel;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.healthaide.util.HealthUtil;
import com.jieli.jl_bt_ota.constant.ErrorCode;
import com.jieli.jl_bt_ota.constant.StateCode;
import com.jieli.jl_bt_ota.interfaces.BtEventCallback;
import com.jieli.jl_bt_ota.interfaces.IUpgradeCallback;
import com.jieli.jl_bt_ota.model.base.BaseError;
import com.jieli.jl_bt_ota.util.FileUtil;
import com.jieli.jl_bt_ota.util.JL_Log;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.utils.FatUtil;
import com.jieli.jl_health_http.model.OtaFileMsg;
import com.jieli.jl_rcsp.interfaces.watch.OnUpdateResourceCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.tool.DeviceStatusManager;
import com.jieli.jl_rcsp.tool.datahandles.ParseHelper;
import com.jieli.jl_rcsp.util.WatchFileUtil;

import java.io.File;

public class UpgradeViewModel extends BluetoothViewModel {
    private final static String TAG = UpgradeViewModel.class.getSimpleName();
    private final WatchManager mWatchManager = WatchManager.getInstance();
    private final OTAManager mOTAManager;
    private final WatchServerCacheHelper mWatchServerCacheHelper = WatchServerCacheHelper.getInstance();
    private final DeviceStatusManager mStatusManager = DeviceStatusManager.getInstance();

    public final MutableLiveData<OtaState> mOtaStateMLD = new MutableLiveData<>();
    public final MutableLiveData<Boolean> mOtaInitMLD = new MutableLiveData<>();

    public BluetoothDevice mTargetDevice;
    public final OtaState mOtaState;
    public int mOtaFlag;
    private String mUpgradeZipPath;

    /**
     * 是否开启本地OTA测试功能
     * Description 默认是关闭，开启后，需要在/Android/data/com.jieli.healthaide/files/upgrade/放入升级文件
     * 升级文件默认为xxx.zip的压缩包。
     */
    public static boolean IS_LOCAL_OTA_TEST = false;

    private final Handler mHandler = new Handler(msg -> true);

    public UpgradeViewModel() {
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
        mOTAManager = new OTAManager(HealthApplication.getAppViewModel().getApplication());
        mOTAManager.registerBluetoothCallback(mBtEventCallback);

        mTargetDevice = mWatchManager.getConnectedDevice();
        mOtaState = new OtaState();
        mOtaState.setState(OtaState.OTA_STATE_IDLE);
        String otaDir = HealthUtil.createFilePath(HealthApplication.getAppViewModel().getApplication(), HealthConstant.DIR_UPDATE);
        String otaFilePath = HealthUtil.obtainUpdateFilePath(otaDir, OTAManager.OTA_ZIP_SUFFIX);
        if (null == otaFilePath) {
            otaFilePath = mOTAManager.getBluetoothOption().getFirmwareFilePath();
        }
        mOtaState.setOtaFilePath(otaFilePath);
    }

    public void release() {
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        mOTAManager.unregisterBluetoothCallback(mBtEventCallback);
        mOTAManager.release();
    }

    public DeviceInfo getDeviceInfo() {
        return mWatchManager.getDeviceInfo(mTargetDevice);
    }

    public boolean isDevOta() {
        return mOTAManager.isOTA();
    }

    public void otaPrepare() {
        if (!isUsingDevice(mTargetDevice)) {
            JL_Log.e(TAG, "-otaPrepare- param error");
            return;
        }
        if (isDevOta()) {
            JL_Log.e(TAG, "-otaPrepare- dev is in ota.");
            return;
        }
        switch (mOtaState.getState()) {
            case OtaState.OTA_STATE_IDLE:
                if (IS_LOCAL_OTA_TEST) {
                    checkLocalOtaFile();
                } else {
                    DeviceInfo deviceInfo = mStatusManager.getDeviceInfo(mTargetDevice);
                    int pid = deviceInfo.getPid();
                    int vid = deviceInfo.getVid();
                    queryOtaMsgForServer(pid, vid);
                }
                break;
            case OtaState.OTA_STATE_PREPARE:
                if (IS_LOCAL_OTA_TEST) {
                    mOtaState.setState(OtaState.OTA_STATE_UPGRADE)
                            .setOtaFilePath(mOtaState.getMessage().getUrl());
                    mOtaStateMLD.setValue(mOtaState);

                    otaPrepare();
                } else {
                    String fileName = WatchFileUtil.getFileName(mOtaState.getMessage().getUrl());
                    String otaFilePath = HealthUtil.createFilePath(HealthApplication.getAppViewModel().getApplication(), HealthConstant.DIR_UPDATE) + "/" + fileName;
                    downloadFile(mOtaState.getMessage().getUrl(), otaFilePath);
                }
                break;
            case OtaState.OTA_STATE_UPGRADE:
                startOTA(mOtaState.getOtaFilePath());
                break;
        }
    }

    public void startOTA(String filePath) {
        if (isDevOta()) {
            return;
        }
        boolean isOtaDev = filePath.endsWith(".ufw") || filePath.endsWith(".buf");
        if (isOtaDev) {
            otaFirmware(filePath);
        } else {
            otaResource(filePath);
        }
    }

    public void otaFirmware(String filePath) {
        mOTAManager.getBluetoothOption().setFirmwareFilePath(filePath);
        mOTAManager.startOTA(new IUpgradeCallback() {
            @Override
            public void onStartOTA() {
                JL_Log.i(TAG, "-otaFirmware- onStart >>>>>> ");
                mTargetDevice = mOTAManager.getConnectedDevice();
                mOtaState.setState(OtaState.OTA_STATE_START)
                        .setOtaType(OtaState.OTA_TYPE_OTA_READY);
                mOtaStateMLD.setValue(mOtaState);
            }

            @Override
            public void onNeedReconnect(String s) {
                //TODO:允许客户自定义回连方式
            }

            @Override
            public void onProgress(int i, float v) {
                JL_Log.i(TAG, "-otaFirmware- onProgress >>>>>> type = " + i + ", progress = " + v);
                if (v > 0) {
                    mOtaState.setState(OtaState.OTA_STATE_WORKING)
                            .setOtaType(i == 0 ? OtaState.OTA_TYPE_OTA_READY : OtaState.OTA_TYPE_OTA_UPGRADE_FIRMWARE)
                            .setOtaProgress(v);
                    mOtaStateMLD.setValue(mOtaState);
                }
            }

            @Override
            public void onStopOTA() {
                JL_Log.e(TAG, "-otaFirmware- :: onStopOTA");
                mOtaState.setState(OtaState.OTA_STATE_STOP)
                        .setStopResult(OtaState.OTA_RES_SUCCESS)
                        .setOtaProgress(0f);
                mOtaStateMLD.setValue(mOtaState);
                if (mUpgradeZipPath != null) {
                    //非本地测试时才删除文件
                    if (!IS_LOCAL_OTA_TEST) {
                        FileUtil.deleteFile(new File(mUpgradeZipPath));
                    }
                    mUpgradeZipPath = null;
                }
            }

            @Override
            public void onCancelOTA() {
                mOtaState.setState(OtaState.OTA_STATE_STOP)
                        .setStopResult(OtaState.OTA_RES_CANCEL)
                        .setOtaProgress(0f);
                mOtaStateMLD.setValue(mOtaState);
                if (mUpgradeZipPath != null) {
                    //非本地测试时才删除文件
                    if (!IS_LOCAL_OTA_TEST) {
                        FileUtil.deleteFile(new File(mUpgradeZipPath));
                    }
                    mUpgradeZipPath = null;
                }
            }

            @Override
            public void onError(BaseError baseError) {
                JL_Log.e(TAG, "-otaFirmware- :: onError, baseError = " + baseError);
                if (baseError != null) {
                    onOtaFailed(baseError.getSubCode(), baseError.getMessage());
                }
                if (mUpgradeZipPath != null) {
                    mUpgradeZipPath = null;
                }

                mHandler.postDelayed(() -> {
                    if (isUsingDevice(mTargetDevice)) {
                        mOtaState.setState(OtaState.OTA_STATE_IDLE).setStopResult(0);
                        mOtaStateMLD.setValue(mOtaState);
                    }
                }, 1000);
            }
        });
    }

    public void otaResource(final String filePath) {
        mWatchManager.updateWatchResource(filePath, new OnUpdateResourceCallback() {
            @Override
            public void onStart(String filePath, int total) {
                JL_Log.i(TAG, "-otaResource- onStart >>>>>> filePath = " + filePath + ", total = " + total);
                mTargetDevice = mOTAManager.getConnectedDevice();
                mOtaState.setState(OtaState.OTA_STATE_START)
                        .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                        .setOtaTotal(total);
                mOtaStateMLD.setValue(mOtaState);
            }

            @Override
            public void onProgress(int index, String filePath, float progress) {
                if (progress > 0) {
                    mOtaState.setState(OtaState.OTA_STATE_WORKING)
                            .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                            .setOtaIndex(index + 1)
                            .setOtaFileInfo(HealthUtil.getFileNameByPath(filePath))
                            .setOtaProgress(progress);
                    mOtaStateMLD.setValue(mOtaState);
                }
            }

            @Override
            public void onStop(String otaFilePath) {
                JL_Log.i(TAG, "-otaResource- onStop >>>>>> otaFilePath = " + otaFilePath);
                if (otaFilePath == null) {
                    mOtaState.setState(OtaState.OTA_STATE_STOP)
                            .setOtaType(OtaState.OTA_TYPE_OTA_UPDATE_RESOURCE)
                            .setStopResult(OtaState.OTA_RES_SUCCESS);
                    mOtaStateMLD.setValue(mOtaState);
                } else {
                    mUpgradeZipPath = filePath;
                    otaFirmware(otaFilePath);
                }
            }

            @Override
            public void onError(int code, String message) {
                if (code == FatFsErrCode.RES_ERR_SPACE_TO_UPDATE) {
                    message = HealthApplication.getAppViewModel().getApplication().getString(R.string.ota_err_no_space);
                } else if (code == FatFsErrCode.RES_REMOTE_NOT_CONNECT) {
                    message = HealthApplication.getAppViewModel().getApplication().getString(R.string.ota_err_device_not_connect);
                }
                onOtaFailed(code, message);
            }
        });
    }

   /* public void cancelOTA() {
        if (isDevOta()) {
            mOTAManager.cancelOTA();
        }
    }*/

    public boolean checkNeedDisconnect(int result) {
        return result > 1024 && result != ErrorCode.SUB_ERR_OTA_IN_HANDLE && result != ErrorCode.SUB_ERR_FILE_NOT_FOUND;
    }

    private void queryOtaMsgForServer(int pid, int vid) {
        mWatchServerCacheHelper.queryOtaMsg(pid, vid, new WatchServerCacheHelper.IWatchHttpCallback<OtaFileMsg>() {
            @Override
            public void onSuccess(OtaFileMsg result) {
                if (judgeDeviceNeedToOta(result)) {
                    mOtaState.setState(OtaState.OTA_STATE_PREPARE)
                            .setMessage(result);
                    if (mOtaFlag != UpgradeFragment.OTA_FLAG_NORMAL) {
                        otaPrepare();
                    }
                } else {
                    mOtaState.setState(OtaState.OTA_STATE_IDLE)
                            .setMessage(result)
                            .setStopResult(OtaState.OTA_RES_SUCCESS);
                }
                mOtaStateMLD.setValue(mOtaState);
            }

            @Override
            public void onFailed(int code, String message) {
                onOtaFailed(code, message);
            }
        });
    }

    private void downloadFile(String url, String outPath) {
        mWatchServerCacheHelper.downloadFile(url, outPath, new WatchServerCacheHelper.OnDownloadListener() {
            @Override
            public void onStart() {

            }

            @Override
            public void onProgress(int progress) {
                mOtaState.setState(OtaState.OTA_STATE_DOWNLOAD)
                        .setOtaProgress(progress);
                mOtaStateMLD.setValue(mOtaState);
            }

            @Override
            public void onSuccess(String result) {
                mOtaState.setState(OtaState.OTA_STATE_UPGRADE)
                        .setOtaFilePath(result);
                mOtaStateMLD.setValue(mOtaState);

                otaPrepare();
            }

            @Override
            public void onFailed(int code, String message) {
                onOtaFailed(code, message);
            }
        });
    }


    private void onOtaFailed(int code, String msg) {
        JL_Log.e(TAG, "-onOtaFailed- code : " + code + ",  msg : " + msg);
        if (null != mOtaStateMLD.getValue() && mOtaStateMLD.getValue().getState() == OtaState.OTA_STATE_STOP)
            return;
        mOtaState.setState(OtaState.OTA_STATE_STOP)
                .setStopResult(OtaState.OTA_RES_FAILED)
                .setError(new BaseError(code, msg))
                .setOtaProgress(0f);
        mOtaStateMLD.setValue(mOtaState);
    }

    private boolean judgeDeviceNeedToOta(OtaFileMsg message) {
        if (mTargetDevice == null || message == null) return false;
        DeviceInfo deviceInfo = mStatusManager.getDeviceInfo(mTargetDevice);
        if (deviceInfo == null) {
            onOtaFailed(ErrorCode.SUB_ERR_BLE_NOT_CONNECTED, "device is not connected.");
            return false;
        }
        int versionCode = deviceInfo.getVersionCode();
        int serverFirmware = ParseHelper.convertVersionByString(message.getVersion());
        JL_Log.i(TAG, "judgeDeviceNeedToOta:: versionCode : " + versionCode + ", sever firmware version : " + serverFirmware);
        return versionCode < serverFirmware || (serverFirmware == 0);
    }

    private void checkLocalOtaFile() {
        String otaDir = HealthUtil.createFilePath(HealthApplication.getAppViewModel().getApplication(), HealthConstant.DIR_UPDATE);
        String otaFilePath = HealthUtil.obtainUpdateFilePath(otaDir, OTAManager.OTA_ZIP_SUFFIX);
        if (null != otaFilePath) {
            OtaFileMsg otaFileMsg = new OtaFileMsg();
            otaFileMsg.setExplain("本地文件测试");
            otaFileMsg.setUrl(otaFilePath);
            otaFileMsg.setVersion("V_0.0.0.0");
            mOtaState.setState(OtaState.OTA_STATE_PREPARE)
                    .setMessage(otaFileMsg);
            mOtaStateMLD.setValue(mOtaState);
        } else {
            onOtaFailed(ErrorCode.SUB_ERR_FILE_NOT_FOUND, "ota file not found.");
        }
    }

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {
        @Override
        public void onWatchSystemInit(int code) {

        }

        @Override
        public void onResourceUpdateUnfinished(BluetoothDevice device) {

        }
    };

    private final BtEventCallback mBtEventCallback = new BtEventCallback() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            if (status == StateCode.CONNECTION_OK) {
                mTargetDevice = device;
                mOtaInitMLD.postValue(true);
            } else if (status == StateCode.CONNECTION_DISCONNECT && !isDevOta()) {
                mOtaInitMLD.postValue(false);
                onOtaFailed(FatFsErrCode.RES_REMOTE_NOT_CONNECT, FatUtil.getFatFsErrorCodeMsg(FatFsErrCode.RES_REMOTE_NOT_CONNECT));
            }
        }
    };
}