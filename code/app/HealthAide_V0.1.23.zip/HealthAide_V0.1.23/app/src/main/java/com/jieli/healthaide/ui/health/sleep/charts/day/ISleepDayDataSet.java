package com.jieli.healthaide.ui.health.sleep.charts.day;

import com.github.mikephil.charting.interfaces.datasets.ILineScatterCandleRadarDataSet;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/3/21 3:16 PM
 * @desc :
 */


public interface ISleepDayDataSet extends ILineScatterCandleRadarDataSet<SleepDayEntry> {
}
