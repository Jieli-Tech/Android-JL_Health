package com.jieli.healthaide.ui.test;

import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.LinearLayout;

import androidx.annotation.Nullable;

import com.amap.api.location.AMapLocation;
import com.amap.api.location.AMapLocationClient;
import com.amap.api.location.AMapLocationClientOption;
import com.amap.api.location.AMapLocationListener;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.healthaide.ui.device.health.HealthOptionFragment;
import com.jieli.healthaide.ui.sports.ui.SportsControllTestFragment;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 4/21/21
 * @desc :
 */
public class TestListActivity extends BaseActivity {


    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        LinearLayout linearLayout = new LinearLayout(this);
        linearLayout.setOrientation(LinearLayout.VERTICAL);

        linearLayout.addView(createItem("天气测试", v -> {
            ContentActivity.startContentActivity(this, WeatherTestFragment.class.getCanonicalName());
        }));

        linearLayout.addView(createItem("健康设置", v -> {
            ContentActivity.startContentActivity(this, HealthOptionFragment.class.getCanonicalName());
        }));
        linearLayout.addView(createItem("运动控制", v -> {
            ContentActivity.startContentActivity(this, SportsControllTestFragment.class.getCanonicalName());
        }));

        linearLayout.addView(createItem("定位测试", v -> {
            AMapLocationClient mLocationClient = new AMapLocationClient(this);
            mLocationClient.setLocationListener(new AMapLocationListener() {
                @Override
                public void onLocationChanged(AMapLocation aMapLocation) {
                    JL_Log.e(tag, aMapLocation.toString());
                }
            });
            AMapLocationClientOption option = new AMapLocationClientOption();
            option
                    .setLocationMode(AMapLocationClientOption.AMapLocationMode.Battery_Saving)
                    .setLocationPurpose(AMapLocationClientOption.AMapLocationPurpose.Sport)
                    .setOnceLocation(true)
                    .setOnceLocationLatest(true)
                    .setNeedAddress(false);
            mLocationClient.setLocationOption(option);
            mLocationClient.startLocation();
        }));
        setContentView(linearLayout);
    }

    private View createItem(String text, View.OnClickListener listener) {
        Button button = new Button(this);

        button.setOnClickListener(listener);
        button.setText(text);

        return button;
    }
}
