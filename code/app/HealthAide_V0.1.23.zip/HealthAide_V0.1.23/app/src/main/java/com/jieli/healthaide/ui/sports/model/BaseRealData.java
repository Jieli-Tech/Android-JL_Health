package com.jieli.healthaide.ui.sports.model;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/10/27
 * @desc :运动过程中得实时数据
 */
public class BaseRealData {

}
