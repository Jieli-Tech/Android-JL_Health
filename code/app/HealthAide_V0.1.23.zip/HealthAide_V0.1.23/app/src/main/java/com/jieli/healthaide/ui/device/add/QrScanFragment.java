package com.jieli.healthaide.ui.device.add;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.MediaStore;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jieli.bluetooth_connect.bean.ble.BleScanMessage;
import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.component.utils.ValueUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentQrScanBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.device.bean.DeviceQrMsg;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.Arrays;
import java.util.List;

import me.devilsen.czxing.code.BarcodeFormat;
import me.devilsen.czxing.code.BarcodeReader;
import me.devilsen.czxing.code.CodeResult;
import me.devilsen.czxing.util.BitmapUtil;
import me.devilsen.czxing.util.SoundPoolUtil;
import me.devilsen.czxing.view.ScanBoxView;
import me.devilsen.czxing.view.ScanListener;

public class QrScanFragment extends BaseFragment {

    private FragmentQrScanBinding mScanBinding;
    private SoundPoolUtil mSoundPoolUtil;
    private final Handler mHandler = new Handler(Looper.getMainLooper());

    private boolean isLightOpen;
    private final static int CODE_SELECT_IMAGE = 1010;

    public static QrScanFragment newInstance() {
        return new QrScanFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mScanBinding = FragmentQrScanBinding.inflate(inflater, container, false);
        return mScanBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mSoundPoolUtil = new SoundPoolUtil();
        mSoundPoolUtil.loadDefault(requireContext());

        initTopBar();
        initScanView();
        mScanBinding.ivQrScanLight.setOnClickListener(v -> {
            if (isLightOpen) {
                isLightOpen = false;
                mScanBinding.svQrScan.closeFlashlight();
            } else {
                isLightOpen = true;
                mScanBinding.svQrScan.openFlashlight();
            }
            updateLightUI(isLightOpen);
        });
        mScanBinding.tvQrScanGallery.setOnClickListener(v -> {
            if (ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(requireActivity(),
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        HealthConstant.REQUEST_CODE_STORAGE);
            } else {
                selectPhotoFromAlbum();
            }
        });
        mScanBinding.tvQrScanPairDevice.setOnClickListener(v -> {
            ContentActivity.startContentActivity(requireContext(), AddDeviceFragment.class.getCanonicalName());
            requireActivity().finish();
        });
        mScanBinding.svQrScan.setBanZoom(true);
    }

    @Override
    public void onResume() {
        super.onResume();
        mScanBinding.svQrScan.openCamera();
        mScanBinding.svQrScan.startScan();
        isLightOpen = false;
        updateLightUI(false);

    }

    @Override
    public void onPause() {
        super.onPause();
        mScanBinding.svQrScan.stopScan();
        mScanBinding.svQrScan.closeCamera();
        isLightOpen = false;
    }

    @Override
    public void onDestroy() {
        mScanBinding.svQrScan.onDestroy();
        mSoundPoolUtil.release();
        mHandler.removeCallbacksAndMessages(null);
        super.onDestroy();
        mScanBinding = null;
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == CODE_SELECT_IMAGE && resultCode == Activity.RESULT_OK) {
            decodeImage(data);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if(requestCode == HealthConstant.REQUEST_CODE_STORAGE){
            if (permissions.length == 0 || grantResults.length == 0)
                return;
            if (permissions[0].equals(Manifest.permission.READ_EXTERNAL_STORAGE) && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                selectPhotoFromAlbum();
            }
            return;
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    private void initTopBar() {
        mScanBinding.clQrScanTopbar.tvTopbarLeft.setCompoundDrawablesRelativeWithIntrinsicBounds(R.drawable.ic_back_white, 0, 0, 0);
        mScanBinding.clQrScanTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().finish());
        mScanBinding.clQrScanTopbar.tvTopbarTitle.setText(getString(R.string.scan_qr_code_title));
        mScanBinding.clQrScanTopbar.tvTopbarTitle.setTextColor(getResources().getColor(R.color.white));
    }

    private void initScanView() {
        Resources resources = getResources();
        List<Integer> scanColors = Arrays.asList(resources.getColor(R.color.blue_scan_side), resources.getColor(R.color.blue_scan_partial), resources.getColor(R.color.blue_scan_middle));
        ScanBoxView scanBox = mScanBinding.svQrScan.getScanBox();
        scanBox.setMaskColor(resources.getColor(R.color.gray_transparent_9C272626));
        scanBox.setBoxTopOffset(-ValueUtil.dp2px(requireContext(), 50));
        scanBox.setBorderSize(ValueUtil.dp2px(requireContext(), 240), ValueUtil.dp2px(requireContext(), 240));
        scanBox.setCornerColor(resources.getColor(R.color.blue_558CFF));
        scanBox.setScanLineColor(scanColors);
        scanBox.invisibleFlashLightIcon();
        scanBox.setScanNoticeText(getString(R.string.scan_qr_tips));

        mScanBinding.svQrScan.setScanListener(new ScanListener() {
            @Override
            public void onScanSuccess(final String result, BarcodeFormat format) {
                mSoundPoolUtil.play();
                handleQrResult(result);
            }

            @Override
            public void onOpenCameraError() {
                requireActivity().finish();
            }
        });
        mScanBinding.svQrScan.setAnalysisBrightnessListener(isDark -> mHandler.post(() -> {
            if (isDark) {
                if (!isLightOpen) {
                    ToastUtil.showToastShort(R.string.scan_env_dark_tips);
                }
            } else if (isLightOpen) {
                ToastUtil.showToastShort(R.string.scan_env_light_tips);
            }
        }));

    }

    private void updateLightUI(boolean isOpen) {
        mScanBinding.ivQrScanLight.setImageResource(isOpen ? R.drawable.ic_scan_light_white : R.drawable.ic_scan_light_gray);
    }

    private void decodeImage(Intent intent) {
        if (intent == null) return;
        Uri selectImageUri = intent.getData();
        if (selectImageUri == null) {
            return;
        }
        String[] filePathColumn = {MediaStore.Images.Media.DATA};
        Cursor cursor = requireActivity().getContentResolver().query(selectImageUri, filePathColumn, null, null, null);
        if (cursor == null) {
            return;
        }
        cursor.moveToFirst();
        int columnIndex = cursor.getColumnIndex(filePathColumn[0]);
        String picturePath = cursor.getString(columnIndex);
        cursor.close();

        Bitmap bitmap = BitmapUtil.getDecodeAbleBitmap(picturePath);
        if (bitmap == null) {
            return;
        }

        CodeResult result = BarcodeReader.getInstance().read(bitmap);
        if (result == null) {
            ToastUtil.showToastShort(R.string.not_found_qr);
        } else {
            handleQrResult(result.getText());
        }
    }

    private void handleQrResult(final String text) {
        //解析json数据
        Gson gson = new GsonBuilder().setLenient().create();
        DeviceQrMsg deviceQrMsg = null;
        try {
            deviceQrMsg = gson.fromJson(text, DeviceQrMsg.class);
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (deviceQrMsg != null) {
            BluetoothDevice device;
            if (deviceQrMsg.getConnectWay() == BluetoothConstant.PROTOCOL_TYPE_SPP) {
                device = BluetoothUtil.getRemoteDevice(deviceQrMsg.getEdrAddr());
            } else {
                device = BluetoothUtil.getRemoteDevice(deviceQrMsg.getBleAddr());
            }
            BleScanMessage scanMessage = new BleScanMessage();
            if (device != null) scanMessage.setDeviceType(device.getType());
            scanMessage.setEdrAddr(deviceQrMsg.getEdrAddr());
            scanMessage.setConnectWay(deviceQrMsg.getConnectWay());
            scanMessage.setPid(deviceQrMsg.getPid());
            scanMessage.setUid(deviceQrMsg.getVid());
            Bundle bundle = new Bundle();
            bundle.putParcelable(ConnectFragment.KEY_CONNECT_DEV, device);
            bundle.putSerializable(ConnectFragment.KEY_CONNECT_BLE_MSG, scanMessage);
            ContentActivity.startContentActivity(requireContext(), ConnectFragment.class.getCanonicalName(), bundle);
            requireActivity().finish();
        } else {
            JL_Log.w(tag, "Not valid content: " + text);
            mHandler.post(() -> {
                ToastUtil.showToastShort(text);
                mScanBinding.svQrScan.resetZoom();
                mScanBinding.svQrScan.startScan();
            });
        }
    }

    private void selectPhotoFromAlbum() {
        Intent albumIntent = new Intent(Intent.ACTION_PICK, MediaStore.Images.Media.EXTERNAL_CONTENT_URI);
        startActivityForResult(albumIntent, CODE_SELECT_IMAGE);
    }
}