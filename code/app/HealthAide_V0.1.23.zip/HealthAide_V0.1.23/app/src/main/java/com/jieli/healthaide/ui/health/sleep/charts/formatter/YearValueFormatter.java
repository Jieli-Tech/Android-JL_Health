package com.jieli.healthaide.ui.health.sleep.charts.formatter;

import com.github.mikephil.charting.formatter.ValueFormatter;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/3/21 8:33 PM
 * @desc :
 */
public class YearValueFormatter extends ValueFormatter {
    @Override
    public String getFormattedValue(float value) {
         return String.format("%d月", (int) value);
    }

}
