package com.jieli.healthaide.ui.sports.ui.set;

import android.content.ComponentName;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;

import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentRunningSetBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseFragment;

/**
 * @ClassName: RunningSetFragment
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/11/4 16:03
 */
public class RunningSetFragment extends BaseFragment {

    public RunningSetFragment() {
        // Required empty public constructor
    }


    public static RunningSetFragment newInstance() {
        RunningSetFragment fragment = new RunningSetFragment();
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        // Inflate the layout for this fragment
        FragmentRunningSetBinding binding = DataBindingUtil.inflate(inflater, R.layout.fragment_running_set, container, false);
        binding.layoutTopbar.tvTopbarTitle.setText(R.string.running_set);
        binding.layoutTopbar.tvTopbarLeft.setOnClickListener(v -> {
            requireActivity().finish();
        });
        binding.layoutSportPermission.tvSettingTarget2.setText(R.string.permission_sport);
        binding.layoutSportPermission.getRoot().setOnClickListener(v -> {
            ContentActivity.startContentActivity(requireContext(), SportPermissionFragment.class.getCanonicalName());
        });
        if (Build.MANUFACTURER.equalsIgnoreCase("Xiaomi")) {
            binding.clLockScreenDisplay.setVisibility(View.VISIBLE);
            binding.clLockScreenDisplay.setOnClickListener(v -> {
                Intent intent = new Intent();
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ComponentName componentName = ComponentName.unflattenFromString("com.miui.securitycenter/com.miui.appmanager.ApplicationsDetailsActivity");
                intent.setComponent(componentName);
                intent.putExtra("package_name", getContext().getPackageName());
                intent.putExtra("package_label", getContext().getString(R.string.app_name));
                getContext().startActivity(intent);
            });
        }
        return binding.getRoot();
    }
}
