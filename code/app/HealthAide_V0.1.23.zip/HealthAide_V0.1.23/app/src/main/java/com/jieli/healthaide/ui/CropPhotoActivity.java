package com.jieli.healthaide.ui;

import android.app.Activity;
import android.bluetooth.BluetoothDevice;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;

import com.jieli.component.utils.SystemUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.ActivityCropPhotoBinding;
import com.jieli.healthaide.tool.bluetooth.BluetoothHelper;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.jl_rcsp.model.response.ExternalFlashMsgResponse;
import com.jieli.jl_rcsp.tool.DeviceStatusManager;
import com.jieli.jl_rcsp.util.JL_Log;
import com.yalantis.ucrop.UCrop;
import com.yalantis.ucrop.UCropFragment;
import com.yalantis.ucrop.UCropFragmentCallback;
import com.yalantis.ucrop.view.GestureCropImageView;
import com.yalantis.ucrop.view.UCropView;

import java.io.File;

/**
 * 裁剪图片界面
 */
public class CropPhotoActivity extends BaseActivity implements UCropFragmentCallback {

    private ActivityCropPhotoBinding mCropPhotoBinding;
    private UCropFragment mCropFragment;
    private UCropView mUCropView;
    private GestureCropImageView mGestureCropImageView;

    private int cropType;
    private Uri photoUri;
    private String outputPath;

    private final Handler mHandler = new Handler(Looper.getMainLooper());

    public final static String KEY_CROP_TYPE = "crop_type";
    public final static String KEY_RESOURCE_URI = "resource_uri";
    public final static String KEY_OUTPUT_PATH = "output_path";

    public final static int CROP_TYPE_AVATAR = 1;
    public final static int CROP_TYPE_WATCH_BG = 2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        SystemUtil.setImmersiveStateBar(getWindow(), true);
        mCropPhotoBinding = ActivityCropPhotoBinding.inflate(getLayoutInflater());
        setContentView(mCropPhotoBinding.getRoot());
        mCropPhotoBinding.tvCropPhotoCancel.setOnClickListener(v -> {
            setResult(Activity.RESULT_CANCELED);
            finish();
        });
        mCropPhotoBinding.tvCropPhotoSelect.setOnClickListener(v -> {
            if (mCropFragment != null && mCropFragment.isAdded()) {
                mCropFragment.cropAndSaveImage();
            }
        });
        mCropPhotoBinding.ivCropPhotoRotate.setOnClickListener(v -> {
            if (mCropFragment != null && mCropFragment.isAdded() && mGestureCropImageView != null) {
                mGestureCropImageView.postRotate(90);
                mGestureCropImageView.setImageToWrapCropBounds();
            }
        });
        final BluetoothDevice device = BluetoothHelper.getInstance().getConnectedBtDevice();
        if (null == getIntent() || null == device) {
            finish();
            return;
        }
        cropType = getIntent().getIntExtra(KEY_CROP_TYPE, 0);
        photoUri = getIntent().getParcelableExtra(KEY_RESOURCE_URI);
        outputPath = getIntent().getStringExtra(KEY_OUTPUT_PATH);
        JL_Log.i(tag, "-onCreate- cropType = " + cropType + ", photoUri = " + photoUri + ", outputPath = " + outputPath);
        if (cropType <= 0 || null == photoUri || null == outputPath) {
            finish();
            return;
        }
        UCrop uCrop = UCrop.of(photoUri, Uri.fromFile(new File(outputPath)));
        if (cropType == CROP_TYPE_WATCH_BG) {
            int width = 240;
            int height = 280;
            ExternalFlashMsgResponse externalFlashMsg = DeviceStatusManager.getInstance().getExtFlashMsg(device);
            if(externalFlashMsg != null){
                if(externalFlashMsg.getScreenWidth() > 0){
                    width = externalFlashMsg.getScreenWidth();
                }
                if(externalFlashMsg.getScreenHeight() > 0){
                    height = externalFlashMsg.getScreenHeight();
                }
            }
            JL_Log.i(tag, "-onCreate- width = " + width + ", height = " + height);
            uCrop.withAspectRatio(width, height)
                    .withMaxResultSize(width, height);
        } else {
            uCrop.withAspectRatio(1.0f, 1.0f)
                    .withMaxResultSize(180, 180);
        }
        UCrop.Options options = new UCrop.Options();
        options.setCompressionFormat(Bitmap.CompressFormat.JPEG);
        options.setCompressionQuality(100);
        //是否隐藏底部控制栏
        options.setHideBottomControls(true);
        //是否可以自由裁剪
        options.setFreeStyleCropEnabled(false);
        //设置图像最大体积
        options.setMaxBitmapSize(200 * 1024);
        uCrop.withOptions(options);
        setupFragment(uCrop);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mCropPhotoBinding = null;
    }

    public void setupFragment(UCrop uCrop) {
        mCropFragment = uCrop.getFragment(uCrop.getIntent(CropPhotoActivity.this).getExtras());
        getSupportFragmentManager().beginTransaction()
                .add(R.id.fl_crop_photo_container, mCropFragment, UCropFragment.TAG)
                .commitAllowingStateLoss();

        mHandler.postDelayed(() -> {
            if(mCropFragment != null && mCropFragment.isAdded()){
                mUCropView = mCropFragment.requireView().findViewById(com.yalantis.ucrop.R.id.ucrop);
                mGestureCropImageView = mUCropView.getCropImageView();
            }
        }, 200);

    }

    @Override
    public void loadingProgress(boolean showLoader) {

    }

    @Override
    public void onCropFinish(UCropFragment.UCropResult result) {
        JL_Log.i(tag, "-onCropFinish- result : "  + result.mResultCode + ", intent = " + result.mResultData);
        setResult(result.mResultCode, result.mResultData);
        finish();
    }
}