package com.jieli.healthaide.ui.sports.notify;

import android.content.Context;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/11/2
 * @desc :
 */
public class DeviceOutdoorRunningNotifySender extends DeviceIndoorRunningNotifySender {
    public DeviceOutdoorRunningNotifySender(Context context) {
        super(context);
    }
}
