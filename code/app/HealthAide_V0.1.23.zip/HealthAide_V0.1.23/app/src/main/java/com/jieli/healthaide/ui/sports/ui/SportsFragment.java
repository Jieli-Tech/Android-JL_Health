package com.jieli.healthaide.ui.sports.ui;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.viewpager.widget.ViewPager;
import androidx.viewpager2.adapter.FragmentStateAdapter;
import androidx.viewpager2.widget.ViewPager2;

import com.google.android.material.tabs.TabLayout;
import com.jieli.healthaide.databinding.FragmentSportsBinding;
import com.jieli.healthaide.ui.base.BaseFragment;

/**
 * 运动界面
 */
public class SportsFragment extends BaseFragment {
    private FragmentSportsBinding mSportsBinding;

    public SportsFragment() {
        // Required empty public constructor
    }

    public static SportsFragment newInstance() {
        return new SportsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        mSportsBinding = FragmentSportsBinding.inflate(inflater, container, false);
        mSportsBinding.vp2Sport.setAdapter(new FragmentStateAdapter(this) {

            @NonNull
            @Override
            public Fragment createFragment(int position) {
                if (position == 0) {
                    return new HomeOutdoorRunningFragment();
                } else {
                    return new HomeIndoorRunningFragment();

                }

            }

            @Override
            public int getItemCount() {
                return 2;
            }
        });
        mSportsBinding.vp2Sport.registerOnPageChangeCallback(new ViewPager2.OnPageChangeCallback() {
            @Override
            public void onPageScrolled(int position, float positionOffset, int positionOffsetPixels) {
                super.onPageScrolled(position, positionOffset, positionOffsetPixels);
                mSportsBinding.tlSport.setScrollPosition(position, positionOffset, positionOffset > 0.7);
            }

            @Override
            public void onPageSelected(int position) {
                mSportsBinding.tlSport.selectTab(mSportsBinding.tlSport.getTabAt(position));
            }
        });
//        replaceFragment(R.id.fl_sport, HomeOutdoorRunningFragment.class.getCanonicalName(), null);
        mSportsBinding.tlSport.addOnTabSelectedListener(new TabLayout.OnTabSelectedListener() {
            @Override
            public void onTabSelected(TabLayout.Tab tab) {
                mSportsBinding.vp2Sport.setCurrentItem(tab.getPosition());
//                replaceFragment(R.id.fl_sport,
//                        tab.getPosition() == 0 ? HomeOutdoorRunningFragment.class.getCanonicalName() : HomeIndoorRunningFragment.class.getCanonicalName()
//                        , null);
            }

            @Override
            public void onTabUnselected(TabLayout.Tab tab) {

            }

            @Override
            public void onTabReselected(TabLayout.Tab tab) {

            }
        });
        return mSportsBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onDestroy() {
        super.onDestroy();
        mSportsBinding = null;
    }
}