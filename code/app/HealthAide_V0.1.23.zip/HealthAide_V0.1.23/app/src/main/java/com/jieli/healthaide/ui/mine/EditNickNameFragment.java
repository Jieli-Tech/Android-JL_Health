package com.jieli.healthaide.ui.mine;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentEditNicknameBinding;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.jl_health_http.model.UserInfo;
import com.jieli.jl_health_http.model.param.UpdateUserInfoParam;
import com.jieli.jl_health_http.model.response.UserInfoResponse;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/10/21 2:18 PM
 * @desc :
 */
public class EditNickNameFragment extends BaseFragment {
    FragmentEditNicknameBinding binding;

    UserInfoViewModel viewModel;
    private WaitingDialog waitingDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        binding = FragmentEditNicknameBinding.inflate(inflater, container, false);
        binding.layoutTopbar.tvTopbarTitle.setText(R.string.nickname);
        binding.layoutTopbar.tvTopbarLeft.setText(R.string.cancel);
        binding.layoutTopbar.tvTopbarLeft.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
        binding.layoutTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        binding.layoutTopbar.tvTopbarLeft.setTextColor(getResources().getColor(R.color.auxiliary_widget));

        binding.layoutTopbar.tvTopbarRight.setTextColor(getResources().getColor(R.color.auxiliary_widget));
        binding.layoutTopbar.tvTopbarRight.setVisibility(View.VISIBLE);
        binding.layoutTopbar.tvTopbarRight.setOnClickListener(v -> saveUserInfo());

        binding.layoutTopbar.tvTopbarRight.setText(R.string.save);

        return binding.getRoot();
    }

    private void saveUserInfo() {
        String nickName = binding.tietNickname.getText().toString().trim();
        if (TextUtils.isEmpty(nickName)) {
            ToastUtil.showToastShort(R.string.tip_nickname_null);
            return;
        }
        UserInfo data = viewModel.copyUserInfo();
        data.setNickname(nickName);
        viewModel.updateUserInfo(data);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        viewModel = new ViewModelProvider(this).get(UserInfoViewModel.class);
        viewModel.userInfoLiveData.observe(getViewLifecycleOwner(), data -> binding.tietNickname.setText(data.getNickname()));
        viewModel.httpStateLiveData.observe(getViewLifecycleOwner(), state -> {
            switch (state){
                case UserInfoViewModel.HTTP_STATE_UPDATING:
                    if(waitingDialog == null){
                        waitingDialog = new WaitingDialog();
                    }
                    waitingDialog.show(getChildFragmentManager(),waitingDialog.getClass().getCanonicalName());
                    break;
                case UserInfoViewModel.HTTP_STATE_UPDATED_FINISH:
                    requireActivity().finish();
                case UserInfoViewModel.HTTP_STATE_UPDATED_ERROR:
                    if(waitingDialog != null){
                        waitingDialog.dismiss();
                    }
                    break;
            }
        });
        viewModel.getUserInfo();
    }
}
