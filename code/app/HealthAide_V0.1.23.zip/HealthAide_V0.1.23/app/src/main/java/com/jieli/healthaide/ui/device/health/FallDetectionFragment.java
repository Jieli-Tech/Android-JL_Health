package com.jieli.healthaide.ui.device.health;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentFallDetectionBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.jl_rcsp.model.device.health.FallDetection;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/10/25
 * @desc :
 */
public class FallDetectionFragment extends BaseHealthSettingFragment implements View.OnClickListener {
    FragmentFallDetectionBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_fall_detection, container, false);
        binding = FragmentFallDetectionBinding.bind(root);
        root.findViewById(R.id.tv_topbar_left).setOnClickListener(v -> requireActivity().onBackPressed());
        ((TextView) root.findViewById(R.id.tv_topbar_title)).setText(R.string.fall_detection);
        binding.swFallDetection.setOnCheckedChangeListener((buttonView, isChecked) -> {
            FallDetection fallDetection = viewModel.getHealthSettingInfo().getFallDetection();
            fallDetection.setEnable(isChecked);
            viewModel.sendSettingCmd(fallDetection);
        });

        binding.tvModeBright.setOnClickListener(this);
        binding.tvModeShake.setOnClickListener(this);
        binding.tvModeCall.setOnClickListener(this);
        binding.tvModeBright.setTag(FallDetection.MODE_BRIGHT);
        binding.tvModeShake.setTag(FallDetection.MODE_SHAKE);
        binding.tvModeCall.setTag(FallDetection.MODE_CALL);

        binding.clEmergencyContact.setOnClickListener(v -> ContentActivity.startContentActivity(requireContext(), EmergencyContactSettingFragment.class.getCanonicalName()));

        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
         viewModel.healthSettingInfoLiveData().observe(getViewLifecycleOwner(), healthSettingInfo -> {
            FallDetection fallDetection = healthSettingInfo.getFallDetection();
            binding.swFallDetection.setCheckedImmediatelyNoEvent(fallDetection.isEnable());
            binding.tvModeBright.setCompoundDrawablesWithIntrinsicBounds(0, 0, fallDetection.isEnable() && fallDetection.getMode() == 0x00 ? R.drawable.ic_choose_blue : 0, 0);
            binding.tvModeShake.setCompoundDrawablesWithIntrinsicBounds(0, 0, fallDetection.isEnable() && fallDetection.getMode() == 0x01 ? R.drawable.ic_choose_blue : 0, 0);
            binding.tvModeCall.setCompoundDrawablesWithIntrinsicBounds(0, 0, fallDetection.isEnable() && fallDetection.getMode() == 0x02 ? R.drawable.ic_choose_blue : 0, 0);

            binding.tvModeBright.setClickable(fallDetection.isEnable());
            binding.tvModeShake.setClickable(fallDetection.isEnable());
            binding.tvModeCall.setClickable(fallDetection.isEnable());

            binding.tvModeBright.setAlpha(fallDetection.isEnable() ? 1.0f : 0.4f);
            binding.tvModeShake.setAlpha(fallDetection.isEnable() ? 1.0f : 0.4f);
            binding.tvModeCall.setAlpha(fallDetection.isEnable() ? 1.0f : 0.4f);



            binding.clEmergencyContact.setAlpha(fallDetection.isEnable() && fallDetection.getMode() == 0x02 ? 1.0f : 0.4f);
            binding.clEmergencyContact.setClickable(fallDetection.isEnable() && fallDetection.getMode() == 0x02);

            String contact = fallDetection.getContact();
            if (TextUtils.isEmpty(contact)) {
                contact = getString(R.string.no_setting);
            }
            binding.tvEmergencyContact.setText(contact);

        });
    }

    @Override
    public void onClick(View v) {
        byte status = (byte) v.getTag();
        FallDetection fallDetection = viewModel.getHealthSettingInfo().getFallDetection();
        fallDetection.setMode( status);
        viewModel.sendSettingCmd(fallDetection);
    }
}
