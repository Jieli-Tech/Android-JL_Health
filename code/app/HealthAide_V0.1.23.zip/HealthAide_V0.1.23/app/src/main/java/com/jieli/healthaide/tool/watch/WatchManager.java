package com.jieli.healthaide.tool.watch;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;

import com.jieli.bluetooth_connect.bean.history.HistoryRecord;
import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.constant.JL_DeviceType;
import com.jieli.bluetooth_connect.data.HistoryRecordDbHelper;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.utils.FileUtil;
import com.jieli.healthaide.BuildConfig;
import com.jieli.healthaide.tool.bluetooth.BluetoothEventListener;
import com.jieli.healthaide.tool.bluetooth.BluetoothHelper;
import com.jieli.healthaide.tool.watch.synctask.SyncTaskManager;
import com.jieli.healthaide.tool.watch.synctask.WatchListSyncTask;
import com.jieli.healthaide.ui.device.bean.WatchInfo;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.healthaide.util.HealthUtil;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.interfaces.OnFatFileProgressListener;
import com.jieli.jl_fatfs.model.FatFile;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.impl.WatchOpImpl;
import com.jieli.jl_rcsp.interfaces.rcsp.RcspCommandCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.base.CommandBase;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.response.ExternalFlashMsgResponse;
import com.jieli.jl_rcsp.tool.DeviceStatusManager;
import com.jieli.jl_rcsp.util.JL_Log;

import java.io.File;
import java.util.ArrayList;

/**
 * 手表管理类
 *
 * @author zqjasonZhong
 * @since 2021/3/8
 */
public class WatchManager extends WatchOpImpl {
    private final static String TAG = HealthConstant.WATCH_TAG;//WatchManager.class.getSimpleName();
    private volatile static WatchManager instance;

    private final BluetoothHelper mBluetoothHelper = BluetoothHelper.getInstance();
    private final DeviceStatusManager mStatusManager = DeviceStatusManager.getInstance();
    private final HistoryRecordDbHelper mHistoryRecordDbHelper;

    private BluetoothDevice mTargetDevice;
    private GetWatchMsgTask mGetWatchMsgTask;

    //表盘信息列表
    public final ArrayList<WatchInfo> watchInfoList = new ArrayList<>();
    public ArrayList<FatFile> devFatFileList;

    public final static int ERR_OVER_LIMIT = 99;

    private WatchManager(int func) {
        super(func);
        mHistoryRecordDbHelper = mBluetoothHelper.getBluetoothOp().getHistoryRecordHelper();
        mBluetoothHelper.addBluetoothEventListener(mEventListener);

        if (mBluetoothHelper.isConnectedDevice()) {
            setTargetDevice(mBluetoothHelper.getConnectedBtDevice());
        }

        registerOnWatchCallback(mOnWatchCallback);
        registerOnWatchCallback(new AlarmHandleTask(this));
    }

    public static WatchManager getInstance() {
        if (null == instance) {
            synchronized (WatchManager.class) {
                if (null == instance) {
                    instance = new WatchManager(FUNC_WATCH);
                }
            }
        }
        return instance;
    }

    public boolean isConnected() {
        return getConnectedDevice() != null && isWatchSystemInit(getConnectedDevice());
    }

    public boolean isWatchSystemInit(BluetoothDevice device) {
        if (null == device) return false;
        return BluetoothUtil.deviceEquals(getConnectedDevice(), device) && isWatchSystemOk();
    }

    public BluetoothHelper getBluetoothHelper() {
        return mBluetoothHelper;
    }

    public boolean isBleChangeSpp() {
        return mBluetoothHelper.isBleChangeSpp(getConnectedDevice());
    }

    @Override
    public BluetoothDevice getConnectedDevice() {
//        JL_Log.w(TAG, "-getConnectedDevice- " + BluetoothUtil.printBtDeviceInfo(mTargetDevice));
        return mTargetDevice;
    }

    @Override
    public boolean sendDataToDevice(BluetoothDevice device, byte[] data) {
        return mBluetoothHelper.sendDataToDevice(device, data);
    }

    public void sendCommandAsync(CommandBase command, int timeout, RcspCommandCallback callback) {
        sendRcspCommand(getConnectedDevice(), command, timeout, callback);
    }

    @Override
    public void release() {
        super.release();
        unregisterOnWatchCallback(mOnWatchCallback);
        mBluetoothHelper.removeBluetoothEventListener(mEventListener);
        watchInfoList.clear();
        if (null != mGetWatchMsgTask) {
            mGetWatchMsgTask.interrupt();
            mGetWatchMsgTask = null;
        }
        mTargetDevice = null;
        instance = null;
    }

    public void listWatchFileList(final OnWatchOpCallback<ArrayList<WatchInfo>> callback) {
        if (watchInfoList.isEmpty()) {
            SyncTaskManager.getInstance().addTask(new WatchListSyncTask(callback, SyncTaskManager.getInstance()));
        } else {
            if (callback != null) callback.onSuccess(watchInfoList);
        }
    }

    public void updateWatchFileListByDevice(final OnWatchOpCallback<ArrayList<WatchInfo>> callback) {
        watchInfoList.clear();
        listWatchFileList(callback);
    }

    public void getCurrentWatchMsg(final OnWatchOpCallback<WatchInfo> callback) {
        listWatchFileList(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
            @Override
            public void onSuccess(ArrayList<WatchInfo> result) {
                if (!result.isEmpty()) {
                    getCurrentWatchInfo(new OnWatchOpCallback<FatFile>() {
                        @Override
                        public void onSuccess(FatFile result) {
                            JL_Log.d(TAG, "-getCurrentWatchMsg- result = " + result);
                            WatchInfo info = getWatchInfoByFatFile(result);
                            if (info != null) {
                                if (callback != null) callback.onSuccess(info);
                            } else {
                                if (callback != null)
                                    callback.onFailed(new BaseError(FatFsErrCode.RES_ERR_PARAM, "not found watch info."));
                            }
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            if (callback != null) callback.onFailed(error);
                        }
                    });
                } else {
                    if (callback != null)
                        callback.onFailed(new BaseError(FatFsErrCode.RES_ERR_PARAM, "not found watch info."));
                }
            }

            @Override
            public void onFailed(BaseError error) {
                if (callback != null) callback.onFailed(error);
            }
        });
    }

    public void enableWatchCustomBg(final String fatFilePath, final OnWatchOpCallback<FatFile> callback) {
        enableCustomWatchBg(fatFilePath, new OnWatchOpCallback<FatFile>() {
            @Override
            public void onSuccess(FatFile result) {
                final FatFile custom = result;
                getCurrentWatchMsg(new OnWatchOpCallback<WatchInfo>() {
                    @Override
                    public void onSuccess(WatchInfo result) {
                        result.setCustomBgFatPath(fatFilePath);
                        JL_Log.d(TAG, "-enableWatchCustomBg- result = " + result);
                        if (callback != null) callback.onSuccess(custom);
                    }

                    @Override
                    public void onFailed(BaseError error) {
                        if (callback != null) callback.onFailed(error);
                    }
                });
            }

            @Override
            public void onFailed(BaseError error) {
                if (callback != null) callback.onFailed(error);
            }
        });
    }

    public void deleteWatch(final WatchInfo info, final OnFatFileProgressListener listener) {
        if (null == info || null == info.getWatchFile()) return;
        JL_Log.d(TAG, "-deleteWatch- info = " + info.toString());
        if (info.hasCustomBgFatPath()) { //有自定义背景，先删除自定义背景，再删除表盘文件
            JL_Log.w(TAG, "-deleteWatch- CustomBgFatPath = " + info.getCustomBgFatPath());
            deleteWatchFile(info.getCustomBgFatPath(), new OnFatFileProgressListener() {
                @Override
                public void onStart(String filePath) {
                    JL_Log.i(TAG, "-deleteWatch- onStart = " + filePath);
                    if (listener != null) listener.onStart(info.getWatchFile().getPath());
                }

                @Override
                public void onProgress(float progress) {
                    float cProgress = progress * 100 / 200f;
                    JL_Log.d(TAG, "-deleteWatch- onProgress = " + cProgress);
                    if (listener != null) listener.onProgress(cProgress);
                }

                @Override
                public void onStop(int result) {
                    JL_Log.i(TAG, "-deleteWatch- onStop = " + result);
                    if (result == FatFsErrCode.RES_OK) {
                        JL_Log.d(TAG, "-deleteWatch- deleteWatchFile = " + info.getWatchFile().getPath());
                        deleteWatchFile(info.getWatchFile().getPath(), new OnFatFileProgressListener() {
                            @Override
                            public void onStart(String filePath) {
                                JL_Log.i(TAG, "-deleteWatch- onStart = " + filePath);
                            }

                            @Override
                            public void onProgress(float progress) {
                                float cProgress = (progress + 100) * 100 / 200f;
                                JL_Log.d(TAG, "-deleteWatch- onProgress = " + cProgress);
                                if (listener != null) listener.onProgress(cProgress);
                            }

                            @Override
                            public void onStop(int result) {
                                JL_Log.w(TAG, "-deleteWatch- onStop = " + result);
                                final int deleteResult = result;
                                updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                                    @Override
                                    public void onSuccess(ArrayList<WatchInfo> result) {
                                        if (listener != null) listener.onStop(deleteResult);
                                    }

                                    @Override
                                    public void onFailed(BaseError error) {
                                        if (listener != null)
                                            listener.onStop(FatFsErrCode.RES_RCSP_SEND);
                                    }
                                });
                            }
                        });
                    } else {
                        if (listener != null) listener.onStop(result);
                    }
                }
            });
            return;
        }
        JL_Log.d(TAG, "-deleteWatch- 111 deleteWatchFile = " + info.getWatchFile().getPath());
        deleteWatchFile(info.getWatchFile().getPath(), new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                JL_Log.i(TAG, "-deleteWatch- 111 onStart = " + filePath);
                if (listener != null) listener.onStart(filePath);
            }

            @Override
            public void onProgress(float progress) {
                JL_Log.d(TAG, "-deleteWatch-111  onProgress = " + progress);
                if (listener != null) listener.onProgress(progress);
            }

            @Override
            public void onStop(int result) {
                JL_Log.w(TAG, "-deleteWatch- 111 onStop = " + result);
                if (result == FatFsErrCode.RES_OK) {
                    updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                        @Override
                        public void onSuccess(ArrayList<WatchInfo> result) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_OK);
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_RCSP_SEND);
                        }
                    });
                } else {
                    if (listener != null) listener.onStop(result);
                }
            }
        });
    }

    public void addFatFile(final String filePath, final boolean isNoNeedCheck, final OnFatFileProgressListener listener) {
        if (watchInfoList.size() >= HealthConstant.WATCH_MAX_COUNT) {
            if (null != listener) listener.onStop(ERR_OVER_LIMIT);
            return;
        }
        createWatchFile(filePath, isNoNeedCheck, new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                if (listener != null) listener.onStart(filePath);
            }

            @Override
            public void onProgress(float progress) {
                if (listener != null) listener.onProgress(progress);
            }

            @Override
            public void onStop(int result) {
                if (result == FatFsErrCode.RES_OK) {
                    if (!BuildConfig.DEBUG) {
                        FileUtil.deleteFile(new File(filePath));
                    }
                    updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                        @Override
                        public void onSuccess(ArrayList<WatchInfo> result) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_OK);
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            if (listener != null) listener.onStop(FatFsErrCode.RES_RCSP_SEND);
                        }
                    });
                } else {
                    if (listener != null) listener.onStop(result);
                }
            }
        });
    }

    public DeviceInfo getDeviceInfo(BluetoothDevice device) {
        return mStatusManager.getDeviceInfo(device);
    }

    public ExternalFlashMsgResponse getExternalFlashMsg(BluetoothDevice device) {
        return mStatusManager.getExtFlashMsg(device);
    }

    private void setTargetDevice(BluetoothDevice device) {
        if (!BluetoothUtil.deviceEquals(device, mTargetDevice)) {
            mTargetDevice = device;
            BluetoothDevice connectedDevice = getTargetDevice();
            JL_Log.i(TAG, "-setTargetDevice- device = " + BluetoothUtil.printBtDeviceInfo(device)
                    + ", connectedDevice = " + BluetoothUtil.printBtDeviceInfo(connectedDevice));
            if (device != null) {
                notifyBtDeviceConnection(device, StateCode.CONNECTION_OK);
            }
        }
    }

    private void updateHistoryRecordMsg(BluetoothDevice device) {
        if (!mBluetoothHelper.isConnectedBtDevice(device)) return;
        DeviceInfo deviceInfo = mStatusManager.getDeviceInfo(device);
        if (deviceInfo == null) return;
        int connectWay = mBluetoothHelper.getBluetoothOp().isConnectedSppDevice(device) ? BluetoothConstant.PROTOCOL_TYPE_SPP : BluetoothConstant.PROTOCOL_TYPE_BLE;
        boolean isBLEChangeSPP = mBluetoothHelper.isBleToSpp(device) || deviceInfo.isBLEToSppWay();
        if (isBLEChangeSPP) {
            HistoryRecord record = mHistoryRecordDbHelper.getHistoryRecordByMac(device.getAddress());
            if(record != null){
                JL_Log.e(TAG, "updateHistoryRecordMsg : change device type: 5" );
                record.setDevType(JL_DeviceType.JL_DEVICE_TYPE_WATCH);
                mHistoryRecordDbHelper.updateHistoryRecord(record);
            }
        }
        String mappedAddress;
        if (connectWay == BluetoothConstant.PROTOCOL_TYPE_SPP) {
            mappedAddress = deviceInfo.getBleAddr();
        } else {
            mappedAddress = deviceInfo.getEdrAddr();
        }
        if (BluetoothAdapter.checkBluetoothAddress(mappedAddress)) {
            mHistoryRecordDbHelper.updateDeviceInfo(device, deviceInfo.getSdkType(), mappedAddress);
        }
        if (deviceInfo.getVid() != 0 || deviceInfo.getPid() != 0) {
            mHistoryRecordDbHelper.updateDeviceIDs(device, deviceInfo.getVid(), deviceInfo.getVid(), deviceInfo.getPid());
        }
    }

    public ArrayList<FatFile> getWatchList(ArrayList<FatFile> list) {
        if (null == list) return new ArrayList<>();
        ArrayList<FatFile> result = new ArrayList<>();
        for (FatFile watchFile : list) {
            if (watchFile.getName().startsWith("WATCH") || watchFile.getName().startsWith("watch")) {
                result.add(watchFile);
            }
        }
        return result;
    }

    public WatchInfo getWatchInfoByFatFile(FatFile watchFile) {
        if (watchFile == null || watchInfoList.isEmpty()) return null;
        WatchInfo result = null;
        for (WatchInfo watchInfo : watchInfoList) {
            JL_Log.d(TAG, "-getWatchInfoByList- watchInfo = " + watchInfo + ", target = " + watchFile);
            if (watchFile.getPath() != null && watchFile.getPath().equals(watchInfo.getWatchFile().getPath())) {
                result = watchInfo;
                break;
            }
        }
        return result;
    }

    public WatchInfo getWatchInfoByPath(String fatFilePath) {
        if (null == fatFilePath || null == devFatFileList || devFatFileList.isEmpty()) return null;
        FatFile watchFile = null;
        for (FatFile file : devFatFileList) {
            if (fatFilePath.toUpperCase().equals(file.getPath())) {
                watchFile = file;
                break;
            }
        }
        return getWatchInfoByFatFile(watchFile);
    }

    private final BluetoothEventListener mEventListener = new BluetoothEventListener() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            status = HealthUtil.convertWatchConnectStatus(status);
            switch (status) {
                case StateCode.CONNECTION_OK:
                    setTargetDevice(device);
                    break;
                case StateCode.CONNECTION_CONNECTING:
                    notifyBtDeviceConnection(device, status);
                    break;
                case StateCode.CONNECTION_FAILED:
                case StateCode.CONNECTION_DISCONNECT:
                    if(getTargetDevice() == null || BluetoothUtil.deviceEquals(getTargetDevice(), device)){
                        setTargetDevice(null);
                        watchInfoList.clear();
                        notifyBtDeviceConnection(device, status);
                    }
                    break;
            }
        }

        @Override
        public void onReceiveData(BluetoothDevice device, byte[] data) {
            if (BluetoothUtil.deviceEquals(device, getConnectedDevice())) {
                notifyReceiveDeviceData(device, data);
            }
        }

        @Override
        public void onSwitchConnectedDevice(BluetoothDevice device) {
            if (device != null) {
                setTargetDevice(device);
            }
        }
    };

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {

        @Override
        public void onRcspInit(BluetoothDevice device, boolean isInit) {
            if (isInit) {
                updateHistoryRecordMsg(device);
            } else {
                mBluetoothHelper.disconnectDevice(device);
            }
        }

        @Override
        public void onMandatoryUpgrade(BluetoothDevice device) {
            updateHistoryRecordMsg(device);
        }

        @Override
        public void onWatchSystemInit(int code) {
            if (code == 0 && !HealthConstant.ONLY_CONNECT_BLE) {
                BluetoothDevice connectedDevice = getConnectedDevice();
                boolean isBleChangeSpp = mBluetoothHelper.getBluetoothOp().isConnectedBLEDevice(connectedDevice);
                if (isBleChangeSpp) {
                    DeviceInfo deviceInfo = getDeviceInfo(connectedDevice);
                    isBleChangeSpp = (deviceInfo.getEdrProfile() & 0x80) > 0; //优先使用SPP
                }
                if (isBleChangeSpp) {
                    // TODO: 2022/4/19 增加检测是否需要BLE切换SPP流程
                    mBluetoothHelper.bleChangeSpp(WatchManager.this, connectedDevice);
                    return;
                }
                mBluetoothHelper.syncEdrConnectionStatus(getConnectedDevice(), getDeviceInfo(getConnectedDevice()));
            }
        }
    };
}
