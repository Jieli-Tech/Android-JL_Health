package com.jieli.healthaide.ui.device.more;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentMoreBinding;
import com.jieli.healthaide.tool.notification.NotificationHelper;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.device.health.BaseHealthSettingFragment;
import com.jieli.jl_dialog.Jl_Dialog;
import com.jieli.jl_rcsp.constant.AttrAndFunCode;
import com.jieli.jl_rcsp.model.device.health.DisconnectReminder;
import com.jieli.jl_rcsp.model.device.health.LiftWristDetection;

import org.jetbrains.annotations.NotNull;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/7/26
 * @desc :
 */
public class MoreFragment extends BaseHealthSettingFragment {

    FragmentMoreBinding binding;

    static final int REQUEST_CODE_NOTIFICATION = 6514;

    @Nullable
    @org.jetbrains.annotations.Nullable
    @Override
    public View onCreateView(@NonNull @NotNull LayoutInflater inflater, @Nullable @org.jetbrains.annotations.Nullable ViewGroup container, @Nullable @org.jetbrains.annotations.Nullable Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_more, container, false);
        binding = FragmentMoreBinding.bind(root);

        binding.viewTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        binding.viewTopbar.tvTopbarTitle.setText(R.string.more);


        binding.tvAlert.setOnClickListener(v -> {
            if (!NotificationHelper.isNotificationServiceEnabled(requireContext())) {
                showEnableNotificationListenerDialog();
            } else {
                ContentActivity.startContentActivity(requireContext(), MessageSyncFragment.class.getCanonicalName());
            }
        });

        binding.swWeatherPush.setOnCheckedChangeListener((buttonView, isChecked) -> {

        });

        binding.twBtDisconnectTip.setOnCheckedChangeListener((buttonView, isChecked) -> {
            DisconnectReminder disconnectReminder = viewModel.getHealthSettingInfo().getDisconnectReminder();
            disconnectReminder.setEnable(isChecked);
            viewModel.sendSettingCmd(disconnectReminder);

        });

        binding.clBrightScreen.setOnClickListener(v -> ContentActivity.startContentActivity(requireContext(), LiftWristDetectionFragment.class.getCanonicalName()));


        binding.tvSensorSetting.setOnClickListener(v -> {
            ContentActivity.startContentActivity(requireContext(), SensorSettingFragment.class.getCanonicalName());
        });


        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        viewModel.requestHealthSettingInfo(0x01 << AttrAndFunCode.HEALTH_SETTING_TYPE_LIFT_WRIST_DETECTION
                | 0x01 << AttrAndFunCode.HEALTH_SETTING_TYPE_DISCONNECT_REMINDER);
        viewModel.healthSettingInfoLiveData().observe(getViewLifecycleOwner(), healthSettingInfo -> {
            LiftWristDetection liftWristDetection = healthSettingInfo.getLiftWristDetection();
//            binding.twBrightScreen.setCheckedNoEvent(liftWristDetection.isEnable());
            DisconnectReminder disconnectReminder = healthSettingInfo.getDisconnectReminder();
            binding.twBtDisconnectTip.setCheckedNoEvent(disconnectReminder.isEnable());
            String[] statusString = getResources().getStringArray(R.array.sw_status_string_array);
            binding.tvLiftWristDetectionValue.setText(statusString[liftWristDetection.getStatus()]);
        });
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        if (requestCode == REQUEST_CODE_NOTIFICATION && NotificationHelper.isNotificationServiceEnabled(requireContext())) {
            ContentActivity.startContentActivity(requireContext(), MessageSyncFragment.class.getCanonicalName());
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    private void showEnableNotificationListenerDialog() {
        if (isDetached() || !isAdded()) return;
        Jl_Dialog.builder()
                .width(0.8f)
                .cancel(true)
                .content(getString(R.string.enable_notification_listener_service_tips))
                .left(getString(R.string.cancel))
                .leftColor(getResources().getColor(R.color.black))
                .leftClickListener((view, dialogFragment) -> dialogFragment.dismiss())
                .right(getString(R.string.confirm))
                .rightColor(getResources().getColor(R.color.red_D25454))
                .rightClickListener((view, dialogFragment) -> {
                    dialogFragment.dismiss();
                    startActivityForResult(new Intent(NotificationHelper.ACTION_NOTIFICATION_LISTENER_SETTINGS), REQUEST_CODE_NOTIFICATION);
                })
                .build()
                .show(getChildFragmentManager(), "notification_listener_service");
    }
}
