package com.jieli.healthaide.ui.sports.ui;

import android.animation.Animator;
import android.animation.ValueAnimator;
import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioManager;
import android.media.SoundPool;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.LinearInterpolator;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.data.entity.SportRecord;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.jl_rcsp.impl.HealthOpImpl;
import com.jieli.jl_rcsp.interfaces.OnOperationCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 4/6/21
 * @desc :
 */
public class SportsCountdownFragment extends BaseFragment {

    private ValueAnimator valueAnimator;


    public static void startByOutdoorRunning(Context context) {
        Bundle bundle = new Bundle();
        bundle.putInt(RunningParentFragment.KEY_RUNNING_TYPE, SportRecord.TYPE_OUTDOOR);
        ContentActivity.startContentActivity(context, SportsCountdownFragment.class.getCanonicalName(), bundle);
    }

    public static void startByIndoorRunning(Context context) {
        Bundle bundle = new Bundle();
        bundle.putInt(RunningParentFragment.KEY_RUNNING_TYPE, SportRecord.TYPE_INDOOR);
        ContentActivity.startContentActivity(context, SportsCountdownFragment.class.getCanonicalName(), bundle);
    }


    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        container.setBackgroundColor(getResources().getColor(R.color.main_color));

        ImageView imageView = new ImageView(requireContext());
        ConstraintLayout.LayoutParams params = new ConstraintLayout.LayoutParams(ViewGroup.LayoutParams.WRAP_CONTENT, ViewGroup.LayoutParams.WRAP_CONTENT);
        params.startToStart = ConstraintLayout.LayoutParams.PARENT_ID;
        params.topToTop = ConstraintLayout.LayoutParams.PARENT_ID;
        params.bottomToBottom = ConstraintLayout.LayoutParams.PARENT_ID;
        params.endToEnd = ConstraintLayout.LayoutParams.PARENT_ID;
        imageView.setLayoutParams(params);
        imageView.setScaleType(ImageView.ScaleType.FIT_CENTER);
        int[] res = new int[]{
                R.drawable.nub_3,
                R.drawable.nub_2,
                R.drawable.nub_1,
                R.drawable.nub_0,
        };
        int[] audios = new int[]{
                R.raw.num_3,
                R.raw.num_2,
                R.raw.num_1,
                R.raw.go
        };
        int[] ids = new int[4];
        SoundPool soundPool = new SoundPool.Builder()
                .setMaxStreams(4)
                .setAudioAttributes(
                        new AudioAttributes.Builder()
                                .setLegacyStreamType(AudioManager.STREAM_RING)
                                .build())
                .build();
        for (int i = 0; i < audios.length; i++) {
            ids[i] = soundPool.load(getContext(), audios[i], 1);
        }

        valueAnimator = ValueAnimator.ofFloat(0, 3.99f);
        valueAnimator.setInterpolator(new LinearInterpolator());
        valueAnimator.setDuration(4000);
        InnerAnimationListener listener = new InnerAnimationListener() {
            private int index = -1;

            @Override
            public void onAnimationUpdate(ValueAnimator animation) {
                int tmp = (int) ((float) animation.getAnimatedValue());
                if (tmp != index) {
                    index = tmp;
                    imageView.setImageResource(res[index]);
                    soundPool.play(ids[index], 1.0F, 1.0F, 1, 0, 1.0F);
                }
                float scale = (float) (animation.getAnimatedValue()) - index;
                imageView.setScaleX(scale);
                imageView.setScaleY(scale);
            }

            @Override
            public void onAnimationEnd(Animator animation) {
                super.onAnimationEnd(animation);
                soundPool.release();
                doAfterAnimation();

            }
        };


        valueAnimator.addUpdateListener(listener);
        valueAnimator.addListener(listener);
        soundPool.setOnLoadCompleteListener((soundPool1, sampleId, status) -> {
            if (valueAnimator.isStarted()) return;
            valueAnimator.start();
        });
        return imageView;
    }

    @Override
    public void onPause() {
        super.onPause();
        valueAnimator.pause();
    }

    @Override
    public void onResume() {
        super.onResume();
        valueAnimator.resume();
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        valueAnimator.cancel();
    }

    private void doAfterAnimation() {
        final Bundle args = getArguments();
        HealthOpImpl healthOp = new HealthOpImpl(WatchManager.getInstance());
        healthOp.startSports(healthOp.getConnectedDevice(), args.getInt(RunningParentFragment.KEY_RUNNING_TYPE, 0), new OnOperationCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                //进入不同的跑步界面
                if (getActivity() == null) return;
                ContentActivity.startContentActivity(requireContext(), RunningParentFragment.class.getCanonicalName(), args);
                requireActivity().finish();
            }

            @Override
            public void onFailed(BaseError error) {
                JL_Log.w(tag, "发送开始运动命令失败:" + error);
                ToastUtil.showToastShort(R.string.start_sports_failed);
                if (getActivity() != null && !requireActivity().isDestroyed()) {
                    requireActivity().finish();
                }
            }
        });
    }


    private static class InnerAnimationListener implements ValueAnimator.AnimatorUpdateListener, Animator.AnimatorListener {
        private long time;

        @Override
        public void onAnimationStart(Animator animation) {
            time = System.currentTimeMillis();
        }

        @Override
        public void onAnimationEnd(Animator animation) {
            JL_Log.d("sen", "sportsCountdown take time = " + (System.currentTimeMillis() - time));

        }

        @Override
        public void onAnimationCancel(Animator animation) {

        }

        @Override
        public void onAnimationRepeat(Animator animation) {

        }

        @Override
        public void onAnimationUpdate(ValueAnimator animation) {

        }
    }

}
