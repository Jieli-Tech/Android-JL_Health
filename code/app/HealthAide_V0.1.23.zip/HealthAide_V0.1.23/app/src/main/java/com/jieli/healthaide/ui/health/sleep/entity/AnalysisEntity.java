package com.jieli.healthaide.ui.health.sleep.entity;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/4/21 11:48 AM
 * @desc :
 */
public class AnalysisEntity {

    public String title;

    public String reference;

    public String level;
    public int levelColor;

    public int max;
    public int min;
}
