package com.jieli.healthaide.tool.watch.synctask;

import com.jieli.jl_rcsp.constant.AttrAndFunCode;
import com.jieli.jl_rcsp.impl.HealthOpImpl;
import com.jieli.jl_rcsp.interfaces.OnOperationCallback;
import com.jieli.jl_rcsp.model.HealthDataQuery;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @ClassName: RealTimeHealthDataSyncTask
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/11/10 16:52
 */
public class RealTimeHealthDataSyncTask extends DeviceSyncTask {
    private final HealthOpImpl mHealthOp;

    public RealTimeHealthDataSyncTask(SyncTaskFinishListener finishListener) {
        super(finishListener);
        mHealthOp = new HealthOpImpl(mWatchManager);
    }

    @Override
    public void start() {
        int mask = 0x01 << AttrAndFunCode.HEALTH_DATA_TYPE_HEART_RATE | (0x01 << AttrAndFunCode.HEALTH_DATA_TYPE_STEP) | (0x01 << AttrAndFunCode.HEALTH_DATA_TYPE_BLOOD_OXYGEN);
        byte[] subMask = new byte[]{0x01, 0x07, 0x01};
        byte version = 0;
        mHealthOp.readHealthData(mWatchManager.getConnectedDevice(), new HealthDataQuery(version, mask, subMask), new OnOperationCallback<Boolean>() {
            @Override
            public void onSuccess(Boolean result) {
                if (finishListener != null) finishListener.onFinish();
            }

            @Override
            public void onFailed(BaseError error) {
                JL_Log.w("RealTimeHealthDataSyncTask", "onFailed : " + error);
                if (finishListener != null) finishListener.onFinish();
            }
        });
    }
}
