package com.jieli.healthaide.tool.net;

import android.content.Context;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.NetworkInfo;
import android.net.NetworkRequest;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;

import androidx.annotation.NonNull;

import com.jieli.healthaide.HealthApplication;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2020/11/24 2:37 PM
 * @desc :
 */
public class NetworkStateHelper {
    private static NetworkStateHelper instance = new NetworkStateHelper();
    private final String tag = getClass().getSimpleName();
    private final Handler handler = new Handler(Looper.getMainLooper());
    private NetWorkStateModel netWorkStateModel;
    private List<Listener> listeners = new ArrayList<>();
    private TimeOutTask timeOutTask;

    public static NetworkStateHelper getInstance() {
        return instance;
    }

    private NetworkStateHelper() {
        ConnectivityManager cm = (ConnectivityManager) HealthApplication.getAppViewModel().getApplication().getSystemService(Context.CONNECTIVITY_SERVICE);
        checkNetworkIsOpen(cm);
        NetworkRequest request = new NetworkRequest.Builder()
                .addTransportType(NetworkCapabilities.TRANSPORT_WIFI)
                .addTransportType(NetworkCapabilities.TRANSPORT_CELLULAR)
                .addTransportType(NetworkCapabilities.TRANSPORT_VPN)
                .build();

        cm.requestNetwork(request, new ConnectivityManager.NetworkCallback() {
            @Override
            public void onAvailable(@NonNull Network network) {
                super.onAvailable(network);
                if (cm.getNetworkInfo(network) == null) return;
                JL_Log.d(tag, "onAvailable  " + cm.getNetworkInfo(network).getClass() + "\tthread==" + Thread.currentThread().getName());

                int type = cm.getNetworkInfo(network).getType();
                boolean available = checkNetworkIsAvailable("www.baidu.com")
                        || checkNetworkIsAvailable("www.aliyun.com")
                        || checkNetworkIsAvailable("www.qq.com");
                JL_Log.d(tag, "onAvailable  " + type + "\tthread==" + Thread.currentThread().getName() + "\tavailabe=" + available);
                if (cm.getNetworkInfo(network) == null) return;//网络检测的过程中，该网络已失效
                handleState(type, available);
            }


            @Override
            public void onLost(@NonNull Network network) {
                super.onLost(network);
                JL_Log.d(tag, "onLost");
                NetworkInfo networkInfo = cm.getNetworkInfo(network);
                int type = networkInfo == null ? ConnectivityManager.TYPE_MOBILE : networkInfo.getType();
                handleState(type, false);
            }

        });
    }


    public NetWorkStateModel getNetWorkStateModel() {
        return netWorkStateModel;
    }

    public void registerListener(Listener listener) {
        if (listeners.contains(listener)) return;
        if (listeners.add(listener) && null != netWorkStateModel) {
            listener.onNetworkStateChange(netWorkStateModel);
        }
    }

    public void unregisterListener(Listener listener) {
        listeners.remove(listener);
    }

    private void handleState(int type, boolean available) {
        netWorkStateModel = new NetWorkStateModel(type, available);
        handler.post(() -> {
            for (Listener l : new ArrayList<>(listeners)) {
                l.onNetworkStateChange(new NetWorkStateModel(type, available));
            }
        });
    }


    public interface Listener {
        void onNetworkStateChange(NetWorkStateModel model);
    }

    private void checkNetworkIsOpen(ConnectivityManager cm) {
        if (null == cm) return;
        int[] types = new int[]{
                ConnectivityManager.TYPE_MOBILE,
                ConnectivityManager.TYPE_WIFI,
        };
        for (int type : types) {
            NetworkInfo info = cm.getNetworkInfo(type);
            if (info != null) {
                if (info.getState() == NetworkInfo.State.CONNECTED) {
                    handleState(type, info.isConnected());
                    return;
                }
            }
        }
        handleState(-1, false);
    }

    private static class TimeOutTask implements Runnable {
        private Thread thread;


        public void setThread(Thread thread) {
            this.thread = thread;
        }

        @Override
        public void run() {
            thread.interrupt();
        }
    }


    private boolean checkNetworkIsAvailable(String ip) {
        int timeOut = 3000;
        Process process = null;
        boolean ret = false;
        try {
            process = Runtime.getRuntime().exec("/system/bin/ping  -c 1 -w 1000 " + ip);
            long time = new Date().getTime();
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                ret = process.waitFor(timeOut, TimeUnit.MILLISECONDS);
            } else {
                if (timeOutTask == null) {
                    timeOutTask = new TimeOutTask();
                }
                timeOutTask.setThread(Thread.currentThread());
                handler.postDelayed(timeOutTask, timeOut);
                ret = process.waitFor() == 0;
            }
            JL_Log.d(tag, "-checkNetworkIsAvailable-->address=" + ip + "\ttake time=" + (new Date().getTime() - time) + "\tstate:" + ret);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            handler.removeCallbacks(timeOutTask);
            if (process != null) {
                process.destroy();
            }
        }
        return ret;
    }
}
