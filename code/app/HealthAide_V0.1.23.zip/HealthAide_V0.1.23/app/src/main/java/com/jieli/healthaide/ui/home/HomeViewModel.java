package com.jieli.healthaide.ui.home;

import android.bluetooth.BluetoothDevice;

import androidx.lifecycle.MutableLiveData;

import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.healthaide.tool.bluetooth.BluetoothEventListener;
import com.jieli.healthaide.tool.history.HistoryRecordManager;
import com.jieli.healthaide.tool.phone.PhoneHelper;
import com.jieli.healthaide.tool.ring.RingHandler;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.tool.watch.WatchServerCacheHelper;
import com.jieli.healthaide.tool.watch.synctask.SyncTaskManager;
import com.jieli.healthaide.ui.device.BluetoothViewModel;
import com.jieli.healthaide.ui.device.bean.DeviceConnectionData;
import com.jieli.healthaide.ui.device.bean.WatchOpData;
import com.jieli.jl_fatfs.interfaces.OnFatFileProgressListener;
import com.jieli.jl_rcsp.constant.Command;
import com.jieli.jl_rcsp.constant.RcspConstant;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.model.base.CommandBase;
import com.jieli.jl_rcsp.model.command.SearchDevCmd;
import com.jieli.jl_rcsp.model.parameter.SearchDevParam;
import com.jieli.jl_rcsp.util.CommandBuilder;
import com.jieli.jl_rcsp.util.JL_Log;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 主页面逻辑操作
 * @since 2021/3/19
 */
public class HomeViewModel extends BluetoothViewModel {
    private final static String TAG = HomeViewModel.class.getSimpleName();
    private final WatchManager mWatchManager = WatchManager.getInstance();
    public final MutableLiveData<WatchOpData> mWatchRestoreSysMLD = new MutableLiveData<>();
    public final MutableLiveData<BluetoothDevice> mWatchUpdateExceptionMLD = new MutableLiveData<>();
    public final MutableLiveData<BluetoothDevice> mMandatoryUpgradeMLD = new MutableLiveData<>();
    public final MutableLiveData<DeviceConnectionData> mConnectionDataMLD = new MutableLiveData<>();
    public final MutableLiveData<Boolean> mRingPlayStatusMLD = new MutableLiveData<>();

    private final SyncTaskManager mSyncTaskManager;
    private final RingHandler mRingHandler = RingHandler.getInstance();

    public HomeViewModel() {
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
        mSyncTaskManager = SyncTaskManager.getInstance();
        mWatchManager.registerOnRcspCallback(mSyncTaskManager);
        mWatchManager.getBluetoothHelper().addBluetoothEventListener(mEventCallback);
        mRingHandler.registerOnRingStatusListener(mRingPlayStatusMLD::postValue);
    }

    public void destroy() {
        mWatchManager.getBluetoothHelper().removeBluetoothEventListener(mEventCallback);
        mWatchManager.unregisterOnRcspCallback(mSyncTaskManager);
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        mRingHandler.destroy();
        mWatchManager.release();
        mBluetoothHelper.destroy();
        WatchServerCacheHelper.getInstance().destroy();
        HistoryRecordManager.getInstance().release();
        SyncTaskManager.getInstance().destroy();
        PhoneHelper.getInstance().destroy();
    }

    public void stopRing() {
        mRingHandler.stopAlarmRing();
        if (mWatchManager.isWatchSystemOk()) {
            mWatchManager.sendRcspCommand(CommandBuilder.buildSearchDevCmd(RcspConstant.RING_OP_CLOSE, 0), null);
        }
    }

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {

        @Override
        public void onMandatoryUpgrade(BluetoothDevice device) {
            if (isUsingDevice(device)) {
                mMandatoryUpgradeMLD.postValue(device);
            }
        }

        @Override
        public void onWatchSystemException(BluetoothDevice device, int sysStatus) {
            JL_Log.e(TAG, "-onWatchSystemException- device = " + BluetoothUtil.printBtDeviceInfo(device) + ", sysStatus = " + sysStatus);
            if (sysStatus != 0 && isUsingDevice(device)) {
                mWatchManager.restoreWatchSystem(new OnFatFileProgressListener() {
                    @Override
                    public void onStart(String filePath) {
                        WatchOpData watchOpData = new WatchOpData();
                        watchOpData.setOp(WatchOpData.OP_RESTORE_SYS);
                        watchOpData.setState(WatchOpData.STATE_START);
                        watchOpData.setFilePath(filePath);
                        mWatchRestoreSysMLD.setValue(watchOpData);
                    }

                    @Override
                    public void onProgress(float progress) {
                        WatchOpData watchOpData = new WatchOpData();
                        watchOpData.setOp(WatchOpData.OP_RESTORE_SYS);
                        watchOpData.setState(WatchOpData.STATE_PROGRESS);
                        watchOpData.setProgress(progress);
                        mWatchRestoreSysMLD.setValue(watchOpData);
                    }

                    @Override
                    public void onStop(int result) {
                        WatchOpData watchOpData = new WatchOpData();
                        watchOpData.setOp(WatchOpData.OP_RESTORE_SYS);
                        watchOpData.setState(WatchOpData.STATE_END);
                        watchOpData.setResult(result);
                        mWatchRestoreSysMLD.setValue(watchOpData);
                    }
                });
            }
        }

        @Override
        public void onResourceUpdateUnfinished(BluetoothDevice device) {
            JL_Log.e(TAG, "-onResourceUpdateUnfinished- device = " + BluetoothUtil.printBtDeviceInfo(device));
            if (isUsingDevice(device)) {
                mWatchUpdateExceptionMLD.postValue(device);
            }
        }

        @Override
        public void onRcspCommand(BluetoothDevice device, CommandBase command) {
            if (command.getId() == Command.CMD_SEARCH_DEVICE) {//查找设备的处理
                SearchDevCmd searchDevCmd = (SearchDevCmd) command;
                SearchDevParam param = searchDevCmd.getParam();
                if (param != null) {
                    if (param.getOp() == RcspConstant.RING_OP_OPEN) {
                        mRingHandler.playAlarmRing(param.getType(), param.getTimeoutSec() * 1000);
                        mRingPlayStatusMLD.postValue(true);
                    } else {
                        mRingHandler.stopAlarmRing();
                        mRingPlayStatusMLD.postValue(false);
                    }
                }
                searchDevCmd.setStatus(StateCode.STATUS_SUCCESS);
                searchDevCmd.setParam(new SearchDevParam.SearchDevResultParam(0));
                mWatchManager.sendCommandResponse(device, searchDevCmd, null);
            }
        }
    };

    private final BluetoothEventListener mEventCallback = new BluetoothEventListener() {
        @Override
        public void onConnection(BluetoothDevice device, int status) {
            mConnectionDataMLD.setValue(new DeviceConnectionData(device, status));
        }
    };
}
