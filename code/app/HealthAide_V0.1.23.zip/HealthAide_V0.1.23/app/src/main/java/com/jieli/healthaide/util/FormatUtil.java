package com.jieli.healthaide.util;

import android.annotation.SuppressLint;
import android.text.TextUtils;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 格式化工具类
 *
 * @author zqjasonZhong
 * @since 2021/3/3
 */
public class FormatUtil {

    /**
     * 检测是否手机号码
     *
     * @param phoneNumber 手机号码
     * @return 结果
     */
    public static boolean checkPhoneNumber(String phoneNumber) {
        if (null == phoneNumber || phoneNumber.length() != 11) return false;
        Pattern p = Pattern.compile("^1(3\\d{2}|4[14-9]\\d|5([0-35689]\\d|7[1-79])|66\\d|7[2-35-8]\\d|8\\d{2}|9[13589]\\d)\\d{7}$");
        Matcher m = p.matcher(phoneNumber);
        return m.matches();
    }

    /**
     * 格式化时间：yyyy-MM-dd HH:mm:ss
     *
     * @param time 时间戳
     * @return 时间文本
     */
    public static String formatterTime(long time) {
        @SuppressLint("SimpleDateFormat") SimpleDateFormat formater = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return formater.format(new Date(time));
    }

    /**
     * 检测密码是否符合格式
     *
     * @param password 密码
     * @return 结果
     */
    public static boolean checkPassword(String password) {
        if (null == password) return false;
        String regex = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,12}$";
        return password.matches(regex);
    }

    /**
     * 检测验证码是否符合格式
     *
     * @param code 验证码
     * @return 结果
     */
    public static boolean checkSmsCode(String code) {
        if (null == code) return false;
        return code.length() == 6 && TextUtils.isDigitsOnly(code);
    }


    @SuppressLint("DefaultLocale")
    public static String paceFormat(long seconds){
        int min = (int) (seconds/60);
        int sec = (int) (seconds%60);
        return String.format("%02d'%02d\"",min,sec);
    }
}
