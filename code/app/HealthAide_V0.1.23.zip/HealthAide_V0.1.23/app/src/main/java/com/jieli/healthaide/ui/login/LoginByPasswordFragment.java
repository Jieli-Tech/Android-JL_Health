package com.jieli.healthaide.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentLoginByPasswordBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.ui.home.HomeActivity;
import com.jieli.healthaide.ui.login.bean.LoginMsg;
import com.jieli.healthaide.ui.widget.CustomTextWatcher;
import com.jieli.healthaide.util.FormatUtil;
import com.jieli.jl_filebrowse.interfaces.OperatCallback;


/**
 * Des:
 * Author: Bob
 * Date:21-3-2
 * UpdateRemark:
 */
public class LoginByPasswordFragment extends BaseFragment {
    private FragmentLoginByPasswordBinding loginBinding;
    private TextInputEditText etUsername;
    private TextInputEditText etPassword;

    private LoginViewModel loginViewModel;
    private WaitingDialog waitingDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        loginBinding = FragmentLoginByPasswordBinding.inflate(inflater, container, false);
        etUsername = loginBinding.tietUsername;
        etPassword = loginBinding.tietPassword;
        return loginBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        etUsername.addTextChangedListener(usernameTextWatcher);
        etPassword.addTextChangedListener(passwordTextWatcher);
        loginBinding.btnLogin.setOnClickListener(v -> {
            String account = loginBinding.tietUsername.getText().toString().trim();
            String password = loginBinding.tietPassword.getText().toString().trim();
            loginViewModel.loginByAccount(account, password);
        });
        loginBinding.btnRegister.setOnClickListener(v -> toRegisterFragment());
        loginBinding.tvLoginByCode.setOnClickListener(v -> toLoginByCode());
        loginBinding.tvForgotPassword.setOnClickListener(v -> toResetPassword());

        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);
        etUsername.setText(loginViewModel.getCacheInputNumber());

        loginViewModel.loginMsgMutableLiveData.observe(getViewLifecycleOwner(), loginMsg -> {
            switch (loginMsg.getState()) {
                case LoginMsg.STATE_LOGINING:
                    if (waitingDialog == null) {
                        waitingDialog = new WaitingDialog();
                    }
                    waitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getCanonicalName());
                    break;
                case LoginMsg.STATE_LOGIN_FINISH:
                    toHomeActivity();

                case LoginMsg.STATE_IDLE:
                case LoginMsg.STATE_LOGIN_ERROR:
                    if (waitingDialog != null) {
                        waitingDialog.dismiss();
                    }
                    break;
            }

        });
        updateLoginState();
    }

    private final TextWatcher usernameTextWatcher = new CustomTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            if (null == s) return;
            String text = s.toString();
            boolean isUsernameInputting = FormatUtil.checkPhoneNumber(text);
            PreferencesHelper.putStringValue(requireContext(), LoginViewModel.KEY_CACHE_MOBILE, text.trim());

            if (isUsernameInputting) {
                showError(loginBinding.tilUsername, null);
            } else if (text.length() == 0) {
                showError(loginBinding.tilUsername, getString(R.string.phone_tips_empty));
            } else {
                showError(loginBinding.tilUsername, getString(R.string.phone_tips_format_err));
            }
            updateLoginState();
        }
    };

    private final TextWatcher passwordTextWatcher = new CustomTextWatcher() {

        @Override
        public void afterTextChanged(Editable s) {
            if (null == s) return;
            String text = s.toString();
            boolean isPasswordInputting = checkPassword(text);
            if (isPasswordInputting) {
                showError(loginBinding.tilPassword, null);
            } else if (text.length() == 0) {
                showError(loginBinding.tilPassword, getString(R.string.password_tips_empty));
            } else {
                showError(loginBinding.tilPassword, getString(R.string.password_tips_format_err));
            }
            updateLoginState();
        }
    };


    private void updateLoginState() {
        boolean ret = FormatUtil.checkPhoneNumber(loginBinding.tietUsername.getText().toString().trim())
                && checkPassword(loginBinding.tietPassword.getText().toString().trim());
        loginBinding.btnLogin.setEnabled(ret);
    }

    private void showError(TextInputLayout textInputLayout, String error) {
        if (null == textInputLayout) return;
        textInputLayout.setError(error);
    }

    private boolean checkPassword(String password) {
        if (null == password) return false;
        return password.length() >= 6 && password.length() <= 12;
    }

    private void toLoginByCode() {
        BaseActivity baseActivity = (BaseActivity) requireActivity();
        baseActivity.replaceFragment(R.id.launcher_container, LoginByCodeFragment.class.getCanonicalName());
    }

    private void toResetPassword() {
        ContentActivity.startContentActivity(requireContext(), ResetPasswordFragment.class.getCanonicalName());
    }

    private void toRegisterFragment() {
        ContentActivity.startContentActivity(requireContext(), RegisterFragment.class.getCanonicalName());
    }

    private void toHomeActivity() {
        HealthApplication.getAppViewModel().requestProfile(new OperatCallback() {
            @Override
            public void onSuccess() {
                Intent i = new Intent(requireActivity(), HomeActivity.class);
                startActivity(i);
                if (getActivity() != null)
                    requireActivity().finish();
            }

            @Override
            public void onError(int code) {
                ToastUtil.showToastShort(getString(R.string.save_failed));
            }
        });

    }
}
