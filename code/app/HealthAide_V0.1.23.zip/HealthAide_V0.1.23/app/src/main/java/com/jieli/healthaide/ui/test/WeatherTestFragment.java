package com.jieli.healthaide.ui.test;

import android.annotation.SuppressLint;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

import com.amap.api.services.weather.LocalDayWeatherForecast;
import com.amap.api.services.weather.LocalWeatherForecast;
import com.amap.api.services.weather.LocalWeatherForecastResult;
import com.amap.api.services.weather.LocalWeatherLive;
import com.amap.api.services.weather.LocalWeatherLiveResult;
import com.amap.api.services.weather.WeatherSearch;
import com.amap.api.services.weather.WeatherSearchQuery;
import com.google.gson.Gson;
import com.jieli.component.utils.ToastUtil;

import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 4/21/21
 * @desc :
 */
public class WeatherTestFragment extends Fragment {


    @SuppressLint("SetTextI18n")
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {


        LinearLayout linearLayout = new LinearLayout(requireActivity());
        linearLayout.setLayoutParams(new FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        linearLayout.setFitsSystemWindows(true);
        linearLayout.setOrientation(LinearLayout.VERTICAL);


        TextView tvShow = new TextView(requireActivity());
        tvShow.setLayoutParams(new LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
 
        Button getWeatherBtn = new Button(requireActivity());
        linearLayout.addView(getWeatherBtn);
        getWeatherBtn.setText("读取实时天气数据");
        getWeatherBtn.setOnClickListener(v -> {
            WeatherSearchQuery query = new WeatherSearchQuery("珠海市", WeatherSearchQuery.WEATHER_TYPE_LIVE);
            WeatherSearch search = new WeatherSearch(requireContext());
            search.setQuery(query);
            search.setOnWeatherSearchListener(new WeatherSearch.OnWeatherSearchListener() {
                @Override
                public void onWeatherLiveSearched(LocalWeatherLiveResult localWeatherLiveResult, int code) {
                    if (code != 1000) {
                        ToastUtil.showToastShort("获取天气失败");
                        return;
                    }
                    if (localWeatherLiveResult == null || localWeatherLiveResult.getLiveResult() == null) {
                        ToastUtil.showToastShort("没有天气数据");
                        return;
                    }
                    LocalWeatherLive result = localWeatherLiveResult.getLiveResult();
                    StringBuilder sb = new StringBuilder();
                    sb.append("实时天气数据:")
                            .append("\n")
                            .append("省份:").append(result.getProvince()).append("\t\t")
                            .append("城市:").append(result.getCity()).append("\t\t")
                            .append("城市编码:").append(result.getAdCode()).append("\n")
                            .append("天气:").append(result.getWeather()).append("\t\t")
                            .append("温度:").append(result.getTemperature()).append("\t\t")
                            .append("湿度:").append(result.getHumidity()).append("\n")
                            .append("方向:").append(result.getWindDirection()).append("\t\t")
                            .append("风力:").append(result.getWindPower()).append("\n")
                            .append("时间:").append(result.getReportTime())
                    ;
                    sb.append("\n\n");

                    tvShow.append(sb.toString());
                }

                @Override
                public void onWeatherForecastSearched(LocalWeatherForecastResult localWeatherForecastResult, int code) {

                }
            });
            search.searchWeatherAsyn();

        });


        Button getForecastWeatherBtn = new Button(requireActivity());
        linearLayout.addView(getForecastWeatherBtn);
        getForecastWeatherBtn.setText("读取天气预告数据");
        getForecastWeatherBtn.setOnClickListener(v -> {
            WeatherSearchQuery query = new WeatherSearchQuery("珠海市", WeatherSearchQuery.WEATHER_TYPE_FORECAST);
            WeatherSearch search = new WeatherSearch(requireContext());
            search.setQuery(query);
            search.setOnWeatherSearchListener(new WeatherSearch.OnWeatherSearchListener() {
                @Override
                public void onWeatherLiveSearched(LocalWeatherLiveResult localWeatherLiveResult, int code) {
                }

                @Override
                public void onWeatherForecastSearched(LocalWeatherForecastResult localWeatherForecastResult, int code) {
                    if (code != 1000) {
                        ToastUtil.showToastShort("获取天气预告失败");
                        return;
                    }

                    if (localWeatherForecastResult == null || localWeatherForecastResult.getForecastResult() == null) {
                        ToastUtil.showToastShort("没有预告天气数据");
                        return;
                    }

                    LocalWeatherForecast result = localWeatherForecastResult.getForecastResult();
                    StringBuilder sb = new StringBuilder();
                    sb.append("天气预告数据:")
                            .append("\n");
                    List<LocalDayWeatherForecast> list = result.getWeatherForecast();

                    for (LocalDayWeatherForecast data : list) {
                        sb.append("日期:").append(data.getDate()).append("\t\t")
                                .append("星期:")
                                .append(data.getWeek()).append("\n")
                                .append("\t\t白天:").append(data.getDayWeather()).append("\t\t")
                                .append("温度:").append(data.getDayTemp()).append("\t\t")
                                .append("方向:").append(data.getDayWindDirection()).append("\t\t")
                                .append("风力:").append(data.getDayWindPower()).append("\n")

                                .append("\t\t晚上 :").append(data.getNightWeather()).append("\t\t")
                                .append("温度:").append(data.getNightTemp()).append("\t")
                                .append("方向:").append(data.getNightWindDirection()).append("\t\t")
                                .append("风力:").append(data.getNightWindPower()).append("\t\t");

                        sb.append("\n\n");
                    }
                    tvShow.append(sb.toString());
                }
            });
            search.searchWeatherAsyn();
        });

        Button clearBtn = new Button(requireActivity());
        linearLayout.addView(clearBtn);
        clearBtn.setText("清除log");
        clearBtn.setOnClickListener(v -> {
            tvShow.setText("");
        });

        linearLayout.addView(tvShow);
        return linearLayout;
    }
}
