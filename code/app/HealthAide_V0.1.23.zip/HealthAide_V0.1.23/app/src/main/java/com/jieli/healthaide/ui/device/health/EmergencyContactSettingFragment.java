package com.jieli.healthaide.ui.device.health;

import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmemtEmergencyContactSettingBinding;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.device.HealthSettingViewModel;
import com.jieli.healthaide.util.FormatUtil;
import com.jieli.jl_filebrowse.interfaces.OperatCallback;
import com.jieli.jl_rcsp.model.device.health.FallDetection;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/10/26
 * @desc :
 */
public class EmergencyContactSettingFragment extends BaseHealthSettingFragment {

    FragmemtEmergencyContactSettingBinding binding;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {

        View root = inflater.inflate(R.layout.fragmemt_emergency_contact_setting, container, false);
        binding = FragmemtEmergencyContactSettingBinding.bind(root);
        binding.viewTopbar.tvTopbarTitle.setText(R.string.title_emergency_contact);
        binding.viewTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());


        binding.btnEditContact.setOnClickListener(v -> {
            binding.rlShowContact.setVisibility(View.GONE);
            binding.rlEditContact.setVisibility(View.VISIBLE);
            binding.btnSaveContact.setVisibility(View.VISIBLE);
        });

        binding.btnSaveContact.setOnClickListener(v -> {
            FallDetection fallDetection = viewModel.getHealthSettingInfo().getFallDetection();
            EditText editText = binding.etContact;
            String contact = editText.getText().toString().trim();
            if (TextUtils.isEmpty(contact)) {
                ToastUtil.showToastShort(getString(R.string.phone_number_is_empty));
            } else if (!FormatUtil.checkPhoneNumber(contact)) {
                ToastUtil.showToastShort(getString(R.string.phone_tips_format_err));
            } else {
                fallDetection.setContact(contact);
                binding.btnSaveContact.setClickable(false);
                viewModel.sendSettingCmd(fallDetection, new OperatCallback() {
                    @Override
                    public void onSuccess() {
                        binding.btnSaveContact.setClickable(true);
                        if (getActivity() != null) {
                            requireActivity().onBackPressed();
                        }
                    }

                    @Override
                    public void onError(int code) {
                        binding.btnSaveContact.setClickable(true);
                    }
                });
            }

        });


        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        viewModel.healthSettingInfoLiveData().observe(getViewLifecycleOwner(), healthSettingInfo -> {
            FallDetection fallDetection = healthSettingInfo.getFallDetection();
            String contact = fallDetection.getContact();
            if (TextUtils.isEmpty(contact)) {
                contact = getString(R.string.no_setting);
            }
            binding.tvContact.setText(contact);
            binding.etContact.setText(fallDetection.getContact());

        });
    }
}
