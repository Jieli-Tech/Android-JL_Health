package com.jieli.healthaide.ui.mine;

import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.text.method.PasswordTransformationMethod;
import android.text.method.TransformationMethod;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentChangePasswordBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.ui.login.ResetPasswordFragment;
import com.jieli.healthaide.ui.login.ResetPasswordViewModel;
import com.jieli.healthaide.ui.widget.CustomTextWatcher;
import com.jieli.healthaide.util.FormatUtil;

/**
 * @ClassName: ChangePasswordFragment
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/4/2 9:46
 */
public class ChangePasswordFragment extends Fragment {
    private FragmentChangePasswordBinding fragmentChangePasswordBinding;
    private ResetPasswordViewModel mViewModel;
    private WaitingDialog waitingDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        fragmentChangePasswordBinding = FragmentChangePasswordBinding.inflate(inflater, container, false);
        fragmentChangePasswordBinding.tilPasswordNew.setOnClickListener(view -> {
            TransformationMethod method = hasPasswordTransformation() ? new PasswordTransformationMethod() : null;
            fragmentChangePasswordBinding.tietPasswordNewReconfirm.setTransformationMethod(method);
        });
        fragmentChangePasswordBinding.tietPasswordOld.addTextChangedListener(passwordCheck);
        fragmentChangePasswordBinding.tietPasswordNew.addTextChangedListener(passwordCheckNewPassword);
        fragmentChangePasswordBinding.tietPasswordNewReconfirm.addTextChangedListener(passwordCheck);
        fragmentChangePasswordBinding.clRegisterTopbar.tvTopbarTitle.setText(R.string.change_password);
        fragmentChangePasswordBinding.clRegisterTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        fragmentChangePasswordBinding.btnConfirm.setOnClickListener(v -> {
            String oldPassword = fragmentChangePasswordBinding.tietPasswordOld.getText().toString().trim();
            String newPassword = fragmentChangePasswordBinding.tietPasswordNew.getText().toString().trim();
            String newPasswordReconfirm = fragmentChangePasswordBinding.tietPasswordNewReconfirm.getText().toString().trim();
            if (TextUtils.equals(newPassword, newPasswordReconfirm)) {
                mViewModel.resetPassword(oldPassword, newPassword);
            } else {
                fragmentChangePasswordBinding.tvError.setText(R.string.password_is_inconsistent);
                fragmentChangePasswordBinding.tvError.setVisibility(View.VISIBLE);
            }
        });
        fragmentChangePasswordBinding.tvForgetPassword.setOnClickListener(view -> {
            ContentActivity.startContentActivity(requireContext(), ResetPasswordFragment.class.getCanonicalName());
        });
        return fragmentChangePasswordBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(ResetPasswordViewModel.class);
        mViewModel.stateLiveData.observe(getViewLifecycleOwner(), state -> {
            switch (state) {
                case ResetPasswordViewModel.STATE_INPUT_PASSWORD:
                    hideWaitingDialog();
                    break;
                case ResetPasswordViewModel.STATE_RESET_PASSWORD: {
                    if (waitingDialog == null) {
                        waitingDialog = new WaitingDialog();
                    }
                    waitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getCanonicalName());
                }
                case ResetPasswordViewModel.STATE_RESET_PASSWORD_FINISH: {
                    hideWaitingDialog();
                    requireActivity().onBackPressed();
                    ToastUtil.showToastLong(R.string.modified_success);
                }
                break;
            }
        });
    }

    private void hideWaitingDialog() {
        if (waitingDialog != null) {
            waitingDialog.dismiss();
        }
    }

    private TextWatcher passwordCheckNewPassword = new CustomTextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            super.beforeTextChanged(s, start, count, after);
            TransformationMethod method = hasPasswordTransformation() ? new PasswordTransformationMethod() : null;
            fragmentChangePasswordBinding.tietPasswordNewReconfirm.setTransformationMethod(method);
            passwordCheck.beforeTextChanged(s, start, count, after);
        }

        @Override
        public void afterTextChanged(Editable s) {
            super.afterTextChanged(s);
            passwordCheck.afterTextChanged(s);
        }
    };
    private TextWatcher passwordCheck = new CustomTextWatcher() {
        @Override
        public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            super.beforeTextChanged(s, start, count, after);
            fragmentChangePasswordBinding.tvError.setVisibility(View.GONE);
        }

        @Override
        public void afterTextChanged(Editable s) {
            super.afterTextChanged(s);
            String pass1 = fragmentChangePasswordBinding.tietPasswordOld.getText().toString().trim();
            String pass2 = fragmentChangePasswordBinding.tietPasswordNew.getText().toString().trim();
            String pass3 = fragmentChangePasswordBinding.tietPasswordNewReconfirm.getText().toString().trim();
            boolean ret = !TextUtils.isEmpty(pass1) && !TextUtils.isEmpty(pass2) && !TextUtils.isEmpty(pass3);
            ret = ret
                    && FormatUtil.checkPassword(pass2) && FormatUtil.checkPassword(pass3);
            fragmentChangePasswordBinding.btnConfirm.setEnabled(ret);
        }
    };
    private boolean hasPasswordTransformation() {
        EditText editText = fragmentChangePasswordBinding.tilPasswordNew.getEditText();
        return editText != null && editText.getTransformationMethod() instanceof PasswordTransformationMethod;
    }
}
