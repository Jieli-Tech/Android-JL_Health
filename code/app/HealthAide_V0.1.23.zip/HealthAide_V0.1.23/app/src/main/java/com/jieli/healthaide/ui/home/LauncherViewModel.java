package com.jieli.healthaide.ui.home;

import android.app.Application;
import android.text.TextUtils;
import android.view.View;

import androidx.annotation.NonNull;
import androidx.lifecycle.AndroidViewModel;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.tool.net.NetWorkStateModel;
import com.jieli.healthaide.tool.net.NetworkStateHelper;
import com.jieli.healthaide.ui.service.NetStateCheckService;
import com.jieli.jl_filebrowse.interfaces.OperatCallback;
import com.jieli.jl_health_http.HttpClient;
import com.jieli.jl_health_http.HttpConstant;
import com.jieli.jl_health_http.model.response.LoginResponse;
import com.jieli.jl_health_http.model.response.ProfileResponse;
import com.jieli.jl_health_http.model.response.UserInfoResponse;
import com.jieli.jl_health_http.util.NetworkUtil;
import com.jieli.jl_health_http.util.SpUtil;
import com.jieli.jl_rcsp.util.JL_Log;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/22/21 9:37 AM
 * @desc :
 */
public class LauncherViewModel extends AndroidViewModel {
    MutableLiveData<Boolean> tokenStateLiveData = new MutableLiveData<>();

    public LauncherViewModel(@NonNull Application application) {
        super(application);
    }


    public void refreshToken() {

        String token = HttpClient.getToken();
        //没有登录信息，直接结束
        if (TextUtils.isEmpty(token)) {
            JL_Log.e("Sen","no token");
            tokenStateLiveData.postValue(false);
            return;
        }
        if (!NetworkUtil.checkNetWorkConnected()) {
            //无网络
            tokenStateLiveData.postValue(true);
            return;
        }

        HttpClient.createUserApi().refreshToken().enqueue(new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.isSuccessful() && response.body().getCode() == HttpConstant.HTTP_OK) {
                    requestProfile();
                } else {
                    requestProfile();
//                    tokenStateLiveData.postValue(false);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                tokenStateLiveData.postValue(false);
            }
        });
    }

    private void requestProfile() {
        HealthApplication.getAppViewModel().requestProfile(new OperatCallback() {
            @Override
            public void onSuccess() {
                tokenStateLiveData.postValue(true);
            }

            @Override
            public void onError(int code) {
                //当无网络时，会使用缓存，如果使用缓存也是返回错误，可认为数据异常，返回登录页面
                tokenStateLiveData.postValue(false);
            }
        });

    }
}
