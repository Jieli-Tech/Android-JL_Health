package com.jieli.healthaide.ui.device;

import android.bluetooth.BluetoothDevice;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.watch.WatchServerCacheHelper;
import com.jieli.healthaide.ui.device.bean.WatchInfo;
import com.jieli.healthaide.ui.device.bean.WatchOpData;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.interfaces.OnFatFileProgressListener;
import com.jieli.jl_fatfs.utils.FatUtil;
import com.jieli.jl_health_http.model.WatchFileList;
import com.jieli.jl_health_http.model.WatchFileMsg;
import com.jieli.jl_health_http.model.param.WatchFileListParam;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.response.ExternalFlashMsgResponse;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 手表市场ViewModel
 * @since 2021/3/12
 */
public class WatchMarketViewModel extends WatchViewModel {
    private final static String TAG = WatchMarketViewModel.class.getSimpleName();
    public final MutableLiveData<WatchMarketResult> mWatchMarketResultMLD = new MutableLiveData<>();
    public final BluetoothDevice mTargetDev;
    private final Fragment mFragment;
    public int currentPage = 0;
    private int totalPage;
    private final List<WatchInfo> mWatchInfoList = new ArrayList<>();
    private final WatchServerCacheHelper mWatchServerCacheHelper;

    private final static int PAGE_NUM = 15;

    public WatchMarketViewModel(Fragment fragment) {
        super();

        mFragment = fragment;
        mWatchServerCacheHelper = WatchServerCacheHelper.getInstance();

        mWatchListMLD.observe(fragment.getViewLifecycleOwner(), watchInfos -> {
            mWatchInfoList.clear();
            mWatchInfoList.addAll(watchInfos);
        });

        mTargetDev = getConnectedDevice();
    }

    @Override
    public void release() {
        super.release();
    }

    @Override
    public void listWatchList() {
        currentPage = 0;
        super.listWatchList();
    }

    /**
     * 获取服务器表盘列表
     *
     * @param page 页数
     */
    public void getServiceWatchList(int page) {
        if (!isConnectedDevice(mTargetDev)) {
            publishWatchMarketFail(2, mFragment.getString(R.string.device_is_disconnected));
            return;
        }
        if (totalPage != 0 && page == totalPage) {
            publishWatchMarketFail(1, mFragment.getString(R.string.last_page));
            return;
        }
        DeviceInfo deviceInfo = getDeviceInfo(mTargetDev);
        if (null == deviceInfo) return;
        int vid = deviceInfo.getVid();//2
        int pid = deviceInfo.getPid();//49
        List<String> versionList = new ArrayList<>();
        WatchFileListParam param = new WatchFileListParam();
        /*versionList.add("W001");
        versionList.add("W002");*/
        ExternalFlashMsgResponse externalFlashMsg = mWatchManager.getExternalFlashMsg(mTargetDev);
        if (null != externalFlashMsg) {
            String[] versions = externalFlashMsg.getMatchVersions();
            if (versions != null) {
                versionList.addAll(Arrays.asList(versions));
            }
        }
        if (versionList.isEmpty()) {
            publishWatchMarketFail(3, mFragment.getString(R.string.server_none_device_support_version));
            return;
        }
        param.setPage(page + 1);
        param.setPid(pid);
        param.setVid(vid);
        param.setSize(PAGE_NUM);
        param.setVersions(versionList);
        JL_Log.e("zzc_http", "-getServiceWatchList- >>> " + param);
        mWatchServerCacheHelper.queryWatchFileListByPage(param, new WatchServerCacheHelper.IWatchHttpCallback<WatchFileList>() {
            @Override
            public void onSuccess(WatchFileList result) {
                List<WatchFileMsg> list = result.getRecords();
                totalPage = result.getPages();
                if (list == null || list.isEmpty()) return;
                currentPage = result.getCurrent();
                JL_Log.i("zzc_http", "currentPage >> " + currentPage + ", list = " + list.size());
                List<WatchInfo> watchInfos = mergeWatchList(mWatchInfoList, list);
                mWatchInfoList.clear();
                mWatchInfoList.addAll(watchInfos);
                publishWatchMarketSuccess(new ArrayList<>(mWatchInfoList));
            }

            @Override
            public void onFailed(int code, String message) {
                publishWatchMarketFail(code, message);
            }
        });
    }

    public void downloadWatch(String uri, final String outPath) {
        postWatchOpStart(WatchOpData.OP_CREATE_FILE, FatUtil.getFatFilePath(outPath));
        /*if(FileUtil.checkFileExist(outPath)){
            insertWatchFile(outPath);
        }else*/
        {
            mWatchServerCacheHelper.downloadFile(uri, outPath, new WatchServerCacheHelper.OnDownloadListener() {
                @Override
                public void onStart() {

                }

                @Override
                public void onProgress(int progress) {

                }

                @Override
                public void onSuccess(String result) {
                    JL_Log.i(TAG, "-downloadWatch- result = " + result);
                    insertWatchFile(result);
                }

                @Override
                public void onFailed(int code, String message) {
                    JL_Log.w(TAG, "-downloadWatch- onFailed = " + code + ", message = " + message);
                    postWatchOpEnd(WatchOpData.OP_CREATE_FILE, code, message);
                }
            });
        }
    }

    public void updateWatch(String uri, String outPath) {
        postWatchOpStart(WatchOpData.OP_REPLACE_FILE, FatUtil.getFatFilePath(outPath));
        mWatchServerCacheHelper.downloadFile(uri, outPath, new WatchServerCacheHelper.OnDownloadListener() {
            @Override
            public void onStart() {

            }

            @Override
            public void onProgress(int progress) {

            }

            @Override
            public void onSuccess(String result) {
                JL_Log.i(TAG, "-updateWatch- result = " + result);
                replaceWatchFile(result);
            }

            @Override
            public void onFailed(int code, String message) {
                JL_Log.w(TAG, "-updateWatch- onFailed = " + code + ", message = " + message);
                postWatchOpEnd(WatchOpData.OP_REPLACE_FILE, code, message);
            }
        });
    }

    private void insertWatchFile(final String filePath) {
        if(isCallWorkState()){
            postWatchOpEnd(WatchOpData.OP_CREATE_FILE, FatFsErrCode.RES_ERR_BEGIN, HealthApplication.getAppViewModel().getApplication().getString(R.string.call_phone_error_tips));
            return;
        }
        mWatchManager.addFatFile(filePath, false, new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                //postWatchOpStart(WatchOpData.OP_CREATE_FILE, filePath);
            }

            @Override
            public void onProgress(float progress) {
                postWatchOpProgress(WatchOpData.OP_CREATE_FILE, progress);
            }

            @Override
            public void onStop(int result) {
                JL_Log.e(TAG, "-insertWatchFile- onStop ---> result = " + result);
                if (result == 0) {
//                    listWatchList();
                    enableCurrentWatch(FatUtil.getFatFilePath(filePath));
                }
                postWatchOpEnd(WatchOpData.OP_CREATE_FILE, result, FatUtil.getFatFsErrorCodeMsg(result));
            }
        });
    }

    private void replaceWatchFile(final String filePath) {
        mWatchManager.replaceWatchFile(filePath, new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                //postWatchOpStart(WatchOpData.OP_REPLACE_FILE, filePath);
            }

            @Override
            public void onProgress(float progress) {
                postWatchOpProgress(WatchOpData.OP_REPLACE_FILE, progress);
            }

            @Override
            public void onStop(int result) {
                if (result == FatFsErrCode.RES_OK) {
                    mWatchManager.updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                        @Override
                        public void onSuccess(ArrayList<WatchInfo> result) {
                            enableCurrentWatch(FatUtil.getFatFilePath(filePath));
                            postWatchOpEnd(WatchOpData.OP_REPLACE_FILE, FatFsErrCode.RES_OK, FatUtil.getFatFsErrorCodeMsg(FatFsErrCode.RES_OK));
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            postWatchOpEnd(WatchOpData.OP_REPLACE_FILE, FatFsErrCode.RES_RCSP_SEND, FatUtil.getFatFsErrorCodeMsg(FatFsErrCode.RES_RCSP_SEND));
                        }
                    });
                } else {
                    postWatchOpEnd(WatchOpData.OP_REPLACE_FILE, result, FatUtil.getFatFsErrorCodeMsg(result));
                }
            }
        });
    }

    private List<WatchInfo> mergeWatchList(List<WatchInfo> devWatchList, List<WatchFileMsg> list) {
        if (null == devWatchList && null == list) return new ArrayList<>();
        if (null == list || list.isEmpty()) return devWatchList;
        List<WatchInfo> resultList = new ArrayList<>();
        if (devWatchList == null || devWatchList.isEmpty()) {
            for (WatchFileMsg fileMsg : list) {
                WatchInfo watch = new WatchInfo()
                        .setName(fileMsg.getName())
                        .setFileUrl(fileMsg.getUrl())
                        .setUuid(fileMsg.getUuid())
                        .setBitmapUri(fileMsg.getIcon())
                        .setStatus(WatchInfo.WATCH_STATUS_NONE_EXIST)
                        .setVersion(fileMsg.getVersion());
                resultList.add(watch);
            }
            return resultList;
        }
        List<WatchFileMsg> deleteList = new ArrayList<>();
        for (WatchInfo info : devWatchList) {
            String infoName = info.getName() == null ? null : info.getName().toUpperCase();
            String infoVersion = info.getVersion() == null ? null : info.getVersion().toUpperCase();
            for (WatchFileMsg fileMsg : list) {
                String watchName = fileMsg.getName() == null ? null : fileMsg.getName().toUpperCase();
                String watchVersion = fileMsg.getVersion() == null ? null : fileMsg.getVersion().toUpperCase();
                if (null != info.getUuid() && info.getUuid().equalsIgnoreCase(fileMsg.getUuid())
                        && null != infoName && infoName.equalsIgnoreCase(watchName)
                        && null != infoVersion && infoVersion.equalsIgnoreCase(watchVersion)) {
//                    info.setUuid(fileMsg.getUuid());
                    info.setFileUrl(fileMsg.getUrl());
                    info.setBitmapUri(fileMsg.getIcon());
                    deleteList.add(fileMsg);
                    break;
                }
            }
            resultList.add(info);
        }
        if (!deleteList.isEmpty()) {
            list.removeAll(deleteList);
        }
        for (WatchFileMsg fileMsg : list) {
            WatchInfo watch = new WatchInfo()
                    .setName(fileMsg.getName())
                    .setFileUrl(fileMsg.getUrl())
                    .setUuid(fileMsg.getUuid())
                    .setBitmapUri(fileMsg.getIcon())
                    .setStatus(WatchInfo.WATCH_STATUS_NONE_EXIST)
                    .setVersion(fileMsg.getVersion());
            boolean isExist = false;
            String watchName = fileMsg.getName() == null ? null : fileMsg.getName().toUpperCase();
            String watchVersion = fileMsg.getVersion() == null ? null : fileMsg.getVersion().toUpperCase();
            for (WatchInfo watchInfo : resultList) {
                String infoName = watchInfo.getName() == null ? null : watchInfo.getName().toUpperCase();
                String infoVersion = watchInfo.getVersion() == null ? null : watchInfo.getVersion().toUpperCase();
                if (watchName != null && watchName.equals(infoName) && watchInfo.getStatus() >= WatchInfo.WATCH_STATUS_EXIST) {
                    isExist = true;
                    if (watchVersion != null && infoVersion != null) {
                        int ret = watchVersion.compareTo(infoVersion);
                        if (ret > 0) {//服务器版本大
                            watchInfo.setUpdateUUID(fileMsg.getUuid())
                                    .setUpdateVersion(fileMsg.getVersion())
                                    .setUpdateUrl(fileMsg.getUrl());
                        }
                    }
                    break;
                }
            }
            if (!isExist) {
                resultList.add(watch);
            }
        }
        return resultList;
    }

    private void publishWatchMarketSuccess(List<WatchInfo> list) {
        WatchMarketResult result = new WatchMarketResult();
        result.setOk(true);
        result.setWatchList(list);
        mWatchMarketResultMLD.postValue(result);
    }

    private void publishWatchMarketFail(int code, String message) {
        WatchMarketResult result = new WatchMarketResult();
        result.setOk(false);
        result.setCode(code);
        result.setMessage(message);
        mWatchMarketResultMLD.postValue(result);
    }

    public static class WatchMarketResult {
        private boolean isOk;
        private int code;
        private String message;
        private List<WatchInfo> watchList;

        public boolean isOk() {
            return isOk;
        }

        public void setOk(boolean ok) {
            isOk = ok;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public List<WatchInfo> getWatchList() {
            return watchList;
        }

        public void setWatchList(List<WatchInfo> watchList) {
            this.watchList = watchList;
        }
    }

    public static class WatchMarketViewModelFactory implements ViewModelProvider.Factory {
        private final Fragment mFragment;

        public WatchMarketViewModelFactory(Fragment fragment) {
            mFragment = fragment;
        }

        @NonNull
        @Override
        public <T extends ViewModel> T create(@NonNull Class<T> modelClass) {
            return (T) new WatchMarketViewModel(mFragment);
        }
    }
}