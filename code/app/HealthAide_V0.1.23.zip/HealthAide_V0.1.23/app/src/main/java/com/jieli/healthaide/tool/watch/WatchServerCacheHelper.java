package com.jieli.healthaide.tool.watch;

import com.jieli.component.thread.ThreadManager;
import com.jieli.jl_health_http.HttpClient;
import com.jieli.jl_health_http.HttpConstant;
import com.jieli.jl_health_http.api.WatchApi;
import com.jieli.jl_health_http.model.OtaFileMsg;
import com.jieli.jl_health_http.model.WatchFileList;
import com.jieli.jl_health_http.model.WatchFileMsg;
import com.jieli.jl_health_http.model.WatchProduct;
import com.jieli.jl_health_http.model.param.WatchFileListParam;
import com.jieli.jl_health_http.model.response.OtaFileMsgResponse;
import com.jieli.jl_health_http.model.response.WatchFileListResponse;
import com.jieli.jl_health_http.model.response.WatchFileResponse;
import com.jieli.jl_health_http.model.response.WatchProductResponse;
import com.jieli.jl_health_http.tool.WriteDataToFileTask;
import com.jieli.jl_rcsp.util.JL_Log;

import org.jetbrains.annotations.NotNull;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ExecutorService;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 表盘服务器缓存器
 * @since 2021/4/30
 */
public class WatchServerCacheHelper {
    private static final String TAG = "watch_http";
    private static volatile WatchServerCacheHelper instance;
    private final WatchApi mWatchApi = HttpClient.createWatchApi();
    private final Map<String, WatchFileMsg> cacheServerWatchMap = new HashMap<>(); //缓存设备对应表盘列表信息
    private final ExecutorService mThreadPool = ThreadManager.getInstance().getThreadPool();//Executors.newSingleThreadExecutor();

    public static final int ERR_INVALID_PARAMETER = 1;
    public static final int ERR_HTTP_BAD_CODE = 2;
    public static final int ERR_HTTP_FORMAT = 3;
    public static final int ERR_HTTP_EXCEPTION = 4;
    public static final int ERR_BAD_RESPONSE = 5;
    public static final int ERR_NOT_PATH = 6;
    public static final int ERR_THREAD_POOL_SHUTDOWN = 7;


    private WatchServerCacheHelper() {

    }

    public static WatchServerCacheHelper getInstance() {
        if (null == instance) {
            synchronized (WatchServerCacheHelper.class) {
                if (null == instance) {
                    instance = new WatchServerCacheHelper();
                }
            }
        }
        return instance;
    }

    public void destroy() {
        cacheServerWatchMap.clear();
        if (!mThreadPool.isShutdown()) {
            mThreadPool.shutdown();
        }
        instance = null;
    }

    public Map<String, WatchFileMsg> getCacheServerWatchMap() {
        return cacheServerWatchMap;
    }

    public WatchFileMsg getCacheWatchServerMsg(String uuid) {
        if (null == uuid) return null;
        return cacheServerWatchMap.get(uuid);
    }

    public void getWatchProductMsg(int vid, int pid, final IWatchHttpCallback<WatchProduct> callback) {
        mWatchApi.queryWatchProduct(vid, pid).enqueue(new Callback<WatchProductResponse>() {
            @Override
            public void onResponse(@NotNull Call<WatchProductResponse> call, @NotNull Response<WatchProductResponse> response) {
                if (!response.isSuccessful()) {
                    callbackFailed(callback, ERR_HTTP_BAD_CODE, "http code error:" + response.code());
                    return;
                }
                WatchProductResponse watchProductResponse = response.body();
                if (null == watchProductResponse) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response body is error.");
                    return;
                }
                if (watchProductResponse.getCode() != HttpConstant.HTTP_OK) {
                    callbackFailed(callback, ERR_BAD_RESPONSE, "bad code : " + watchProductResponse.getCode() + ", message : " + watchProductResponse.getMsg());
                    return;
                }
                WatchProduct product = watchProductResponse.getT();
                if (null == product) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response format is error.");
                    return;
                }
                callbackSuccess(callback, product);
            }

            @Override
            public void onFailure(@NotNull Call<WatchProductResponse> call, @NotNull Throwable t) {
                callbackFailed(callback, ERR_HTTP_EXCEPTION, t.getMessage());
            }
        });
    }

    public void queryWatchFileListByPage(WatchFileListParam param, final IWatchHttpCallback<WatchFileList> callback) {
        if (null == param) {
            callbackFailed(callback, ERR_INVALID_PARAMETER, "Invalid parameter : WatchFileListParam");
            return;
        }
        mWatchApi.queryWatchFileList(param).enqueue(new Callback<WatchFileListResponse>() {
            @Override
            public void onResponse(@NotNull Call<WatchFileListResponse> call, @NotNull Response<WatchFileListResponse> response) {
                if (!response.isSuccessful()) {
                    callbackFailed(callback, ERR_HTTP_BAD_CODE, "http code error:" + response.code());
                    return;
                }
                WatchFileListResponse watchFileListResponse = response.body();
                if (null == watchFileListResponse) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response body is error.");
                    return;
                }
                if (watchFileListResponse.getCode() != HttpConstant.HTTP_OK) {
                    callbackFailed(callback, ERR_BAD_RESPONSE, "bad code : " + watchFileListResponse.getCode() + ", message : " + watchFileListResponse.getMsg());
                    return;
                }
                WatchFileList fileList = watchFileListResponse.getT();
                if (null == fileList) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response format is error.");
                    return;
                }
                List<WatchFileMsg> list = fileList.getRecords();
                if (null != list && !list.isEmpty()) {
                    for (WatchFileMsg msg : list) {
                        cacheServerWatchMap.put(msg.getUuid(), msg);
                    }
                }
                callbackSuccess(callback, fileList);
            }

            @Override
            public void onFailure(@NotNull Call<WatchFileListResponse> call, @NotNull Throwable t) {
                callbackFailed(callback, ERR_HTTP_EXCEPTION, t.getMessage());
            }
        });
    }

    public void queryWatchInfoByUUID(final String uuid, final IWatchHttpCallback<WatchFileMsg> callback) {
        if (null == uuid) {
            callbackFailed(callback, ERR_INVALID_PARAMETER, "Invalid parameter: uuid");
            return;
        }
        mWatchApi.queryWatchFileByUUID(uuid).enqueue(new Callback<WatchFileResponse>() {
            @Override
            public void onResponse(@NotNull Call<WatchFileResponse> call, @NotNull Response<WatchFileResponse> response) {
                if (!response.isSuccessful()) {
                    callbackFailed(callback, ERR_HTTP_BAD_CODE, "http code error:" + response.code());
                    return;
                }
                WatchFileResponse watchFileResponse = response.body();
                if (null == watchFileResponse) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response body is error.");
                    return;
                }
                if (watchFileResponse.getCode() != HttpConstant.HTTP_OK) {
                    callbackFailed(callback, ERR_BAD_RESPONSE, "bad code : " + watchFileResponse.getCode() + ", message : " + watchFileResponse.getMsg());
                    return;
                }
                WatchFileMsg watchFileMsg = watchFileResponse.getT();
                if (null == watchFileMsg) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response format is error.");
                    return;
                }
                cacheServerWatchMap.put(watchFileMsg.getUuid(), watchFileMsg);
                callbackSuccess(callback, watchFileMsg);
            }

            @Override
            public void onFailure(@NotNull Call<WatchFileResponse> call, @NotNull Throwable t) {
                callbackFailed(callback, ERR_HTTP_EXCEPTION, t.getMessage());
            }
        });
    }

    public void queryOtaMsg(int pid, int vid, final IWatchHttpCallback<OtaFileMsg> callback) {
        mWatchApi.queryOtaMsg(pid, vid).enqueue(new Callback<OtaFileMsgResponse>() {
            @Override
            public void onResponse(@NotNull Call<OtaFileMsgResponse> call, @NotNull Response<OtaFileMsgResponse> response) {
                if (!response.isSuccessful()) {
                    callbackFailed(callback, ERR_HTTP_BAD_CODE, "http code error:" + response.code());
                    return;
                }
                OtaFileMsgResponse otaFileMsgResponse = response.body();
                if (null == otaFileMsgResponse) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response body is error.");
                    return;
                }
                if (otaFileMsgResponse.getCode() != HttpConstant.HTTP_OK) {
                    callbackFailed(callback, ERR_BAD_RESPONSE, "bad code : " + otaFileMsgResponse.getCode() + ", message : " + otaFileMsgResponse.getMsg());
                    return;
                }
                OtaFileMsg otaFileMsg = otaFileMsgResponse.getT();
                if (null == otaFileMsg) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response format is error.");
                    return;
                }
                callbackSuccess(callback, otaFileMsg);
            }

            @Override
            public void onFailure(@NotNull Call<OtaFileMsgResponse> call, @NotNull Throwable t) {
                callbackFailed(callback, ERR_HTTP_EXCEPTION, t.getMessage());
            }
        });
    }

    public void downloadFile(String uri, final String outPath, final OnDownloadListener callback) {
        if (uri == null || (!uri.startsWith("http://") && !uri.startsWith("https://")) || outPath == null) {
            callbackFailed(callback, ERR_INVALID_PARAMETER, "Invalid parameter: uri = " + uri);
            return;
        }
        mWatchApi.downloadFileByUrl(uri).enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(@NotNull Call<ResponseBody> call, @NotNull Response<ResponseBody> response) {
                if (!response.isSuccessful()) {
                    callbackFailed(callback, ERR_HTTP_BAD_CODE, "http code error:" + response.code());
                    return;
                }
                ResponseBody responseBody = response.body();
                if (responseBody == null) {
                    callbackFailed(callback, ERR_HTTP_FORMAT, "response body is error.");
                    return;
                }
                if (!mThreadPool.isShutdown()) {
                    mThreadPool.submit(new WriteDataToFileTask(response.body(), outPath, new WriteDataToFileTask.OnWriteDataListener() {
                        @Override
                        public void onStart(long threadID) {
                            if (callback != null) {
                                callback.onStart();
                            }
                        }

                        @Override
                        public void onProgress(long threadID, float progress) {
                            if (callback != null) {
                                callback.onProgress((int) progress);
                            }
                        }

                        @Override
                        public void onStop(long threadID, String outputPath) {
                            JL_Log.w(TAG, "-downloadWatch- onStop = " + outputPath);
                            callbackSuccess(callback, outputPath);
                        }

                        @Override
                        public void onError(long threadID, int code, String message) {
                            JL_Log.e(TAG, "-downloadWatch- WriteDataToFileTask error. code = " + code + ", message = " + message);
                            int errCode = ERR_HTTP_EXCEPTION;
                            if (code == 1) {
                                errCode = ERR_INVALID_PARAMETER;
                            } else if (code == 2) {
                                errCode = ERR_NOT_PATH;
                            }
                            callbackFailed(callback, errCode, message);
                        }
                    }));
                } else {
                    JL_Log.e(TAG, "-downloadWatch- Thread pool is shut down.");
                    callbackFailed(callback, ERR_THREAD_POOL_SHUTDOWN, "Thread pool is shut down");
                }
            }

            @Override
            public void onFailure(@NotNull Call<ResponseBody> call, @NotNull Throwable t) {
                callbackFailed(callback, ERR_HTTP_EXCEPTION, t.getMessage());
            }
        });
    }

    private <T> void callbackSuccess(IWatchHttpCallback<T> callback, T result) {
        if (callback != null) {
            callback.onSuccess(result);
        }
    }

    private <T> void callbackFailed(IWatchHttpCallback<T> callback, int code, String message) {
        if (callback != null) {
            callback.onFailed(code, message);
        }
    }

    public interface IWatchHttpCallback<T> {

        void onSuccess(T result);

        void onFailed(int code, String message);
    }

    public interface OnDownloadListener extends IWatchHttpCallback<String> {
        void onStart();

        void onProgress(int progress);

    }
}
