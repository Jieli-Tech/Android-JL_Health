package com.jieli.healthaide.ui.mine;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.Nullable;
import androidx.constraintlayout.widget.ConstraintLayout;
import androidx.databinding.DataBindingUtil;
import androidx.fragment.app.Fragment;

import com.jieli.component.ActivityManager;
import com.jieli.component.utils.PreferencesHelper;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentLanguageSetBinding;
import com.jieli.healthaide.ui.home.HomeActivity;
import com.jieli.healthaide.util.MultiLanguageUtils;

import static com.jieli.healthaide.util.MultiLanguageUtils.LANGUAGE_AUTO;

/**
 * A simple {@link Fragment} subclass.
 * Use the {@link LanguageSetFragment#newInstance} factory method to
 * create an instance of this fragment.
 */
public class LanguageSetFragment extends Fragment {

    private FragmentLanguageSetBinding binding;
    private String selectLanguage = null;
    private String setLanguage = null;//已设置的语言

    public static LanguageSetFragment newInstance() {
        return new LanguageSetFragment();
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = DataBindingUtil.inflate(inflater, R.layout.fragment_language_set, container, false);
        binding.viewTopbar.tvTopbarTitle.setText(getString(R.string.set_language));
        binding.viewTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        binding.viewTopbar.tvTopbarRight.setVisibility(View.VISIBLE);
        binding.viewTopbar.tvTopbarRight.setTextColor(getResources().getColor(R.color.gray_D8D8D8));
        binding.viewTopbar.tvTopbarRight.setText(getString(R.string.confirm));
        binding.viewTopbar.tvTopbarRight.setOnClickListener(v -> saveChange());
        binding.tvFollowSystem.setTag(LANGUAGE_AUTO);
        binding.tvSimplifiedChinese.setTag(MultiLanguageUtils.LANGUAGE_ZH);
        binding.tvEnglish.setTag(MultiLanguageUtils.LANGUAGE_EN);
        initClick();
        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        setLanguage = PreferencesHelper.getSharedPreferences(HealthApplication.getAppViewModel().getApplication()).getString(MultiLanguageUtils.SP_LANGUAGE, MultiLanguageUtils.LANGUAGE_AUTO);
        selectLanguage = setLanguage;
        updateSelectView();
        updateConfirmButton();
    }

    private void initClick() {
        ConstraintLayout parent = (ConstraintLayout) binding.getRoot();
        int count = parent.getChildCount();
        for (int i = 1; i < count; i++) {
            if (!(parent.getChildAt(i) instanceof TextView)) continue;
            TextView textView = (TextView) parent.getChildAt(i);
            textView.setOnClickListener(v -> {
                if (v.getTag() != null) {
                    String t1 = (String) v.getTag();
                    selectLanguage = t1;
                    updateSelectView();
                    updateConfirmButton();
                }
            });
        }
    }

    private void updateConfirmButton() {
        binding.viewTopbar.tvTopbarRight.setTextColor(getResources().getColor(!isSetLanguage(selectLanguage) ? R.color.blue_558CFF : R.color.gray_D8D8D8));
        binding.viewTopbar.tvTopbarRight.setEnabled(!isSetLanguage(selectLanguage));
    }

    private void updateSelectView() {
        ConstraintLayout parent = (ConstraintLayout) binding.getRoot();
        int count = parent.getChildCount();
        for (int i = 1; i < count; i++) {
            if (!(parent.getChildAt(i) instanceof TextView)) continue;
            TextView textView = (TextView) parent.getChildAt(i);
            String tag = (String) textView.getTag();
            if (selectLanguage != null && tag.equals(selectLanguage)) {
                textView.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, R.drawable.ic_choose_blue, 0);
            } else {
                textView.setCompoundDrawablesRelativeWithIntrinsicBounds(0, 0, 0, 0);
            }
        }
    }

    private boolean isSetLanguage(String language) {
        return TextUtils.equals(setLanguage, language);
    }

    private void saveChange() {
        Context context = HealthApplication.getAppViewModel().getApplication();
        switch (selectLanguage) {
            case LANGUAGE_AUTO://切换到 跟随系统
                MultiLanguageUtils.changeLanguage(context, LANGUAGE_AUTO, MultiLanguageUtils.AREA_AUTO);
                break;
            case MultiLanguageUtils.LANGUAGE_ZH:
                MultiLanguageUtils.changeLanguage(context, MultiLanguageUtils.LANGUAGE_ZH, MultiLanguageUtils.AREA_ZH);
                break;
            case MultiLanguageUtils.LANGUAGE_EN:
                MultiLanguageUtils.changeLanguage(context, MultiLanguageUtils.LANGUAGE_EN, MultiLanguageUtils.AREA_EN);
                break;
        }
        //关闭应用所有Activity

        while (!(ActivityManager.getInstance().getTopActivity() instanceof HomeActivity)) {
            Activity activity = ActivityManager.getInstance().getTopActivity();
            activity.finish();
            ActivityManager.getInstance().a(activity);
        }
        Intent intent = new Intent(HomeActivity.HOME_ACTIVITY_RELOAD);
        getActivity().sendBroadcast(intent);
    }
}