package com.jieli.healthaide.tool.watch.synctask;
/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/7/20
 * @desc :
 */
public interface SyncTaskFinishListener {
    void onFinish();
}
