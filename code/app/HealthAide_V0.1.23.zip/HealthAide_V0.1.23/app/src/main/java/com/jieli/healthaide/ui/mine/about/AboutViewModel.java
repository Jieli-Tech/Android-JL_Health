package com.jieli.healthaide.ui.mine.about;

import androidx.lifecycle.ViewModel;
/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/11/21 9:19 AM
 * @desc :
 */
public class AboutViewModel extends ViewModel {

}