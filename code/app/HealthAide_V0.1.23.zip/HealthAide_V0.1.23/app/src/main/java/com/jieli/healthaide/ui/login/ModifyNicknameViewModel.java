package com.jieli.healthaide.ui.login;

import androidx.lifecycle.ViewModel;

public class ModifyNicknameViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}