package com.jieli.healthaide.ui.login;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentLoginByCodeBinding;
import com.jieli.healthaide.ui.base.BaseActivity;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.ui.home.HomeActivity;
import com.jieli.healthaide.ui.login.bean.LoginMsg;
import com.jieli.healthaide.ui.widget.CustomTextWatcher;
import com.jieli.healthaide.util.FormatUtil;
import com.jieli.jl_filebrowse.interfaces.OperatCallback;



/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/9/21 4:10 PM
 * @desc :
 */
public class LoginByCodeFragment extends SmsCodeFragment {
    private FragmentLoginByCodeBinding loginBinding;
    private LoginViewModel loginViewModel;
    private WaitingDialog waitingDialog;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        loginBinding = FragmentLoginByCodeBinding.inflate(inflater, container, false);
        loginBinding.tvLoginByPassword.setOnClickListener(v -> {
            BaseActivity baseActivity = (BaseActivity) requireActivity();
            baseActivity.replaceFragment(R.id.launcher_container, LoginByPasswordFragment.class.getCanonicalName());
        });

        loginBinding.layoutSmsCode.etPhoneNumber.addTextChangedListener(loginBtnStatusListener);
        loginBinding.layoutSmsCode.etVerificationCode.addTextChangedListener(loginBtnStatusListener);

        loginBinding.btnLogin.setOnClickListener(v -> {
            String mobile = loginBinding.layoutSmsCode.etPhoneNumber.getText().toString().trim();
            String code = loginBinding.layoutSmsCode.etVerificationCode.getText().toString().trim();
            loginViewModel.loginBySmsCode(mobile, code);
        });

        return loginBinding.getRoot();
    }


    private TextWatcher loginBtnStatusListener = new CustomTextWatcher() {
        @Override
        public void afterTextChanged(Editable s) {
            super.afterTextChanged(s);
            boolean ret = FormatUtil.checkPhoneNumber(loginBinding.layoutSmsCode.etPhoneNumber.getText().toString().trim())
                    && FormatUtil.checkSmsCode(loginBinding.layoutSmsCode.etVerificationCode.getText().toString().trim());
            PreferencesHelper.putStringValue(requireContext(), LoginViewModel.KEY_CACHE_MOBILE, loginBinding.layoutSmsCode.etPhoneNumber.getText().toString().trim());
            loginBinding.btnLogin.setEnabled(ret);
        }
    };

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        loginViewModel = new ViewModelProvider(this).get(LoginViewModel.class);
        loginBinding.layoutSmsCode.etPhoneNumber.setText(loginViewModel.getCacheInputNumber());
        loginViewModel.loginMsgMutableLiveData.observe(getViewLifecycleOwner(), loginMsg -> {
            switch (loginMsg.getState()) {
                case LoginMsg.STATE_LOGINING:
                    if (waitingDialog == null) {
                        waitingDialog = new WaitingDialog();
                    }
                    waitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getCanonicalName());
                    break;
                case LoginMsg.STATE_LOGIN_FINISH:
                    toHomeActivity();
                case LoginMsg.STATE_IDLE:
                case LoginMsg.STATE_LOGIN_ERROR:
                    if (waitingDialog != null) {
                        waitingDialog.dismiss();
                    }
                    break;
            }
        });
    }



    private void toHomeActivity() {
        HealthApplication.getAppViewModel().requestProfile(new OperatCallback() {
            @Override
            public void onSuccess() {
                Intent i = new Intent(requireActivity(), HomeActivity.class);
                startActivity(i);
                if (getActivity() != null)
                    requireActivity().finish();
            }

            @Override
            public void onError(int code) {
                ToastUtil.showToastShort(getString(R.string.save_failed));
            }
        });

    }
}
