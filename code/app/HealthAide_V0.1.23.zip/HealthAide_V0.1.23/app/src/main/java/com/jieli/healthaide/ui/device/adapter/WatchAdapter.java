package com.jieli.healthaide.ui.device.adapter;

import android.annotation.SuppressLint;
import android.content.Context;
import android.text.TextUtils;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.chad.library.adapter.base.BaseQuickAdapter;
import com.chad.library.adapter.base.module.LoadMoreModule;
import com.chad.library.adapter.base.viewholder.BaseViewHolder;
import com.jieli.component.utils.ValueUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.ui.device.bean.WatchInfo;

import org.jetbrains.annotations.NotNull;

import java.io.File;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 表盘适配器
 * @since 2021/3/11
 */
public class WatchAdapter extends BaseQuickAdapter<WatchInfo, BaseViewHolder> implements LoadMoreModule {
    private boolean isEditMode;
    private boolean isBanUpdate;
    private boolean isBanEditCustomBg;

    public WatchAdapter() {
        super(R.layout.item_watch);
    }

    @Override
    protected void convert(@NotNull BaseViewHolder viewHolder, WatchInfo watchInfo) {
        if (watchInfo == null) return;
        ImageView ivWatch = viewHolder.getView(R.id.iv_item_watch_img);
        String uri = watchInfo.getBitmapUri();
        updateWatchImg(getContext(), ivWatch, uri);
        TextView tvWatchStatus = viewHolder.getView(R.id.tv_item_watch_btn);
        updateWatchStatus(tvWatchStatus, watchInfo.getStatus(), watchInfo);
        tvWatchStatus.setEnabled(!isEditMode);
        boolean isShowDelete = isEditMode && watchInfo.getStatus() != WatchInfo.WATCH_STATUS_NONE_EXIST;
        ImageView ivDelete = viewHolder.getView(R.id.iv_item_watch_delete);
        ivDelete.setVisibility(isShowDelete ? View.VISIBLE : View.INVISIBLE);
        TextView tvWatchEdit = viewHolder.getView(R.id.tv_item_watch_edit);
        tvWatchEdit.setVisibility(!isBanEditCustomBg && !isEditMode && watchInfo.getStatus() == WatchInfo.WATCH_STATUS_USING ? View.VISIBLE : View.GONE);
        addChildClickViewIds(R.id.iv_item_watch_delete, R.id.tv_item_watch_btn, R.id.tv_item_watch_edit);
        bindViewClickListener(viewHolder, R.id.iv_item_watch_delete);
        bindViewClickListener(viewHolder, R.id.tv_item_watch_btn);
        bindViewClickListener(viewHolder, R.id.tv_item_watch_edit);
    }

    public boolean isEditMode() {
        return isEditMode;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setEditMode(boolean editMode) {
        if (isEditMode != editMode) {
            isEditMode = editMode;
            notifyDataSetChanged();
        }
    }

    public boolean isBanUpdate() {
        return isBanUpdate;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setBanUpdate(boolean banUpdate) {
        if (isBanUpdate != banUpdate) {
            isBanUpdate = banUpdate;
            notifyDataSetChanged();
        }
    }

    public boolean isBanEditCustomBg() {
        return isBanEditCustomBg;
    }

    @SuppressLint("NotifyDataSetChanged")
    public void setBanEditCustomBg(boolean banEditCustomBg) {
        if (isBanEditCustomBg != banEditCustomBg) {
            isBanEditCustomBg = banEditCustomBg;
            notifyDataSetChanged();
        }
    }

    public static void updateWatchImg(Context context, ImageView imageView, String uri) {
        if (imageView == null || context == null) return;
        boolean isSetBitmap = false;
        if (uri != null) {
            boolean isGif = uri.endsWith(".gif");
            if (uri.startsWith("res:")) { //资源路径
                String string = uri.substring("res:".length());
                int resId = 0;
                if (TextUtils.isDigitsOnly(string)) {
                    try {
                        resId = Integer.parseInt(string);
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                    imageView.setImageResource(resId);
                    isSetBitmap = true;
                }
                if (!isSetBitmap) {
                    imageView.setImageResource(R.drawable.ic_watch_6);
                }
            } else if (uri.startsWith("http://") || uri.startsWith("https://")) { //网络路径
                if (isGif) {
                    Glide.with(context).asGif().load(uri)
                            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                            .override(ValueUtil.dp2px(context, 108), ValueUtil.dp2px(context, 108))
                            .placeholder(R.drawable.ic_watch_6)
                            .error(R.drawable.ic_watch_6)
                            .into(imageView);
                } else {
                    Glide.with(context).asBitmap().load(uri)
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .override(ValueUtil.dp2px(context, 108), ValueUtil.dp2px(context, 108))
                            .placeholder(R.drawable.ic_watch_6)
                            .error(R.drawable.ic_watch_6)
                            .into(imageView);
                }
            } else { //本地路径
                if (isGif) {
                    Glide.with(context).asGif().load(new File(uri))
                            .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                            .override(ValueUtil.dp2px(context, 108), ValueUtil.dp2px(context, 108))
                            .placeholder(R.drawable.ic_watch_6)
                            .error(R.drawable.ic_watch_6)
                            .into(imageView);
                } else {
                    Glide.with(context).asBitmap().load(new File(uri))
                            .diskCacheStrategy(DiskCacheStrategy.ALL)
                            .override(ValueUtil.dp2px(context, 108), ValueUtil.dp2px(context, 108))
                            .placeholder(R.drawable.ic_watch_6)
                            .error(R.drawable.ic_watch_6)
                            .into(imageView);
                }
            }
        }else{
            imageView.setImageResource(R.drawable.ic_watch_6);
        }
    }

    @SuppressLint({"ResourceType", "UseCompatLoadingForColorStateLists"})
    private void updateWatchStatus(final TextView textView, int status, WatchInfo watchInfo) {
        if (textView == null) return;
        int textId = R.string.download_watch;
        int colorId = R.color.btn_blue_2_gray_selector;
        int bgId = R.drawable.bg_watch_white_2_gray_selector;
        switch (status) {
            case WatchInfo.WATCH_STATUS_EXIST:
                textId = R.string.use_watch;
                if (!isBanUpdate && watchInfo.hasUpdate()) {
                    textId = R.string.update_watch;
                    colorId = R.color.white;
                    bgId = R.drawable.bg_watch_green_2_gray_selecter;
                }
                break;
            case WatchInfo.WATCH_STATUS_USING:
                textId = R.string.using_watch;
                break;
        }
        textView.setText(textId);
        textView.setTextColor(getContext().getResources().getColorStateList(colorId));
        textView.setBackgroundResource(bgId);
    }
}
