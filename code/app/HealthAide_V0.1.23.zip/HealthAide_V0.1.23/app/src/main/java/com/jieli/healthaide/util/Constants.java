package com.jieli.healthaide.util;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 4/7/21
 * @desc :
 */
public interface Constants {
      int TRACK_SERVICE_ID = 283001;//高德猎鹰轨迹服务ID
      String DEFAULT_TERMINAL_NAME = "test_terminal_name";
}
