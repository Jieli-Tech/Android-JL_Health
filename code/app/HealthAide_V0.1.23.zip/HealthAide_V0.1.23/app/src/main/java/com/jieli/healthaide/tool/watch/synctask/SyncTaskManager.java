package com.jieli.healthaide.tool.watch.synctask;

import android.bluetooth.BluetoothDevice;
import android.os.Handler;
import android.os.Looper;

import androidx.lifecycle.MutableLiveData;

import com.jieli.bluetooth_connect.util.JL_Log;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.jl_rcsp.constant.Command;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.model.base.CommandBase;
import com.jieli.jl_rcsp.model.command.watch.SportsInfoStatusSyncCmd;
import com.jieli.jl_rcsp.task.smallfile.QueryFileTask;

import java.util.Queue;
import java.util.concurrent.LinkedBlockingQueue;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/6/15
 * @desc :
 */
public class SyncTaskManager extends OnWatchCallback implements SyncTaskFinishListener {
    private final String tag = SyncTaskManager.class.getSimpleName();
    private final WatchManager mWatchManager = WatchManager.getInstance();

    private final Queue<SyncTask> syncTasks = new LinkedBlockingQueue<>();
    private volatile static SyncTaskManager instance;
    private boolean isSyncing = false;
    public MutableLiveData<Boolean> isSyncingLiveData = new MutableLiveData<>(false);

    private final static int MSG_ADD_WEATHER_TASK = 0x3621;
    private final Handler uiHandler = new Handler(Looper.getMainLooper(), msg -> {
        if (msg.what == MSG_ADD_WEATHER_TASK) {
            addTask(new WeatherSyncTask(SyncTaskManager.this, SyncTaskManager.this));
        }
        return true;
    });

    private SyncTaskManager() {
        mWatchManager.registerOnWatchCallback(this);
        syncServerWhenLogin();
    }

    public static SyncTaskManager getInstance() {
        if (null == instance) {
            synchronized (SyncTaskManager.class) {
                if (null == instance) {
                    instance = new SyncTaskManager();
                }
            }
        }
        return instance;
    }

    public void destroy() {
        mWatchManager.unregisterOnWatchCallback(this);
        syncTasks.clear();
        uiHandler.removeCallbacksAndMessages(null);
        instance = null;
    }

    @Override
    public void onConnectStateChange(BluetoothDevice device, int status) {
        super.onConnectStateChange(device, status);
        JL_Log.w(tag, "onConnectStateChange--->" + status);
        dismissWaitingDialog();

        if (status != StateCode.CONNECTION_OK) {
            uiHandler.removeMessages(MSG_ADD_WEATHER_TASK);
        }
//        syncTasks.clear();
//        uiHandler.removeCallbacksAndMessages(null);
    }


    @Override
    public void onWatchSystemInit(int code) {
        super.onWatchSystemInit(code);
        boolean isSkip = mWatchManager.getBluetoothHelper().isBleChangeSpp(mWatchManager.getConnectedDevice());
        JL_Log.e(tag, "onWatchSystemInit--->" + code + ", isSkip = " + isSkip);
        if (code == 0) {
            if (isSkip) return;
            showWaitDialog();
            syncTasks.clear();
            addTask(new RequestUidSyncTask(this));
            addTask(new DeviceSportRecordSyncTaskModify(SyncTaskManager.this));
            addTask(new DeviceHealthDataSyncTask(QueryFileTask.TYPE_HEART_RATE, SyncTaskManager.this));
            addTask(new DeviceHealthDataSyncTask(QueryFileTask.TYPE_BLOOD_OXYGEN, SyncTaskManager.this));
            addTask(new DeviceHealthDataSyncTask(QueryFileTask.TYPE_SLEEP, SyncTaskManager.this));
            addTask(new DeviceHealthDataSyncTask(QueryFileTask.TYPE_STEP, SyncTaskManager.this));
            addTask(new RealTimeHealthDataSyncTask(this));
            addTask(new ServerHealthDataSyncTask(SyncTaskManager.this));
            addTask(new DownloadSportsRecordSyncTask(SyncTaskManager.this));
            addTask(new UploadSportsRecordSyncTask(SyncTaskManager.this));
            addTask(new SyncSportsStatusTask(SyncTaskManager.this));
            addTask(new WeatherSyncTask(SyncTaskManager.this, SyncTaskManager.this));
        }
    }

    @Override
    public void onFinish() {
        //切换到主线程
        uiHandler.post(() -> {
            SyncTask syncTask = syncTasks.poll();
            if (syncTask == null) return;
            JL_Log.i(tag, "-------------结束任务------------>" + syncTask.getClass().getSimpleName());
            startTask();
        });
    }

    @Override
    public void onRcspCommand(BluetoothDevice device, CommandBase command) {
        super.onRcspCommand(device, command);
        //运动状态变化
        if (command.getId() == Command.CMD_SPORTS_INFO_STATUS_SYNC) {
            SportsInfoStatusSyncCmd sportsInfoStatusSyncCmd = (SportsInfoStatusSyncCmd) command;
            if (sportsInfoStatusSyncCmd.getParam() instanceof SportsInfoStatusSyncCmd.StartSportsParam) {
                SportsInfoStatusSyncCmd.StartSportsParam startSportsParam = (SportsInfoStatusSyncCmd.StartSportsParam) sportsInfoStatusSyncCmd.getParam();
                if (isSyncing) {
                    //设备连接上的任务正在运行，等待
                    return;
                } else if (syncTasks.size() > 0) {
                    //有任务在执行, 放入任务队列等待开始
                    addTask(new SyncSportsStatusTask(this));
                    return;
                }
                //没有任务在执行，直接开始运动;
                SyncSportsStatusTask.toSportsUi(startSportsParam.type);

            }

        }
    }


    public void addTask(SyncTask task) {
        syncTasks.add(task);
        //只有一个task的时候执行该任务
        if (syncTasks.size() == 1) {
            startTask();
        }
    }


    public void addTaskDelay(SyncTask syncTask, int delayMs) {
        uiHandler.postDelayed(() -> addTask(syncTask), delayMs);
    }

    public void addWeatherTask(int delayMs) {
        uiHandler.removeMessages(MSG_ADD_WEATHER_TASK);
        uiHandler.sendEmptyMessageDelayed(MSG_ADD_WEATHER_TASK, delayMs);
    }

    private void startTask() {
        SyncTask syncTask = syncTasks.peek();
        if (syncTask == null) {
            JL_Log.i(tag, "syncTask is null--->");
            dismissWaitingDialog();
            return;
        }
        JL_Log.i(tag, "-------------启动SyncTask------------>" + syncTask.getClass().getSimpleName());
        syncTask.start();
    }


    /**
     * 看实际效果决定是登录同步服务器数据，还是连接成功同步
     */
    private void syncServerWhenLogin() {
        uiHandler.postDelayed(() -> {
            showWaitDialog();
            addTask(new RequestUidSyncTask(SyncTaskManager.this));
            addTask(new DownloadSportsRecordSyncTask(SyncTaskManager.this));
            addTask(new UploadSportsRecordSyncTask(SyncTaskManager.this));
            addTask(new ServerHealthDataSyncTask(this));
        }, 0);
    }

    private void showWaitDialog() {
        isSyncing = true;
        isSyncingLiveData.postValue(true);
    }

    private void dismissWaitingDialog() {
        isSyncing = false;
        isSyncingLiveData.postValue(false);
    }


}
