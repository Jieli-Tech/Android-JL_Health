package com.jieli.healthaide.ui.login;

import android.text.TextUtils;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.ui.login.bean.LoginMsg;
import com.jieli.healthaide.util.HttpErrorUtil;
import com.jieli.jl_health_http.HttpConstant;
import com.jieli.jl_health_http.HttpClient;
import com.jieli.jl_health_http.model.response.BooleanResponse;
import com.jieli.jl_health_http.model.response.LoginResponse;

import org.jetbrains.annotations.NotNull;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/9/21 4:06 PM
 * @desc :
 */
public class LoginViewModel extends ViewModel {
    public static final String KEY_CACHE_MOBILE = "KEY_CACHE_MOBILE";


    private static final String KEY_LOGIN_MOBILE = "KEY_LOGIN_MOBILE";

    MutableLiveData<LoginMsg> loginMsgMutableLiveData = new MutableLiveData<>(new LoginMsg());

    public void loginByAccount(String account, String password) {
        if (isLogin()) return;
        PreferencesHelper.putStringValue(HealthApplication.getAppViewModel().getApplication(), KEY_LOGIN_MOBILE, account);
        LoginMsg loginMsg = new LoginMsg(LoginMsg.STATE_LOGINING, "logining");
        loginMsgMutableLiveData.postValue(loginMsg);
        HttpClient.createUserApi().loginByPassword(account, password).enqueue(getLoginCallback());
    }

    public void loginBySmsCode(String mobile, String code) {
        if (isLogin()) return;
        PreferencesHelper.putStringValue(HealthApplication.getAppViewModel().getApplication(), KEY_LOGIN_MOBILE, mobile);
        LoginMsg loginMsg = new LoginMsg(LoginMsg.STATE_LOGINING, "logining");
        loginMsgMutableLiveData.postValue(loginMsg);
        HttpClient.createUserApi().checkSmsCode(mobile, code).enqueue(new Callback<BooleanResponse>() {
            @Override
            public void onResponse(Call<BooleanResponse> call, Response<BooleanResponse> response) {
                if (response.code() != 200) {
                    HttpErrorUtil.showErrorToast(response.code());
                    LoginMsg errMsg = new LoginMsg(LoginMsg.STATE_LOGIN_ERROR, "logining error");
                    loginMsgMutableLiveData.postValue(errMsg);
                    return;
                }
                BooleanResponse booleanResponse = response.body();
                if (booleanResponse.getCode() != HttpConstant.HTTP_OK) {
                    onFailure(call, new RuntimeException(response.body().getMsg()));
                } else {
                    //验证码校验成功才真正去登录
                    HttpClient.createUserApi().loginBySms(mobile, code).enqueue(getLoginCallback());
                }
            }

            @Override
            public void onFailure(Call<BooleanResponse> call, Throwable t) {
                ToastUtil.showToastShort(t.getMessage());
                LoginMsg errMsg = new LoginMsg(LoginMsg.STATE_LOGIN_ERROR, "logining error");
                loginMsgMutableLiveData.postValue(errMsg);
            }
        });

    }

    //获取缓存的账号，如果有登录过使用登录的，没有就使用输入缓存
    public String getCacheInputNumber() {
        String text = PreferencesHelper.getSharedPreferences(HealthApplication.getAppViewModel().getApplication()).getString(KEY_LOGIN_MOBILE, "");
        if (TextUtils.isEmpty(text)) {
            text = PreferencesHelper.getSharedPreferences(HealthApplication.getAppViewModel().getApplication()).getString(KEY_CACHE_MOBILE, "");

        }
        return text;
    }

    @NotNull
    private Callback<LoginResponse> getLoginCallback() {
        HttpClient.cleanCache();//登录前清理http缓存
        return new Callback<LoginResponse>() {
            @Override
            public void onResponse(Call<LoginResponse> call, Response<LoginResponse> response) {
                if (response.code() != 200) {
//                    onFailure(call, new RuntimeException("http code error:" + response.code()));
                    HttpErrorUtil.showErrorToast(response.code());
                    LoginMsg errMsg = new LoginMsg(LoginMsg.STATE_LOGIN_ERROR, "logining error");
                    loginMsgMutableLiveData.postValue(errMsg);
                    return;

                }
                LoginResponse loginResponse = response.body();
                if (loginResponse.getCode() != HttpConstant.HTTP_OK) {
                    onFailure(call, new RuntimeException(response.body().getMsg()));
                } else {
                    LoginMsg finishMsg = new LoginMsg(LoginMsg.STATE_LOGIN_FINISH, "logining finish");
                    loginMsgMutableLiveData.postValue(finishMsg);
                }
            }

            @Override
            public void onFailure(Call<LoginResponse> call, Throwable t) {
                ToastUtil.showToastShort(t.getMessage());
                LoginMsg errMsg = new LoginMsg(LoginMsg.STATE_LOGIN_ERROR, "logining error");
                loginMsgMutableLiveData.postValue(errMsg);
            }
        };
    }


    private boolean isLogin() {
        int state = loginMsgMutableLiveData.getValue().getState();
        return state == LoginMsg.STATE_LOGINING;
    }


}
