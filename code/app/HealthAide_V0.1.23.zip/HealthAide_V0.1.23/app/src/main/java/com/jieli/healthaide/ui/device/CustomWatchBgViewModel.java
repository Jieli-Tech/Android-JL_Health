package com.jieli.healthaide.ui.device;

import android.bluetooth.BluetoothDevice;
import android.net.Uri;

import androidx.annotation.NonNull;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.bmp_convert.BmpConvert;
import com.jieli.bmp_convert.OnConvertListener;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.phone.PhoneHelper;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.ui.device.bean.DeviceConnectionData;
import com.jieli.healthaide.ui.device.bean.WatchInfo;
import com.jieli.healthaide.ui.device.bean.WatchOpData;
import com.jieli.healthaide.util.HealthUtil;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.interfaces.OnFatFileProgressListener;
import com.jieli.jl_fatfs.model.FatFile;
import com.jieli.jl_fatfs.utils.FatUtil;
import com.jieli.jl_rcsp.constant.JLChipFlag;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.model.response.ExternalFlashMsgResponse;
import com.jieli.jl_rcsp.util.JL_Log;

import java.io.File;
import java.util.ArrayList;

public class CustomWatchBgViewModel extends ViewModel {
    private final static String TAG = CustomWatchBgViewModel.class.getSimpleName();
    private final WatchManager mWatchManager = WatchManager.getInstance();
    public WatchInfo mWatchInfo;
    private final BmpConvert mBmpConvert;

    public File mPhotoSavePath;
    public Uri mCameraUri;

    public final MutableLiveData<DeviceConnectionData> mConnectionDataMLD = new MutableLiveData<>();
    public final MutableLiveData<CustomBgStatus> mCustomBgStatusMLD = new MutableLiveData<>();
    public final MutableLiveData<WatchInfo> mCurrentWatchMLD = new MutableLiveData<>();
    public final MutableLiveData<WatchOpData> mWatchOpDataMLD = new MutableLiveData<>();
    public final MutableLiveData<Boolean> mChangeWatchMLD = new MutableLiveData<>();

    private final static String WATCH_PREFIX = "WATCH";
    private final static String CUSTOM_BG_PREFIX = "bgp_w";
    private final static String JPG_FORMAT = ".jpg";

    public CustomWatchBgViewModel() {
        mBmpConvert = new BmpConvert();
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
    }

    /**
     * 获取自定义背景文件名
     *
     * @return 自定义背景文件名
     */
    public String getCustomBgName() {
        if (mWatchInfo == null) return CUSTOM_BG_PREFIX + formatSeq(0) + JPG_FORMAT;
        String watchName = mWatchInfo.getName().toUpperCase();
        if (!watchName.contains(WATCH_PREFIX)) {
            return CUSTOM_BG_PREFIX + formatSeq(0) + JPG_FORMAT;
        }
        int seq = 0;
        if (!watchName.equals(WATCH_PREFIX)) {
            watchName = watchName.replaceAll(WATCH_PREFIX, "");
            try {
                seq = Integer.parseInt(watchName);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return CUSTOM_BG_PREFIX + formatSeq(seq) + JPG_FORMAT;
    }

    /**
     * 使能自定义背景
     *
     * <p>
     * 实现流程<br>
     * Step0. 缩放图像到指定尺寸
     * Step1. 压缩图像成为表盘背景格式
     * Step2. 添加自定义背景文件
     * Step3. 绑定自定义背景
     * </p>
     *
     * @param path         图像文件路径
     * @param targetWidth  指定宽度
     * @param targetHeight 指定高度
     */
    public void enableCustomBg(String path, int targetWidth, int targetHeight) {
        if (targetWidth == 0 || targetHeight == 0) {
            postCustomBgFail(FatFsErrCode.RES_ERR_PARAM, FatUtil.getFatFsErrorCodeMsg(FatFsErrCode.RES_ERR_PARAM));
            return;
        }
        String targetPath = HealthUtil.saveScaleBitmap(path, targetWidth, targetHeight, 100);
        if (null == targetPath) {
            postCustomBgFail(FatFsErrCode.RES_NO_PATH, FatUtil.getFatFsErrorCodeMsg(FatFsErrCode.RES_NO_PATH));
            return;
        }
        if (isCallWorkState()) {
            postCustomBgFail(FatFsErrCode.RES_ERR_BEGIN, HealthApplication.getAppViewModel().getApplication().getString(R.string.call_phone_error_tips));
            return;
        }
        String outPath = getOutPath(targetPath);
        JL_Log.i(TAG, "-enableCustomBg- targetPath = " + targetPath + ", outPath = " + outPath);
        DeviceInfo deviceInfo = mWatchManager.getDeviceInfo(mWatchManager.getConnectedDevice());
        if (deviceInfo == null) {
            postCustomBgFail(FatFsErrCode.RES_NOT_READY, "can not read device sdk type");
            return;
        }
        int type = deviceInfo.getSdkType() == JLChipFlag.JL_CHIP_FLAG_701X_WATCH ? BmpConvert.TYPE_BR_28 : BmpConvert.TYPE_BR_23;
        mBmpConvert.bitmapConvert(type, path, outPath, new OnConvertListener() {
            @Override
            public void onStart(String path) {
                JL_Log.d(TAG, "bitmapConvert start path = " + path);
                postCustomBgStart(path);
            }

            @Override
            public void onStop(boolean result, final String output) {
                JL_Log.w(TAG, "bitmapConvert onStop result = " + result + ", output = " + output);
                if (result) {
                    mWatchManager.addFatFile(output, true, new OnFatFileProgressListener() {

                        @Override
                        public void onStart(String filePath) {

                        }

                        @Override
                        public void onProgress(float progress) {
                            if (progress >= 100) {
                                progress = 99.9f;
                            }
                            postCustomBgProgress(progress);
                        }

                        @Override
                        public void onStop(int result) {
                            if (result == FatFsErrCode.RES_OK) {
                                mWatchManager.enableWatchCustomBg(FatUtil.getFatFilePath(output), new OnWatchOpCallback<FatFile>() {
                                    @Override
                                    public void onSuccess(FatFile result) {
                                        postCustomBgFinish();
                                        mWatchManager.getCurrentWatchMsg(new OnWatchOpCallback<WatchInfo>() {
                                            @Override
                                            public void onSuccess(WatchInfo result) {
                                                if (isSameWatchInfo(result)) {
                                                    mWatchInfo = result;
                                                    mCurrentWatchMLD.postValue(mWatchInfo);
                                                } else {
                                                    mChangeWatchMLD.postValue(true);
                                                }
                                            }

                                            @Override
                                            public void onFailed(BaseError error) {

                                            }
                                        });
                                    }

                                    @Override
                                    public void onFailed(BaseError error) {
                                        postCustomBgFail(error.getSubCode(), error.getMessage());
                                    }
                                });
                            } else {
                                postCustomBgFail(result, FatUtil.getFatFsErrorCodeMsg(result));
                            }
                        }
                    });
                } else {
                    postCustomBgFail(FatFsErrCode.RES_NOT_READY, "Image conversion failed.");
                }
            }
        });
    }


    public void restoreCustomBg() {
        //方案一，直接解绑背景文件。
        /*mWatchManager.enableCustomWatchBg("/null", new OnWatchOpCallback<FatFile>() {
            @Override
            public void onSuccess(FatFile result) {

            }

            @Override
            public void onFailed(BaseError error) {

            }
        });*/
        //方案二，删除背景文件
        if (!mWatchInfo.hasCustomBgFatPath()) {
            mWatchManager.getCurrentWatchMsg(new OnWatchOpCallback<WatchInfo>() {
                @Override
                public void onSuccess(WatchInfo result) {
                    if (isSameWatchInfo(result)) {
                        mWatchInfo = result;
                        mCurrentWatchMLD.postValue(mWatchInfo);
                        if (result.hasCustomBgFatPath()) {
                            deleteCustomBg(mWatchInfo.getCustomBgFatPath());
                        }
                    } else {
                        mChangeWatchMLD.postValue(true);
                    }
                }

                @Override
                public void onFailed(BaseError error) {
                    postDeleteCustomBgEnd(FatFsErrCode.RES_RCSP_SEND);
                }
            });
        } else {
            deleteCustomBg(mWatchInfo.getCustomBgFatPath());
        }
    }

    public int getWatchWidth() {
        if (mWatchManager.getConnectedDevice() == null) {
            return 0;
        }
        int width = 240;
        ExternalFlashMsgResponse flashMsg = mWatchManager.getExternalFlashMsg(mWatchManager.getConnectedDevice());
        if (flashMsg != null && flashMsg.getScreenWidth() > 0) {
            width = flashMsg.getScreenWidth();
        }
        return width;
    }

    public int getWatchHeight() {
        if (mWatchManager.getConnectedDevice() == null) {
            return 0;
        }
        int height = 280;
        ExternalFlashMsgResponse flashMsg = mWatchManager.getExternalFlashMsg(mWatchManager.getConnectedDevice());
        if (flashMsg != null && flashMsg.getScreenHeight() > 0) {
            height = flashMsg.getScreenHeight();
        }
        return height;
    }

    private boolean isCallWorkState() {
        return PhoneHelper.getInstance().isCallWorking();
    }

    private void deleteCustomBg(String fatFilePath) {
        mWatchManager.deleteWatchFile(fatFilePath, new OnFatFileProgressListener() {
            @Override
            public void onStart(String filePath) {
                postDeleteCustomBgStart(filePath);
            }

            @Override
            public void onProgress(float progress) {
                postDeleteCustomBgProgress(progress);
            }

            @Override
            public void onStop(int result) {
                if (result == FatFsErrCode.RES_OK) {
                    mWatchManager.updateWatchFileListByDevice(new OnWatchOpCallback<ArrayList<WatchInfo>>() {
                        @Override
                        public void onSuccess(ArrayList<WatchInfo> result) {
                            WatchInfo info = mWatchManager.getWatchInfoByFatFile(mWatchInfo.getWatchFile());
                            if (isSameWatchInfo(info)) {
                                mWatchInfo = info;
                                mCurrentWatchMLD.postValue(mWatchInfo);
                            } else {
                                mChangeWatchMLD.postValue(true);
                            }
                            postDeleteCustomBgEnd(FatFsErrCode.RES_OK);
                        }

                        @Override
                        public void onFailed(BaseError error) {
                            postDeleteCustomBgEnd(FatFsErrCode.RES_RCSP_SEND);
                        }
                    });
                } else {
                    postDeleteCustomBgEnd(result);
                }
            }
        });
    }

    public void destroy() {
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        mBmpConvert.release();
    }

    private boolean isSameWatchInfo(WatchInfo info) {
        return info != null && mWatchInfo != null && info.getWatchFile() != null
                && info.getWatchFile().getPath().equals(mWatchInfo.getWatchFile().getPath());
    }

    private String formatSeq(int seq) {
        if (seq < 10) {
            return "00" + seq;
        } else if (seq < 100) {
            return "0" + seq;
        } else {
            return String.valueOf(seq);
        }
    }

    private String getOutPath(String path) {
        if (path.contains(".jpg")) {
            return path.substring(0, path.lastIndexOf(".jpg"));
        } else if (path.contains("\\.")) {
            return path.substring(0, path.lastIndexOf("."));
        } else {
            return path;
        }
    }

    private void postCustomBgStart(String filePath) {
        CustomBgStatus status = new CustomBgStatus();
        status.setStatus(CustomBgStatus.STATUS_START);
        status.setFilePath(FatUtil.getFatFilePath(filePath));
        mCustomBgStatusMLD.setValue(status);
    }

    private void postCustomBgProgress(float progress) {
        CustomBgStatus status = new CustomBgStatus();
        status.setStatus(CustomBgStatus.STATUS_PROGRESS);
        status.setProgress(progress);
        mCustomBgStatusMLD.setValue(status);
    }

    private void postCustomBgFinish() {
        CustomBgStatus status = new CustomBgStatus();
        status.setStatus(CustomBgStatus.STATUS_END);
        status.setResult(true);
        mCustomBgStatusMLD.setValue(status);
    }

    private void postCustomBgFail(int code, String message) {
        CustomBgStatus status = new CustomBgStatus();
        status.setStatus(CustomBgStatus.STATUS_END);
        status.setResult(false);
        status.setCode(code);
        status.setMessage(message);
        mCustomBgStatusMLD.setValue(status);
    }

    private void postDeleteCustomBgStart(String filePath) {
        WatchOpData opData = new WatchOpData();
        opData.setOp(WatchOpData.OP_DELETE_FILE);
        opData.setState(WatchOpData.STATE_START);
        opData.setFilePath(filePath);
        mWatchOpDataMLD.setValue(opData);
    }

    private void postDeleteCustomBgProgress(float progress) {
        WatchOpData opData = new WatchOpData();
        opData.setOp(WatchOpData.OP_DELETE_FILE);
        opData.setState(WatchOpData.STATE_PROGRESS);
        opData.setProgress(progress);
        mWatchOpDataMLD.setValue(opData);
    }

    private void postDeleteCustomBgEnd(int result) {
        WatchOpData opData = new WatchOpData();
        opData.setOp(WatchOpData.OP_DELETE_FILE);
        opData.setState(WatchOpData.STATE_END);
        opData.setResult(result);
        mWatchOpDataMLD.setValue(opData);
    }

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {
        @Override
        public void onConnectStateChange(BluetoothDevice device, int status) {
            mConnectionDataMLD.setValue(new DeviceConnectionData(device, status));
        }

        @Override
        public void onCurrentWatchInfo(BluetoothDevice device, String fatFilePath) {
            WatchInfo info = mWatchManager.getWatchInfoByPath(fatFilePath);
            if (isSameWatchInfo(info)) {
                mWatchInfo = info;
                mCurrentWatchMLD.postValue(mWatchInfo);
            } else {
                mChangeWatchMLD.postValue(true);
            }
        }
    };

    public static class CustomBgStatus {
        private int status;
        private float progress;
        private boolean result;
        private int code;
        private String message;
        private String filePath;

        public final static int STATUS_END = 0;
        public final static int STATUS_START = 1;
        public final static int STATUS_PROGRESS = 2;

        public int getStatus() {
            return status;
        }

        public void setStatus(int status) {
            this.status = status;
        }

        public float getProgress() {
            return progress;
        }

        public void setProgress(float progress) {
            this.progress = progress;
        }

        public boolean isResult() {
            return result;
        }

        public void setResult(boolean result) {
            this.result = result;
        }

        public int getCode() {
            return code;
        }

        public void setCode(int code) {
            this.code = code;
        }

        public String getMessage() {
            return message;
        }

        public void setMessage(String message) {
            this.message = message;
        }

        public String getFilePath() {
            return filePath;
        }

        public void setFilePath(String filePath) {
            this.filePath = filePath;
        }

        @NonNull
        @Override
        public String toString() {
            return "CustomBgStatus{" +
                    "status=" + status +
                    ", progress=" + progress +
                    ", result=" + result +
                    ", code=" + code +
                    ", message='" + message + '\'' +
                    ", filePath='" + filePath + '\'' +
                    '}';
        }
    }
}