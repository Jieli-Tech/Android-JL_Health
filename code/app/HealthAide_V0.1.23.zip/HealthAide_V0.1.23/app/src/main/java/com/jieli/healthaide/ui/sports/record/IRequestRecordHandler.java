package com.jieli.healthaide.ui.sports.record;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/11/4
 * @desc :
 */
public interface IRequestRecordHandler {

    void request();
}
