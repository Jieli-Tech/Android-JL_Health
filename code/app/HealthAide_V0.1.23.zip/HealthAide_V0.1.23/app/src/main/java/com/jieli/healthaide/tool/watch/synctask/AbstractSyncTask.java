package com.jieli.healthaide.tool.watch.synctask;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 2021/11/1
 * @desc :
 */
public abstract class AbstractSyncTask implements SyncTask {
    protected SyncTaskFinishListener finishListener;
    final String tag = getClass().getSimpleName();

    public AbstractSyncTask(SyncTaskFinishListener finishListener) {
        this.finishListener = finishListener;
    }

    @Override
    public void setFinishListener(SyncTaskFinishListener finishListener) {
        this.finishListener = finishListener;
    }
}
