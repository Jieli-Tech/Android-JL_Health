package com.jieli.healthaide.ui.mine.about;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.component.utils.SystemUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentAboutBinding;
import com.jieli.healthaide.ui.base.BaseFragment;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/11/21 9:19 AM
 * @desc : 关于界面
 */
public class AboutFragment extends BaseFragment {

    private AboutViewModel mViewModel;
    private FragmentAboutBinding binding;

    public static AboutFragment newInstance() {
        return new AboutFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        binding = FragmentAboutBinding.inflate(inflater, container, false);
        binding.viewTopbar.tvTopbarTitle.setText(R.string.mine_about);
        binding.tvAboutAppVersion.setText(getString(R.string.current_app_version, SystemUtil.getVersioName(requireContext())));
        binding.viewTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        binding.tvAboutPolicy.setOnClickListener(v -> WebFragment.start(requireContext(), getString(R.string.privacy_policy), getString(R.string.app_privacy_policy)));
        binding.tvAboutUserAgreement.setOnClickListener(v -> WebFragment.start(requireContext(), getString(R.string.user_agreement), getString(R.string.user_agreement_url)));
        return binding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(AboutViewModel.class);

    }

}