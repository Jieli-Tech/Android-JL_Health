package com.jieli.healthaide.tool.watch.synctask;

import android.text.TextUtils;

import com.jieli.bluetooth_connect.util.JL_Log;
import com.jieli.component.utils.FileUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.data.dao.SportRecordDao;
import com.jieli.healthaide.data.db.HealthDatabase;
import com.jieli.healthaide.data.entity.SportRecord;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.FileStruct;
import com.jieli.jl_filebrowse.bean.Folder;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_filebrowse.interfaces.FileObserver;
import com.jieli.jl_filebrowse.interfaces.SimpleFileObserver;
import com.jieli.jl_filebrowse.util.DeviceChoseUtil;
import com.jieli.jl_rcsp.model.command.file_op.SmallFileTransferCmd;
import com.jieli.jl_rcsp.task.GetFileByClusterTask;
import com.jieli.jl_rcsp.task.ITask;
import com.jieli.jl_rcsp.task.SimpleTaskListener;
import com.jieli.jl_rcsp.task.TaskListener;
import com.jieli.jl_rcsp.task.smallfile.QueryFileTask;
import com.jieli.jl_rcsp.task.smallfile.ReadFileTask;
import com.jieli.jl_rcsp.util.CHexConver;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 5/7/21
 * @desc : 同步固件的运动记录到手机
 */
public class DeviceSportRecordSyncTaskModify extends SmallFileSyncTask {


    public DeviceSportRecordSyncTaskModify(SyncTaskFinishListener finishListener) {
        super(QueryFileTask.TYPE_SPORTS_RECORD, finishListener);

    }

    @Override
    public void start() {
        JL_Log.d(tag, "----------- DeviceSportRecordSyncTaskModify start-----------");
//        HealthDatabase.buildHealthDb(HealthApplication.getAppViewModel().getApplication()).SportRecordDao().clean();
        super.start();
    }

    @Override
    protected boolean isInLocal(byte[] data) {
        SportRecord sportRecord = SportRecord.fromHeader(data);

        String uid = HealthApplication.getAppViewModel().getUid();

        if (TextUtils.isEmpty(uid)) {
            JL_Log.w(tag, "-----------isInLocal uid isEmpty-----------");
            return false;
        }
        JL_Log.d(tag, "isInLocal sportRecord:" + sportRecord);
        sportRecord.setUid(uid);
        SportRecordDao sportRecordDao = HealthDatabase.buildHealthDb(HealthApplication.getAppViewModel().getApplication()).SportRecordDao();
        SportRecord dbRecord = sportRecordDao.findByStartTime(uid, sportRecord.getStartTime());
        boolean ret =  dbRecord != null && dbRecord.getStartTime() == sportRecord.getStartTime();
        JL_Log.w(tag, "-----------isInLocal ret----------"+ret);
        return  ret;
    }

    @Override
    protected void saveToDb(byte[] data) {
        JL_Log.w(tag, "----------- 保存运动记录到本地数据库----------");

        String uid = HealthApplication.getAppViewModel().getUid();
        if (TextUtils.isEmpty(uid)) {
            JL_Log.w(tag, "----------- uid isEmpty-----------");
            return;
        }
        SportRecord sportRecord = SportRecord.from(data);
        sportRecord.setUid(uid);
        SportRecordDao sportRecordDao = HealthDatabase.buildHealthDb(HealthApplication.getAppViewModel().getApplication()).SportRecordDao();
        sportRecordDao.insert(sportRecord);
    }
}
