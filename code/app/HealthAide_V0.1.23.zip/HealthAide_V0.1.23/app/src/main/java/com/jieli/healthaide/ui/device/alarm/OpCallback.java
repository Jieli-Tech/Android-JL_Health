package com.jieli.healthaide.ui.device.alarm;

public interface OpCallback<T> {
    void back(T t);
}
