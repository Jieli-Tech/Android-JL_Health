package com.jieli.healthaide.tool.watch;

import android.os.Handler;
import android.os.Looper;

import com.jieli.component.thread.ThreadManager;
import com.jieli.healthaide.ui.device.bean.WatchInfo;
import com.jieli.healthaide.util.HealthConstant;
import com.jieli.healthaide.util.HealthUtil;
import com.jieli.jl_fatfs.FatFsErrCode;
import com.jieli.jl_fatfs.model.FatFile;
import com.jieli.jl_rcsp.impl.WatchOpImpl;
import com.jieli.jl_rcsp.interfaces.listener.ThreadStateListener;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchOpCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.util.JL_Log;

import java.util.ArrayList;
import java.util.List;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc  获取表盘额外信息任务
 * @since 2021/3/31
 */
public class GetWatchMsgTask extends Thread {
    private final static String TAG = HealthConstant.WATCH_TAG; //GetWatchMsgTask.class.getSimpleName();
    private final WatchOpImpl mWatchOp;
    private final List<FatFile> taskList;
    private final OnWatchOpCallback<ArrayList<WatchInfo>> mCallback;
    private final ThreadStateListener mStateListener;
    private final ArrayList<WatchInfo> watchList = new ArrayList<>();

    private final Handler mHandler = new Handler(Looper.getMainLooper());
    private final Object mLock = new Object();
    private volatile boolean isLock;

    public GetWatchMsgTask(WatchOpImpl impl, List<FatFile> list, OnWatchOpCallback<ArrayList<WatchInfo>> callback, ThreadStateListener listener) {
        mWatchOp = impl;
        taskList = list;
        mCallback = callback;
        mStateListener = listener;
    }

    @Override
    public synchronized void start() {
//        super.start();
        ThreadManager.getInstance().postRunnable(this);
    }

    @Override
    public void run() {
        if (null != mStateListener) mStateListener.onStart(getId());
        if (taskList == null || taskList.isEmpty()) return;
        synchronized (mLock) {
            for (final FatFile watchFile : taskList) {
                isLock = false;
                JL_Log.i(TAG, "getWatchMessage >>> fatFilePath = " + watchFile.getPath());
                mWatchOp.getWatchMessage(watchFile.getPath(), new OnWatchOpCallback<String>() {
                    @Override
                    public void onSuccess(String result) {
                        final String watchMsg = result;
                        JL_Log.i(TAG, "getWatchMessage >>> -onSuccess- result = " + result + ", path = " + watchFile.getPath());
                        mWatchOp.getCustomWatchBgInfo(watchFile.getPath(), new OnWatchOpCallback<String>() {
                            @Override
                            public void onSuccess(String result) {
                                JL_Log.d(TAG, "getCustomWatchBgInfo >>> -onSuccess- result = " + result + ", path = " + watchFile.getPath());
                                String customBgPath = result;
                                if (!"null".equalsIgnoreCase(customBgPath)) {
                                    customBgPath = "/" + HealthUtil.getFileNameByPath(result).toUpperCase();
                                }
                                String version = watchMsg;
                                String uuid = "";
                                if (version != null && version.contains(",")) {
                                    String[] array = version.split(",");
                                    if (array.length > 0) {
                                        version = array[0];
                                        if (array.length > 1) {
                                            uuid = array[1];
                                        }
                                    }
                                }
                                WatchInfo watchInfo = new WatchInfo()
                                        .setName(watchFile.getName())
                                        .setWatchFile(watchFile)
                                        .setVersion(version)
                                        .setUuid(uuid)
                                        .setSize(watchFile.getSize() * 4 * 1024)
                                        .setStatus(WatchInfo.WATCH_STATUS_EXIST)
                                        .setCustomBgFatPath(customBgPath);
                                watchList.add(watchInfo);

                                synchronized (mLock) {
                                    if (isLock) {
                                        mLock.notify();
                                    }
                                }
                            }

                            @Override
                            public void onFailed(BaseError error) {
                                JL_Log.e(TAG, "getCustomWatchBgInfo >>> -onFailed- error = " + error);
                                synchronized (mLock) {
                                    if (isLock) {
                                        mLock.notify();
                                    }
                                }
                            }
                        });
                    }

                    @Override
                    public void onFailed(BaseError error) {
                        JL_Log.e(TAG, "getWatchMessage >>> -onFailed- error = " + error);
                        synchronized (mLock) {
                            if (isLock) {
                                mLock.notify();
                            }
                        }
                    }
                });
                isLock = true;
                try {
                    mLock.wait();
                } catch (InterruptedException e) {
                    e.printStackTrace();
                    isLock = false;
                }
            }
            if (mCallback != null) {
                mHandler.post(() -> {
                    if (watchList.isEmpty()) {
                        mCallback.onFailed(new BaseError(FatFsErrCode.RES_RCSP_SEND, "request watch message failed."));
                    } else {
                        mCallback.onSuccess(watchList);
                    }
                });
            }
        }
        if (null != mStateListener) mStateListener.onFinish(getId());
    }
}
