package com.jieli.healthaide.ui.device;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.lifecycle.ViewModelProvider;

import com.bumptech.glide.Glide;
import com.bumptech.glide.load.engine.DiskCacheStrategy;
import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentHistoryRecordBinding;
import com.jieli.healthaide.tool.net.NetworkStateHelper;
import com.jieli.healthaide.ui.base.BaseFragment;
import com.jieli.healthaide.ui.device.bean.DeviceHistoryRecord;
import com.jieli.healthaide.ui.dialog.RequireGPSDialog;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.util.PermissionUtil;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.util.JL_Log;
import com.jieli.jl_rcsp.util.RcspUtil;

import permissions.dispatcher.NeedsPermission;
import permissions.dispatcher.OnNeverAskAgain;
import permissions.dispatcher.OnPermissionDenied;
import permissions.dispatcher.OnShowRationale;
import permissions.dispatcher.PermissionRequest;
import permissions.dispatcher.RuntimePermissions;

/**
 * 历史记录操作界面
 */
@RuntimePermissions
public class HistoryRecordFragment extends BaseFragment {

    private FragmentHistoryRecordBinding mBinding;
    private HistoryRecordViewModel mViewModel;

    private WaitingDialog mWaitingDialog;

    public final static String KEY_HISTORY_RECORD = "history_record";
    private final static int REQUEST_CODE_ENABLE_BT_AND_RECONNECT = 1692;
    private final static int REQUEST_CODE_ENABLE_BT_AND_DELETE = 1693;

    private final Handler mUIHandler = new Handler();
    private boolean isDeleteOk = false;  //是否删除设备记录

    public static HistoryRecordFragment newInstance() {
        return new HistoryRecordFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        mBinding = FragmentHistoryRecordBinding.inflate(inflater, container, false);
        return mBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        if (null == getArguments()) {
            requireActivity().finish();
            return;
        }
        DeviceHistoryRecord record = getArguments().getParcelable(KEY_HISTORY_RECORD);
        if (null == record) {
            requireActivity().finish();
            return;
        }

        mBinding.clHistoryDeviceTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().finish());
        mBinding.tvHistoryDeviceReconnect.setOnClickListener(v -> {
            HistoryRecordFragmentPermissionsDispatcher.reconnectHistoryWithPermissionCheck(this);
//            reconnectHistory();
        });
        mBinding.tvHistoryDeviceDelete.setOnClickListener(v -> {
            if (!BluetoothUtil.isBluetoothEnable()) {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_CODE_ENABLE_BT_AND_DELETE);
                return;
            }
            showWaitingDialog();
            mViewModel.removeHistory();
        });
        mBinding.clHistoryDeviceTopbar.tvTopbarTitle.setText(record.getHistoryRecord().getName());

        mViewModel = new ViewModelProvider(this, new HistoryRecordViewModel.HistoryRecordViewModelFactory(this)).get(HistoryRecordViewModel.class);
        mViewModel.historyRecord = record;
        mViewModel.mRecordGoneMLD.observe(getViewLifecycleOwner(), aBoolean ->
                //延时执行，防止受到删除设备的影响
                mUIHandler.postDelayed(() -> {
                    if (isDeleteOk) return;
                    ToastUtil.showToastShort(getString(R.string.history_is_gone));
                    requireActivity().finish();
                }, 1000));
        mViewModel.mConnectionDataMLD.observe(getViewLifecycleOwner(), deviceConnectionData -> requireActivity().runOnUiThread(() -> {
            BluetoothDevice cacheDevice = RcspUtil.getRemoteDevice(mViewModel.historyRecord.getHistoryRecord().getAddress());
            if (mViewModel.isMatchDevice(deviceConnectionData.getDevice(), cacheDevice)) {
                boolean isConnected = deviceConnectionData.getStatus() == BluetoothConstant.CONNECT_STATE_CONNECTED;
                updateReconnectUI(isConnected);
            }
        }));
        mViewModel.mRemoveResultMLD.observe(getViewLifecycleOwner(), historyRemoveResult -> {
            dismissWaitingDialog();
            if (historyRemoveResult.isResult()) {
                isDeleteOk = true;
                ToastUtil.showToastShort(getString(R.string.remove_history_success));
                requireActivity().finish();
            } else {
                ToastUtil.showToastShort(getString(R.string.remove_history_failed));
            }
        });
        mViewModel.mHistoryConnectStatusMLD.observe(getViewLifecycleOwner(), historyConnectStatus -> {
            if (historyConnectStatus.getConnectStatus() == StateCode.CONNECTION_CONNECTING) {
                showWaitingDialog();
            } else {
                dismissWaitingDialog();
                if (historyConnectStatus.getConnectStatus() == StateCode.CONNECTION_OK) {
                    ToastUtil.showToastShort(R.string.history_connect_ok);
                    requireActivity().finish();
                } else {
                    ToastUtil.showToastShort(R.string.history_connect_failed);
                }
            }
        });
        mViewModel.mWatchProductMsgResultMLD.observe(getViewLifecycleOwner(), watchProductMsgResult -> {
            if (watchProductMsgResult.isOk()) {
                updateImageView(requireContext(), mBinding.ivHistoryDeviceProduct, watchProductMsgResult.getProduct().getIcon());
            } else {
                if (!NetworkStateHelper.getInstance().getNetWorkStateModel().isAvailable()) {
                    ToastUtil.showToastShort(getString(R.string.tip_check_net));
                } else {
                    JL_Log.e(tag, "request message error: " + watchProductMsgResult.getMessage());
                }
            }
        });

        updateReconnectUI(mViewModel.isConnectedDevice(RcspUtil.getRemoteDevice(record.getHistoryRecord().getAddress())));
        mViewModel.getHistoryProductMsg();
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        switch (requestCode) {
            case REQUEST_CODE_ENABLE_BT_AND_RECONNECT:
                if (BluetoothUtil.isBluetoothEnable()) {
                    mViewModel.reconnectHistory(mViewModel.historyRecord);
                } else {
                    ToastUtil.showToastShort(R.string.history_connect_failed);
                }
                break;
            case REQUEST_CODE_ENABLE_BT_AND_DELETE:
                showWaitingDialog();
                mViewModel.removeHistory();
                break;
        }
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        HistoryRecordFragmentPermissionsDispatcher.onRequestPermissionsResult(this, requestCode, grantResults);
    }

    @Override
    public void onDestroyView() {
        mUIHandler.removeCallbacksAndMessages(null);
        super.onDestroyView();
        mViewModel.release();
    }

    private void updateReconnectUI(boolean isConnected) {
        mBinding.tvHistoryDeviceReconnect.setVisibility(isConnected ? View.INVISIBLE : View.VISIBLE);
    }

    private void showWaitingDialog() {
        if (!isFragmentValid()) return;
        if (mWaitingDialog == null) {
            mWaitingDialog = new WaitingDialog(true);
        }
        if (!mWaitingDialog.isShow()) {
            mWaitingDialog.show(getChildFragmentManager(), WaitingDialog.class.getSimpleName());
        }
    }

    private void dismissWaitingDialog() {
        if (!isFragmentValid()) return;
        if (mWaitingDialog != null) {
            if (mWaitingDialog.isShow()) {
                mWaitingDialog.dismiss();
            }
            mWaitingDialog = null;
        }
    }

    private void updateImageView(Context context, ImageView imageView, String url) {
        if (null == url) {
            imageView.setImageResource(R.drawable.ic_watch_big);
            return;
        }
        JL_Log.d("zzc_watch", "-updateImageView- url = " + url);
        boolean isGif = url.endsWith(".gif");
        if (isGif) {
            Glide.with(context).asGif().load(url)
                    .diskCacheStrategy(DiskCacheStrategy.RESOURCE)
                    .error(R.drawable.ic_watch_big)
                    .into(imageView);
        } else {
            Glide.with(context).asBitmap().load(url)
                    .diskCacheStrategy(DiskCacheStrategy.ALL)
                    .error(R.drawable.ic_watch_big)
                    .into(imageView);
        }
    }

    @NeedsPermission({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void reconnectHistory() {
        if (!PermissionUtil.checkGpsProviderEnable(getContext())) {
            showOpenGPSDialog();
        } else {
            if (BluetoothUtil.isBluetoothEnable()) {
                mViewModel.reconnectHistory(mViewModel.historyRecord);
            } else {
                startActivityForResult(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE), REQUEST_CODE_ENABLE_BT_AND_RECONNECT);
            }
        }
    }

    @OnShowRationale({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void showRelationForLocationPermission(PermissionRequest request) {
        showRequireGPSPermissionDialog(request);
    }

    @OnPermissionDenied({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void onLocationDenied() {
        ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
    }

    @OnNeverAskAgain({
            Manifest.permission.ACCESS_COARSE_LOCATION,
            Manifest.permission.ACCESS_FINE_LOCATION,
    })
    public void onLocationNeverAskAgain() {
        ToastUtil.showToastShort(getString(R.string.user_denies_permissions, getString(R.string.app_name)));
    }

    private void showOpenGPSDialog() {
        showGPSDialog(null, true);
    }

    private void showRequireGPSPermissionDialog(PermissionRequest request) {
        showGPSDialog(request, false);
    }

    private void showGPSDialog(PermissionRequest request, boolean isLocationService) {
        RequireGPSDialog requireGPSDialog = new RequireGPSDialog(RequireGPSDialog.VIEW_TYPE_DEVICE, request);
        requireGPSDialog.setLocationService(isLocationService);
        requireGPSDialog.setCancelable(true);
        requireGPSDialog.show(getChildFragmentManager(), RequireGPSDialog.class.getCanonicalName());
    }
}