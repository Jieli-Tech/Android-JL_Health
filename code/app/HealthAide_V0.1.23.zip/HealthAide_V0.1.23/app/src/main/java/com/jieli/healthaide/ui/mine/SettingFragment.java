package com.jieli.healthaide.ui.mine;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.DividerItemDecoration;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.OrientationHelper;

import com.jieli.component.utils.PreferencesHelper;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentSettingBinding;
import com.jieli.healthaide.tool.bluetooth.BluetoothHelper;
import com.jieli.healthaide.tool.notification.NotificationHelper;
import com.jieli.healthaide.tool.unit.BaseUnitConverter;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.device.more.MessageSyncFragment;
import com.jieli.healthaide.ui.dialog.SingleChooseDialog;
import com.jieli.healthaide.ui.mine.entries.CommonItem;
import com.jieli.healthaide.util.MultiLanguageUtils;
import com.jieli.jl_dialog.Jl_Dialog;

import java.util.ArrayList;
import java.util.List;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/10/21 9:44 AM
 * @desc :
 */
public class SettingFragment extends Fragment {

    FragmentSettingBinding settingBinding;

    private Jl_Dialog mEnableNotificationListenerDialog;

    private final static int TYPE_MESSAGE_SYNC = 1;
    private final static int TYPE_WEATHER_PUSH = 2;
    private final static int TYPE_UNIT_SETTINGS = 3;
    private final static int TYPE_LANGUAGE_SETTINGS = 4;

    @SuppressLint("UseCompatLoadingForDrawables")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        settingBinding = FragmentSettingBinding.inflate(inflater, container, false);
        settingBinding.layoutTopbar.tvTopbarTitle.setText(R.string.mine_setting);
        settingBinding.layoutAccountSecurity.tvSettingTarget2.setText(R.string.account_security);
        settingBinding.layoutAccountSecurity.getRoot().setOnClickListener(view -> ContentActivity.startContentActivity(requireContext(), AccountSecurityFragment.class.getCanonicalName()));
        settingBinding.layoutTarget.tvSettingTarget2.setText(getString(R.string.target));
        settingBinding.layoutTarget.getRoot().setOnClickListener(view -> ContentActivity.startContentActivity(requireContext(), MyTargetFragment.class.getCanonicalName()));
        settingBinding.layoutCleanCache.tvSettingTarget2.setText(getString(R.string.clean_cache));
        settingBinding.layoutCleanCache.getRoot().setOnClickListener(view -> cleanCache());
        CommonAdapter commonAdapter = new CommonAdapter();
        commonAdapter.setList(getCommonItemData());
        commonAdapter.setOnItemClickListener((adapter, view, position) -> {
            CommonItem item = ((CommonAdapter) adapter).getItem(position);
            if (null == item) return;
            switch (item.getType()) {
                case TYPE_MESSAGE_SYNC:
                    if (!NotificationHelper.isNotificationServiceEnabled(requireContext())) {
                        showEnableNotificationListenerDialog();
                    } else {
                        if (BluetoothHelper.getInstance().isConnectedDevice()) {
                            ContentActivity.startContentActivity(requireContext(), MessageSyncFragment.class.getCanonicalName());
                        } else {
                            ToastUtil.showToastShort(R.string.bt_disconnect_tips);
                        }
                    }
                    break;
                case TYPE_WEATHER_PUSH:
                    break;
                case TYPE_UNIT_SETTINGS:
                    List<String> data = new ArrayList<>();
                    data.add(getString(R.string.unit_metric));
                    data.add(getString(R.string.unit_imperial));
                    String select = commonAdapter.getItem(position).getTailString().toString();
                    SingleChooseDialog<String> chooseDialog = new SingleChooseDialog<>(getString(R.string.unit), data, select, (dialog, value) -> {
                        commonAdapter.getItem(position).setTailString(value);
                        commonAdapter.notifyItemChanged(position);
                        BaseUnitConverter.setType(value.equals(getString(R.string.unit_metric)) ? BaseUnitConverter.TYPE_METRIC : BaseUnitConverter.TYPE_IMPERIAL);
                        PreferencesHelper.putIntValue(requireContext(), "unit_converter_type", BaseUnitConverter.getType());
                        dialog.dismiss();
                    });
                    chooseDialog.show(requireFragmentManager(), "select_unit_type");
                    break;
                case TYPE_LANGUAGE_SETTINGS:
                    ContentActivity.startContentActivity(requireContext(), LanguageSetFragment.class.getCanonicalName());
                    break;
            }
        });
        settingBinding.rvSetting.setAdapter(commonAdapter);
        settingBinding.rvSetting.setLayoutManager(new LinearLayoutManager(requireContext()));
        DividerItemDecoration decoration = new DividerItemDecoration(requireContext(), OrientationHelper.VERTICAL);
        decoration.setDrawable(getResources().getDrawable(R.drawable.line_gray_1dp, requireActivity().getTheme()));
        settingBinding.rvSetting.addItemDecoration(decoration);
        settingBinding.layoutTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());

        settingBinding.layoutCleanCache.getRoot().setOnClickListener(v -> showCleanCacheDialog());
        return settingBinding.getRoot();
    }

    private List<CommonItem> getCommonItemData() {
        List<CommonItem> list = new ArrayList<>();

//        CommonItem notify = new CommonItem();
//        notify.setType(TYPE_MESSAGE_SYNC);
//        notify.setTitle(getString(R.string.alert));
//        notify.setShowNext(true);
//        list.add(notify);

//        CommonItem weatherPush = new CommonItem();
//        weatherPush.setType(TYPE_WEATHER_PUSH);
//        weatherPush.setTitle(getString(R.string.weather_push));
//        weatherPush.setShowSw(true);
//        list.add(weatherPush);

        CommonItem unitSetting = new CommonItem();
        unitSetting.setType(TYPE_UNIT_SETTINGS);
        unitSetting.setTitle(getString(R.string.unit_settings));
        unitSetting.setTailString(getString(BaseUnitConverter.getType() == BaseUnitConverter.TYPE_METRIC ? R.string.unit_metric : R.string.unit_imperial));
        unitSetting.setShowNext(true);
        list.add(unitSetting);

        String languageTailString = getString(R.string.follow_system);
        String language = PreferencesHelper.getSharedPreferences(HealthApplication.getAppViewModel().getApplication()).getString(MultiLanguageUtils.SP_LANGUAGE, MultiLanguageUtils.LANGUAGE_AUTO);
        if (TextUtils.equals(language, MultiLanguageUtils.LANGUAGE_ZH)) {
            languageTailString = getString(R.string.simplified_chinese);
        } else if (TextUtils.equals(language, MultiLanguageUtils.LANGUAGE_EN)) {
            languageTailString = getString(R.string.english);
        }
        CommonItem languageSetting = new CommonItem();
        languageSetting.setType(TYPE_LANGUAGE_SETTINGS);
        languageSetting.setTitle(getString(R.string.multilingual));
        languageSetting.setTailString(languageTailString);
        languageSetting.setShowNext(true);
        list.add(languageSetting);
        return list;
    }

    private void showEnableNotificationListenerDialog() {
        if (isDetached() || !isAdded()) return;
        if (null == mEnableNotificationListenerDialog) {
            mEnableNotificationListenerDialog = Jl_Dialog.builder()
                    .width(0.8f)
                    .cancel(true)
                    .content(getString(R.string.enable_notification_listener_service_tips))
                    .left(getString(R.string.cancel))
                    .leftColor(getResources().getColor(R.color.black))
                    .leftClickListener((view, dialogFragment) -> dismissEnableNotificationListenerDialog())
                    .right(getString(R.string.sure))
                    .rightColor(getResources().getColor(R.color.red_D25454))
                    .rightClickListener((view, dialogFragment) -> {
                        dismissEnableNotificationListenerDialog();
                        startActivity(new Intent(NotificationHelper.ACTION_NOTIFICATION_LISTENER_SETTINGS));
                    })
                    .build();
        }
        if (!mEnableNotificationListenerDialog.isShow()) {
            mEnableNotificationListenerDialog.show(getChildFragmentManager(), "notification_listener_service");
        }
    }


    private void showCleanCacheDialog() {
        String tag = "clean_cache_dialog";
        Fragment fragment = getChildFragmentManager().findFragmentByTag(tag);
        if (fragment != null) return;

        Jl_Dialog dialog = Jl_Dialog.builder()
                .width(0.8f)
                .cancel(true)
                .content(getString(R.string.tip_clean_cache))
                .left(getString(R.string.cancel))
                .leftColor(getResources().getColor(R.color.black))
                .leftClickListener((view, dialogFragment) -> dialogFragment.dismiss())
                .right(getString(R.string.sure))
                .rightColor(getResources().getColor(R.color.red_D25454))
                .rightClickListener((view, dialogFragment) -> {
                    dialogFragment.dismiss();
                    //todo 内存清理
                    HealthApplication.getAppViewModel().cleanCache();
                })
                .build();
        dialog.show(getChildFragmentManager(), tag);

    }


    private void dismissEnableNotificationListenerDialog() {
        if (isDetached() || !isAdded()) return;
        if (mEnableNotificationListenerDialog != null) {
            if (mEnableNotificationListenerDialog.isShow()) {
                mEnableNotificationListenerDialog.dismiss();
            }
            mEnableNotificationListenerDialog = null;
        }
    }

    private void cleanCache() {
        //todo 清除缓存
    }
}