package com.jieli.healthaide.ui.device.contact;

import androidx.annotation.NonNull;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/16/21 2:13 PM
 * @desc :
 */
public class Contact implements Cloneable{
    private String typeName ="手机";
    private String name;
    private String number;
    private String pinyinName;
    public String letterName;
    private String phoneUri;
    private boolean select;
    private int fileId;

    public String getTypeName() {
        return typeName;
    }

    public void setTypeName(String typeName) {
        this.typeName = typeName;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNumber() {
        return number;
    }

    public void setNumber(String number) {
        this.number = number;
    }

    public void setSelect(boolean select) {
        this.select = select;
    }

    public boolean isSelect() {
        return select;
    }


    public void setPinyinName(String pinyinName) {
        this.pinyinName = pinyinName;
    }

    public String getPinyinName() {
        return pinyinName;
    }

    public void setLetterName(String letterName) {
        this.letterName = letterName;
    }

    public String getLetterName() {
        return letterName;
    }

    public void setPhoneUri(String phoneUri) {
        this.phoneUri = phoneUri;
    }

    public String getPhoneUri() {
        return phoneUri;
    }


    public void setFileId(int fileId) {
        this.fileId = fileId;
    }

    public int getFileId() {
        return fileId;
    }

    @NonNull
    @Override
    protected Object clone() throws CloneNotSupportedException {
        return super.clone();
    }

    @Override
    public String toString() {
        return "Contact{" +
                "typeName='" + typeName + '\'' +
                ", name='" + name + '\'' +
                ", number='" + number + '\'' +
                ", pinyinName='" + pinyinName + '\'' +
                ", letterName='" + letterName + '\'' +
                ", phoneUrl='" + phoneUri + '\'' +
                ", select=" + select +
                '}';
    }
}
