package com.jieli.healthaide.ui.device.music;

import android.bluetooth.BluetoothDevice;
import android.content.Context;
import android.os.Build;

import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.jieli.component.thread.ThreadManager;
import com.jieli.component.utils.ToastUtil;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.R;
import com.jieli.healthaide.tool.phone.PhoneHelper;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.ui.device.bean.DeviceConnectionData;
import com.jieli.healthaide.ui.device.file.Util;
import com.jieli.jl_filebrowse.FileBrowseManager;
import com.jieli.jl_filebrowse.bean.SDCardBean;
import com.jieli.jl_filebrowse.util.DeviceChoseUtil;
import com.jieli.jl_rcsp.constant.StateCode;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.task.ITask;
import com.jieli.jl_rcsp.task.TaskListener;
import com.jieli.jl_rcsp.task.TransferTask;
import com.jieli.jl_rcsp.task.UriTransferTask;

import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * @author : chensenhua
 * @e-mail : chensenhua@zh-jieli.com
 * @date : 3/12/21 5:23 PM
 * @desc :
 */
public class MusicManagerViewModel extends ViewModel {
    static final int MODE_LIST = 0;
    static final int MODE_SELECT = 1;
    static final int MODE_DOWNLOAD = 2;

    private final WatchManager mWatchManager;
    MutableLiveData<List<Music>> musicsMutableLiveData = new MutableLiveData<>();
    MutableLiveData<Integer> modeLiveData = new MutableLiveData<>(MODE_SELECT);
    MutableLiveData<DeviceConnectionData> mConnectionDataMLD = new MutableLiveData<>();

    private ITask task;

    MutableLiveData<MusicDownloadEvent> downloadEventMutableLiveData = new MutableLiveData<>();

    public MusicManagerViewModel() {
        mWatchManager = WatchManager.getInstance();
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
    }


    @Override
    protected void onCleared() {
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        super.onCleared();
    }

    public void getMusicList(Context context) {
        ThreadManager.getInstance().postRunnable(() -> {
            JL_LocalMusicLoader loader = new JL_LocalMusicLoader(context.getContentResolver());
            musicsMutableLiveData.postValue(loader.loadAll());
        });
    }


    public void toNextMode() {
        if (FileBrowseManager.getInstance().getOnlineDev() == null || FileBrowseManager.getInstance().getOnlineDev().size() < 1) {
            ToastUtil.showToastShort(R.string.no_sdcard_device);
            return;
        }

        int mode = Objects.requireNonNull(modeLiveData.getValue()) + 1;
        if (mode > MODE_DOWNLOAD) {
            mode = 1;
        }
        modeLiveData.postValue(mode);
        if (mode == MODE_DOWNLOAD) {
            addToDownloadList();
        }
    }

    public void cancelSelect() {
        modeLiveData.postValue(MODE_SELECT);
    }

    private void addToDownloadList() {
        if (musicsMutableLiveData == null) {
            return;
        }
        if (PhoneHelper.getInstance().isCallWorking()) {
            downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_ERROR, 0, 0, 0,
                    HealthApplication.getAppViewModel().getApplication().getString(R.string.call_phone_error_tips)));
            return;
        }

        List<Music> tmp = new ArrayList<>();
        for (Music music : Objects.requireNonNull(musicsMutableLiveData.getValue())) {
            if (music.isSelected()) {
                tmp.add(music);
            }
        }
        if (tmp.size() < 1) {
            modeLiveData.postValue(MODE_SELECT);
            return;
        }

        ITask lastTask = null;
        int size = tmp.size();
        SDCardBean sdCardBean = DeviceChoseUtil.getTargetDev();
        for (int i = size - 1; i >= 0; i--) {
            Music music = tmp.get(i);
            TransferTask.Param p = new TransferTask.Param();
            if (sdCardBean == null) {
                downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_ERROR, i + 1, 0, 0, music.getTitle()));
                return;
            }
            p.devHandler = sdCardBean.getDevHandler();
            ITask task;
            if (Build.VERSION.SDK_INT > Build.VERSION_CODES.P) {
                task = new UriTransferTask(HealthApplication.getAppViewModel().getApplication(), mWatchManager, music.getUri(), music.getTitle(), p);
            } else {
                task = new TransferTask(mWatchManager, music.getUrl(), p);
            }
            //通过listener形成一个调用链
            task.setListener(new AutoLastListener(lastTask, i + 1, size, music.getTitle()));
            lastTask = task;
        }
        task = lastTask;
        task.start();
        Util.cleanDownloadDir(sdCardBean);
    }


    public void cancelTransfer() {
        if (task != null) {
            task.cancel((byte) 0x00);
        }
    }


    private class AutoLastListener implements TaskListener {

        private final int index;
        private final int total;
        private final String name;
        private final ITask last;

        public AutoLastListener(ITask last, int index, int total, String name) {
            this.index = index;
            this.total = total;
            this.name = name;
            this.last = last;
        }

        @Override
        public void onBegin() {
            downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_DOWNLOAD, index, total, 0, name));
        }


        @Override
        public void onProgress(int progress) {
            downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_DOWNLOAD, index, total, progress, name));

        }

        @Override
        public void onFinish() {
            task = last;
            if (last != null) {
                last.start();
            } else {
                modeLiveData.postValue(MODE_SELECT);
                MusicDownloadEvent musicDownloadEvent = downloadEventMutableLiveData.getValue();
                Objects.requireNonNull(musicDownloadEvent).setType(MusicDownloadEvent.TYPE_FINISH);
                downloadEventMutableLiveData.postValue(musicDownloadEvent);
            }
        }

        @Override
        public void onError(int code, String msg) {
            modeLiveData.postValue(MODE_SELECT);
            downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_ERROR, index, total, 0, name));
        }

        @Override
        public void onCancel(int reason) {
            modeLiveData.postValue(MODE_SELECT);
            downloadEventMutableLiveData.postValue(new MusicDownloadEvent(MusicDownloadEvent.TYPE_CANCEL, index, total, 0, name));
        }
    }

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {
        @Override
        public void onConnectStateChange(BluetoothDevice device, int status) {
            if (status != StateCode.CONNECTION_OK) {
                mConnectionDataMLD.setValue(new DeviceConnectionData(device, status));
            }
        }

        @Override
        public void onWatchSystemInit(int code) {
            if (code == 0) {
                mConnectionDataMLD.setValue(new DeviceConnectionData(mWatchManager.getConnectedDevice(), StateCode.CONNECTION_OK));
            }
        }
    };

}