package com.jieli.healthaide.ui.mine;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.jieli.healthaide.R;
import com.jieli.healthaide.databinding.FragmentAccountSecurityBinding;
import com.jieli.healthaide.ui.ContentActivity;
import com.jieli.healthaide.ui.dialog.DeleteAccountDialog;
import com.jieli.healthaide.ui.dialog.ModifyPhoneNumberDialog;
import com.jieli.healthaide.ui.dialog.UserAuthenticationDialog;
import com.jieli.healthaide.ui.dialog.WaitingDialog;
import com.jieli.healthaide.ui.login.SmsCodeViewModel;
import com.jieli.healthaide.util.phone.PhoneUtil;
import com.jieli.jl_health_http.model.UserLoginInfo;

/**
 * @ClassName: AccountSecurityFragment
 * @Description: java类作用描述
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/4/1 10:08
 */
public class AccountSecurityFragment extends Fragment {
    private FragmentAccountSecurityBinding fragmentAccountSecurityBinding;
    private UserLoginInfoViewModel userLoginInfoViewModel;
    private SmsCodeViewModel smsCodeViewModel;
    private WaitingDialog waitingDialog;
    public static int KEY_USER_LOGIN_INFO_VIEW_MODEL = 100;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);
        fragmentAccountSecurityBinding = FragmentAccountSecurityBinding.inflate(inflater, container, false);
        fragmentAccountSecurityBinding.layoutTopbar.tvTopbarTitle.setText(R.string.account_security);
        fragmentAccountSecurityBinding.layoutModifyPhoneNumber.tvSettingTarget2.setText(R.string.modify_phone_number);
        fragmentAccountSecurityBinding.layoutChangePassword.tvSettingTarget2.setText(R.string.change_password);
        initOnClick();
        fragmentAccountSecurityBinding.layoutTopbar.tvTopbarLeft.setOnClickListener(v -> requireActivity().onBackPressed());
        return fragmentAccountSecurityBinding.getRoot();
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        userLoginInfoViewModel = new ViewModelProvider(this).get(UserLoginInfoViewModel.class);
        userLoginInfoViewModel.userLoginInfoLiveData.observe(getViewLifecycleOwner(), data -> updateUserLoginInfoView(data));
        userLoginInfoViewModel.httpStateLiveData.observe(getViewLifecycleOwner(), state -> {
            switch (state) {
                case UserInfoViewModel.HTTP_STATE_REQUESTING:
                case UserInfoViewModel.HTTP_STATE_UPDATING:
                    if (waitingDialog == null) {
                        waitingDialog = new WaitingDialog();
                    }
                    waitingDialog.show(getChildFragmentManager(), waitingDialog.getClass().getCanonicalName());
                    break;
                default:
                    if (waitingDialog != null) {
                        waitingDialog.dismiss();
                    }
                    break;
            }
        });
        userLoginInfoViewModel.getUserLoginInfo();

    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != Activity.RESULT_OK) return;
        String mobile = data.getStringExtra(BindNewPhoneFragment.MSG_CHANGE_MOBILE);
        if (TextUtils.isEmpty(mobile)) return;
        userLoginInfoViewModel.updateMobileLocal(mobile);
    }

    private void initOnClick() {
        fragmentAccountSecurityBinding.layoutModifyPhoneNumber.getRoot().setOnClickListener(view -> {
            showModifyPhoneNumberDialog();
        });
        fragmentAccountSecurityBinding.layoutChangePassword.getRoot().setOnClickListener(view -> {
            ContentActivity.startContentActivity(requireContext(), ChangePasswordFragment.class.getCanonicalName());
        });
        fragmentAccountSecurityBinding.tvCancelAccount.setOnClickListener(v -> {
            showDeleteAccountDialog();
        });
    }

    private void updateUserLoginInfoView(UserLoginInfo userLoginInfo) {
        fragmentAccountSecurityBinding.layoutModifyPhoneNumber.tvHint.setText(userLoginInfo.getMobile());
    }

    private void showModifyPhoneNumberDialog() {
        ModifyPhoneNumberDialog modifyPhoneNumberDialog = new ModifyPhoneNumberDialog();
        modifyPhoneNumberDialog.setCancelable(true);
        String number = userLoginInfoViewModel.userLoginInfoLiveData.getValue().getMobile();
        int geo = PhoneUtil.getCountryCode(getContext(), number);
        number = "+" + geo + " " + number;
        modifyPhoneNumberDialog.setCurrentPhoneNumber(number);
        modifyPhoneNumberDialog.setOnModifyPhoneNumberDialogListener(new ModifyPhoneNumberDialog.OnModifyPhoneNumberDialogListener() {
            @Override
            public void onChange() {
                showUserAuthenticationDialog();
                modifyPhoneNumberDialog.dismiss();
            }

            @Override
            public void onCancel() {
                modifyPhoneNumberDialog.dismiss();
            }
        });
        modifyPhoneNumberDialog.show(getChildFragmentManager(), ModifyPhoneNumberDialog.class.getCanonicalName());
    }

    private void showUserAuthenticationDialog() {
        UserAuthenticationDialog userAuthenticationDialog = new UserAuthenticationDialog();
        userAuthenticationDialog.setCancelable(true);
        String number = userLoginInfoViewModel.userLoginInfoLiveData.getValue().getMobile();
        userAuthenticationDialog.setCurrentPhoneNumber(number);
        userAuthenticationDialog.setOnListener(new UserAuthenticationDialog.OnListener() {
            @Override
            public void onSendSmsCode() {
            }

            @Override
            public void onChange() {

            }

            @Override
            public void onCancel() {
                userAuthenticationDialog.dismiss();
            }

            @Override
            public void onSending() {
                if (waitingDialog == null) {
                    waitingDialog = new WaitingDialog();
                }
                waitingDialog.show(getChildFragmentManager(), waitingDialog.getClass().getCanonicalName());
            }

            @Override
            public void onSendFinish() {
                if (waitingDialog != null) {
                    waitingDialog.dismiss();
                }
            }

            @Override
            public void onSendError() {
                if (waitingDialog != null) {
                    waitingDialog.dismiss();
                }
            }

            @Override
            public void onCheckSmsCodeSuccess() {
                userAuthenticationDialog.dismiss();
                ContentActivity.startContentActivityForResult(AccountSecurityFragment.this, BindNewPhoneFragment.class.getCanonicalName(), null, KEY_USER_LOGIN_INFO_VIEW_MODEL);
            }
        });
        userAuthenticationDialog.show(getChildFragmentManager(), ModifyPhoneNumberDialog.class.getCanonicalName());
    }

    private void showDeleteAccountDialog() {
        DeleteAccountDialog deleteAccountDialog = new DeleteAccountDialog();
        deleteAccountDialog.setOnDeleteAccountrDialogListener(new DeleteAccountDialog.OnDeleteAccountrDialogListener() {
            @Override
            public void onConfirm() {
                userLoginInfoViewModel.deleteAccount(requireActivity());
                deleteAccountDialog.dismiss();
            }

            @Override
            public void onCancel() {
                deleteAccountDialog.dismiss();
            }
        });
        deleteAccountDialog.show(getChildFragmentManager(), DeleteAccountDialog.class.getCanonicalName());
    }
}
