package com.jieli.healthaide.tool.history;

import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.os.Handler;
import android.os.Looper;
import android.os.Message;
import android.text.TextUtils;

import androidx.annotation.NonNull;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.jieli.bluetooth_connect.bean.ble.BleScanMessage;
import com.jieli.bluetooth_connect.bean.history.HistoryRecord;
import com.jieli.bluetooth_connect.constant.BluetoothConstant;
import com.jieli.bluetooth_connect.constant.BluetoothError;
import com.jieli.bluetooth_connect.interfaces.callback.OnHistoryRecordCallback;
import com.jieli.bluetooth_connect.util.BluetoothUtil;
import com.jieli.component.utils.PreferencesHelper;
import com.jieli.healthaide.HealthApplication;
import com.jieli.healthaide.tool.bluetooth.BluetoothEventListener;
import com.jieli.healthaide.tool.bluetooth.BluetoothHelper;
import com.jieli.healthaide.tool.net.NetWorkStateModel;
import com.jieli.healthaide.tool.net.NetworkStateHelper;
import com.jieli.healthaide.tool.watch.WatchManager;
import com.jieli.healthaide.ui.device.bean.DeviceHistoryRecord;
import com.jieli.jl_health_http.HttpClient;
import com.jieli.jl_health_http.HttpConstant;
import com.jieli.jl_health_http.model.device.DevConfig;
import com.jieli.jl_health_http.model.device.DevMessage;
import com.jieli.jl_health_http.model.device.IdConfig;
import com.jieli.jl_health_http.model.response.BooleanResponse;
import com.jieli.jl_health_http.model.response.DevMessageListResponse;
import com.jieli.jl_health_http.model.response.DevMessageResponse;
import com.jieli.jl_rcsp.constant.RcspErrorCode;
import com.jieli.jl_rcsp.interfaces.OnOperationCallback;
import com.jieli.jl_rcsp.interfaces.watch.OnWatchCallback;
import com.jieli.jl_rcsp.model.base.BaseError;
import com.jieli.jl_rcsp.model.device.DeviceInfo;
import com.jieli.jl_rcsp.util.JL_Log;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Collections;
import java.util.List;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

/**
 * @author zqjasonZhong
 * @email zhongzhuocheng@zh-jieli.com
 * @desc 历史设备管理
 * @since 2021/7/15
 */
public class HistoryRecordManager implements NetworkStateHelper.Listener {
    private final static String TAG = HistoryRecordManager.class.getSimpleName();
    private volatile static HistoryRecordManager manager;
    private final BluetoothHelper mBluetoothHelper = BluetoothHelper.getInstance();
    private final WatchManager mWatchManager = WatchManager.getInstance();

    private final List<OnServiceRecordListener> mRecordListeners = new ArrayList<>();
    private List<DevMessage> mServiceDevMsgList; //缓存服务器历史列表
    private final List<HistoryTask> mTaskList = Collections.synchronizedList(new ArrayList<>());
    private final Gson gson = new GsonBuilder().create();
    private ReconnectTask reconnectTask;
    private final List<String> boundedDeviceList = new ArrayList<>();
    private boolean isSyncService;  //是否正在同步服务器数据

    private final static String KEY_REMOVE_HISTORY_ID = "remove_history_id";

    private final static int RECONNECT_TIMEOUT = 36 * 1000; //重连超时
    private final static int MSG_RECONNECT_TASK_TIMEOUT = 0x001;
    private final Handler mUIHandler = new Handler(Looper.getMainLooper(), new Handler.Callback() {
        @Override
        public boolean handleMessage(@NonNull Message msg) {
            if (msg.what == MSG_RECONNECT_TASK_TIMEOUT) {
                if (reconnectTask != null) {
                    if (reconnectTask.getCallback() != null) {
                        reconnectTask.getCallback().onFailed(BluetoothError.ERR_TIMEOUT, "reconnect device timeout.");
                    }
                    reconnectTask = null;
                }
            }
            return true;
        }
    });

    private HistoryRecordManager() {
        NetworkStateHelper.getInstance().registerListener(this);
        mBluetoothHelper.addBluetoothEventListener(mEventListener);
        mWatchManager.registerOnWatchCallback(mOnWatchCallback);
    }

    public static HistoryRecordManager getInstance() {
        if (null == manager) {
            synchronized (HistoryRecordManager.class) {
                if (null == manager) {
                    manager = new HistoryRecordManager();
                }
            }
        }
        return manager;
    }

    public void addOnServiceRecordListener(OnServiceRecordListener listener) {
        if (listener == null || mRecordListeners.contains(listener)) return;
        mRecordListeners.add(listener);
    }

    public void removeOnServiceRecordListener(OnServiceRecordListener listener) {
        if (listener == null || mRecordListeners.isEmpty()) return;
        mRecordListeners.remove(listener);
    }

    public void syncHistoryRecordList() {
        if (!isSyncService) {
            isSyncService = true;
            HttpClient.createDeviceApi().queryBoundDeviceList().enqueue(new Callback<DevMessageListResponse>() {
                @Override
                public void onResponse(@NonNull Call<DevMessageListResponse> call, @NonNull Response<DevMessageListResponse> response) {
                    if (!response.isSuccessful()) {
                        onFailure(call, new Throwable("http code error:" + response.code()));
                        return;
                    }
                    DevMessageListResponse devMessageListResponse = response.body();
                    if (null == devMessageListResponse) {
                        onFailure(call, new Throwable("response body is error."));
                        return;
                    }
                    if (devMessageListResponse.getCode() != HttpConstant.HTTP_OK) {
                        onFailure(call, new Throwable("bad code : " + devMessageListResponse.getCode() + ", message : " + devMessageListResponse.getMsg()));
                        return;
                    }
                    List<DevMessage> messageList = devMessageListResponse.getT();
                    if (messageList == null) {
                        messageList = new ArrayList<>();
                    }
                    mServiceDevMsgList = filterBoundDeviceList(filterRemoveHistoryIds(messageList));
                    checkServiceDevList(mServiceDevMsgList);
                    isSyncService = false;
                }

                @Override
                public void onFailure(@NonNull Call<DevMessageListResponse> call, @NonNull Throwable t) {
                    JL_Log.e(TAG, "-syncHistoryRecordList- error = " + t.getMessage());
                    isSyncService = false;
                }
            });
        } else {
            JL_Log.i(TAG, "-syncHistoryRecordList-  queryBoundDeviceList is running.");
//            checkServiceDevList(mServiceDevMsgList);
        }
    }

    public void resetCacheServiceList() {
        if (mServiceDevMsgList != null) {
            mServiceDevMsgList.clear();
        }
    }

    public void release() {
        resetCacheServiceList();
        NetworkStateHelper.getInstance().unregisterListener(this);
        mBluetoothHelper.removeBluetoothEventListener(mEventListener);
        mWatchManager.unregisterOnWatchCallback(mOnWatchCallback);
        mUIHandler.removeCallbacksAndMessages(null);
        boundedDeviceList.clear();
        manager = null;
    }

    @Override
    public void onNetworkStateChange(NetWorkStateModel model) {
        if (model.isAvailable()) {
            syncHistoryRecordList();
        }
    }

    public void reconnectHistory(@NonNull HistoryRecord record, OnHistoryRecordCallback callback) {
        if (isReconnectDevice()) {
            if (callback != null)
                callback.onFailed(RcspErrorCode.ERR_SYSTEM_BUSY, "Reconnect task is in progress.");
            return;
        }
        reconnectTask = new ReconnectTask(record);
        reconnectTask.setCallback(callback);
        reconnectTask.setStartTime(getCurrentTime());
        boolean ret = mBluetoothHelper.getBluetoothOp().startBLEScan(BluetoothConstant.DEFAULT_SCAN_TIMEOUT * 2);
        if (ret) {
            JL_Log.d(TAG, "-reconnectHistory- >>>>>>>>>>>>>>>>>> start . " + reconnectTask);
            mUIHandler.removeMessages(MSG_RECONNECT_TASK_TIMEOUT);
            mUIHandler.sendEmptyMessageDelayed(MSG_RECONNECT_TASK_TIMEOUT, RECONNECT_TIMEOUT);
        } else {
            if (callback != null)
                callback.onFailed(RcspErrorCode.ERR_USE_SYSTEM_API, "Failed to start Reconnect task.");
        }
    }

    public void removeDeviceMsg(final String id, final OnOperationCallback<Boolean> callback) {
        final HistoryTask task = new HistoryTask(HistoryTask.OP_REMOVE, id, null);
        if (addTask(task)) {
            JL_Log.d(TAG, "-removeDeviceMsg- has task." + task);
            return;
        }
        JL_Log.d(TAG, "-removeDeviceMsg- id = " + id);
        saveRemoveHistoryID(id);
        HttpClient.createDeviceApi().unbindDevice(new IdConfig(id)).enqueue(new Callback<BooleanResponse>() {
            @Override
            public void onResponse(@NonNull Call<BooleanResponse> call, @NonNull Response<BooleanResponse> response) {
                if (!response.isSuccessful()) {
                    onFailure(call, new Throwable("http code error:" + response.code()));
                    return;
                }
                BooleanResponse booleanResponse = response.body();
                if (null == booleanResponse) {
                    onFailure(call, new Throwable("response body is error."));
                    return;
                }
                if (booleanResponse.getCode() != HttpConstant.HTTP_OK) {
                    if (booleanResponse.getCode() == HttpConstant.ERROR_DEVICE_NOT_EXIST) {
                        deleteRemoveHistoryId(task.getId());
                    }
                    onFailure(call, new Throwable("bad code : " + booleanResponse.getCode() + ", message : " + booleanResponse.getMsg()));
                    return;
                }
                /*Boolean result = booleanResponse.getT();
                if (result == null) {
                    onFailure(call, new Throwable("response format is error."));
                    return;
                }*/
                removeTask(task);
                deleteRemoveHistoryId(task.getId());
                if (callback != null) {
                    callback.onSuccess(true);
                }
                JL_Log.i(TAG, "-removeDeviceMsg- success = " + task.getId());
            }

            @Override
            public void onFailure(@NonNull Call<BooleanResponse> call, @NonNull Throwable t) {
                JL_Log.e(TAG, "-removeDeviceMsg- error = " + t.getMessage());
                if (t.getMessage() != null && t.getMessage().contains(String.valueOf(HttpConstant.ERROR_DEVICE_NOT_EXIST)) && findDevMessageById(id) == null) {
                    JL_Log.i(TAG, "-removeDeviceMsg- cache no device, success = " + id);
                    deleteRemoveHistoryId(id);
                    if (callback != null) {
                        callback.onSuccess(true);
                    }
                } else {
                    if (callback != null) {
                        callback.onFailed(new BaseError(HttpConstant.ERROR_UNKNOWN, t.getMessage()));
                    }
                }
                removeTask(task);
            }
        });
    }

    private List<DevMessage> filterRemoveHistoryIds(@NonNull List<DevMessage> list) {
        return filterIds(list, getRemoveHistoryID(), HistoryTask.OP_REMOVE);
    }

    private List<DevMessage> filterBoundDeviceList(@NonNull List<DevMessage> list) {
        return filterIds(list, boundedDeviceList, HistoryTask.OP_ADD);
    }

    private List<DevMessage> filterIds(@NonNull List<DevMessage> list, @NonNull List<String> filterList, int op) {
        if (filterList.isEmpty()) {
            return list;
        }
        List<DevMessage> deleteList = new ArrayList<>();
        for (DevMessage devMessage : list) {
            if (op == HistoryTask.OP_REMOVE && isMatchHistoryID(filterList, devMessage.getId()) ||
                    (op == HistoryTask.OP_ADD && isMatchHistoryID(filterList, devMessage.getMac()))) {
                deleteList.add(devMessage);
            }
        }
        if (!deleteList.isEmpty()) {
            JL_Log.i(TAG, "-filterIds- deleteList = " + deleteList.size());
            if (op == HistoryTask.OP_REMOVE) {
                for (DevMessage message : deleteList) {
                    JL_Log.w(TAG, "-filterIds- id = " + message.getId());
                    removeDeviceMsg(message.getId(), null);
                }
            }
            list.removeAll(deleteList);
        }
        return list;
    }

    private void checkServiceDevList(@NonNull List<DevMessage> list) {
        JL_Log.d(TAG, "-checkServiceDevList- >>>>>>>>>>>>>>>>>> start .");
        for (DevMessage devMessage : list) {
            JL_Log.i(TAG, "-checkServiceDevList- " + devMessage);
        }
        JL_Log.d(TAG, "-checkServiceDevList- >>>>>>>>>>>>>>>>>> end .");
        List<HistoryRecord> historyList = mBluetoothHelper.getBluetoothOp().getHistoryRecordList();
        if (historyList == null || historyList.isEmpty()) { //本地记录为空时, 以服务列表为主
            postServiceRecordList(list);
            return;
        }
        //本地记录不为空时，以本地记录为主，同步服务器备份
        //同步信息
        List<DevMessage> serviceList = new ArrayList<>();
        for (DevMessage message : list) {
            boolean isExist = false;
            for (HistoryRecord record : historyList) {
                if (isMatch(record, message)) {
                    isExist = true;
                    break;
                }
            }
            if (!isExist) {
                serviceList.add(message);
            }
        }
        if (!serviceList.isEmpty()) {
            postServiceRecordList(serviceList);
        }
        //添加 -- （仅添加，不删除）
        for (HistoryRecord record : historyList) {
            boolean isExist = isContainsDevMsg(list, record) != null;
            if (!isExist) {
                addDeviceMsg(record);
            }
        }
    }

    private void addDeviceMsg(HistoryRecord record) {
        final DevConfig config = convertHistory(record);
        if (boundedDeviceList.contains(config.getMac())) {
            JL_Log.d(TAG, "-addDeviceMsg- device is bound. mac = " + config.getMac());
            return;
        }
        final HistoryTask task = new HistoryTask(HistoryTask.OP_ADD, null, record);
        if (addTask(task)) {
            JL_Log.d(TAG, "-addDeviceMsg- has task." + task);
            return;
        }
        HttpClient.createDeviceApi().bindDevice(config).enqueue(new Callback<DevMessageResponse>() {
            @Override
            public void onResponse(@NonNull Call<DevMessageResponse> call, @NonNull Response<DevMessageResponse> response) {
                if (!response.isSuccessful()) {
                    onFailure(call, new Throwable("http code error:" + response.code()));
                    return;
                }
                DevMessageResponse devMessageResponse = response.body();
                if (null == devMessageResponse) {
                    onFailure(call, new Throwable("response body is error."));
                    return;
                }
                if (devMessageResponse.getCode() != HttpConstant.HTTP_OK) {
                    if (devMessageResponse.getCode() == HttpConstant.ERROR_DEVICE_BOUND) {
                        if (config.getMac() != null && !boundedDeviceList.contains(config.getMac())) {
                            boundedDeviceList.add(config.getMac());
                        }
                    }
                    onFailure(call, new Throwable("bad code : " + devMessageResponse.getCode() + ", message : " + devMessageResponse.getMsg()));
                    return;
                }
                DevMessage devMessage = devMessageResponse.getT();
                if (devMessage == null) {
                    onFailure(call, new Throwable("response format is error."));
                    return;
                }
               /* if (!mServiceDevMsgList.contains(devMessage)) {
                    mServiceDevMsgList.add(devMessage);
                }*/
                JL_Log.d(TAG, "-addDeviceMsg- bond device success." + devMessage);
                removeTask(task);
                postRecordChange(0, devMessage);
            }

            @Override
            public void onFailure(@NonNull Call<DevMessageResponse> call, @NonNull Throwable t) {
                JL_Log.e(TAG, "-addDeviceMsg- error = " + t.getMessage());
                removeTask(task);
            }
        });
    }

    private void updateConnectTime(BluetoothDevice device) {
        if (mServiceDevMsgList == null || !mBluetoothHelper.isConnectedBtDevice(device)) return;
        DeviceInfo deviceInfo = mWatchManager.getDeviceInfo(device);
        if (deviceInfo == null) return;
        DevMessage devMessage = null;
        for (DevMessage message : mServiceDevMsgList) {
            if (message.getMac() != null && message.getMac().equals(deviceInfo.getEdrAddr())/*
                    && message.getVid() == deviceInfo.getVid()
                    && message.getPid() == deviceInfo.getPid()*/) {
                devMessage = message;
                break;
            }
        }
        if (devMessage == null) {
            JL_Log.w(TAG, "not found DevMessage.");
            return;
        }
        final DevMessage message = devMessage;
        HttpClient.createDeviceApi().updateDeviceTime(new IdConfig(devMessage.getId())).enqueue(new Callback<BooleanResponse>() {
            @Override
            public void onResponse(@NonNull Call<BooleanResponse> call, @NonNull Response<BooleanResponse> response) {
                if (!response.isSuccessful()) {
                    onFailure(call, new Throwable("http code error:" + response.code()));
                    return;
                }
                BooleanResponse booleanResponse = response.body();
                if (null == booleanResponse) {
                    onFailure(call, new Throwable("response body is error."));
                    return;
                }
                if (booleanResponse.getCode() != HttpConstant.HTTP_OK) {
                    if (booleanResponse.getCode() == HttpConstant.ERROR_DEVICE_NOT_EXIST) {
                        mServiceDevMsgList.remove(message);
                    }
                    onFailure(call, new Throwable("bad code : " + booleanResponse.getCode() + ", message : " + booleanResponse.getMsg()));
                    return;
                }
               /*Boolean result = booleanResponse.getT();
                if (result == null) {
                    onFailure(call, new Throwable("response format is error."));
                    return;
                }*/
                JL_Log.i(TAG, "-updateDeviceTime- result = true");
            }

            @Override
            public void onFailure(@NonNull Call<BooleanResponse> call, @NonNull Throwable t) {
                JL_Log.e(TAG, "-updateDeviceTime- error = " + t.getMessage());
            }
        });
    }

    private DevMessage isContainsDevMsg(List<DevMessage> messageList, HistoryRecord record) {
        if (messageList == null || record == null) return null;
        for (DevMessage message : messageList) {
            if (isMatch(record, message)) {
                return message;
            }
        }
        return null;

    }

    private String getCacheEdrAddr(HistoryRecord record) {
        return getCacheAddr(record, BluetoothConstant.PROTOCOL_TYPE_SPP);
    }

    private String getCacheBleAddr(HistoryRecord record) {
        return getCacheAddr(record, BluetoothConstant.PROTOCOL_TYPE_BLE);
    }

    private String getCacheAddr(HistoryRecord record, int type) {
        String address = record.getAddress();
        if (record.getConnectType() != type) {
            address = record.getMappedAddress();
        }
        return address;
    }

    private boolean isMatch(HistoryRecord record, DevMessage message) {
        return message.getMac() != null && message.getMac().equals(getCacheEdrAddr(record));
        /*return message.getMac() != null && message.getMac().equals(getCacheEdrAddr(record)) && message.getPid() == record.getPid()
                && (message.getVid() == record.getVid() || message.getVid() == record.getUid());*/
    }

    private DevConfig convertHistory(HistoryRecord record) {
        DevConfig config = new DevConfig();
        config.setPid(record.getPid());
        config.setVid(record.getVid());
        config.setMac(getCacheEdrAddr(record));
        config.setType(String.valueOf(record.getDevType()));

        ConfigData configData = new ConfigData();
        configData.setName(record.getName());

        AndroidConfigData androidConfigData = new AndroidConfigData();
        androidConfigData.setBle(getCacheBleAddr(record));
        androidConfigData.setConnectWay(record.getConnectType());
        androidConfigData.setSdkType(record.getSdkFlag());

        config.setConfigData(configData.toString());
        config.setAndroidConfigData(androidConfigData.toString());
        return config;
    }

    private ConfigData convertConfigData(String json) {
        ConfigData configData = null;
        if (!TextUtils.isEmpty(json)) {
            try {
                configData = gson.fromJson(json, ConfigData.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return configData;
    }

    private AndroidConfigData convertAndroidConfigData(String json) {
        AndroidConfigData configData = null;
        if (!TextUtils.isEmpty(json)) {
            try {
                configData = gson.fromJson(json, AndroidConfigData.class);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        return configData;
    }

    private List<DeviceHistoryRecord> convertDeviceHistoryRecordByService(List<DevMessage> serviceList) {
        if (serviceList == null || serviceList.isEmpty()) {
            return new ArrayList<>();
        }
        List<DeviceHistoryRecord> list = new ArrayList<>();
        for (DevMessage devMessage : serviceList) {
            if (!BluetoothAdapter.checkBluetoothAddress(devMessage.getMac())) continue;
            ConfigData configData = convertConfigData(devMessage.getConfigData());
            AndroidConfigData androidConfigData = convertAndroidConfigData(devMessage.getAndroidConfigData());
            HistoryRecord record = new HistoryRecord();
            record.setVid(devMessage.getVid());
            record.setPid(devMessage.getPid());
            record.setAddress(devMessage.getMac());
            if (configData != null && configData.getName() != null) {
                record.setName(configData.getName());
            }
            if (androidConfigData != null && BluetoothAdapter.checkBluetoothAddress(androidConfigData.getBle())) {
                record.setConnectType(androidConfigData.getConnectWay());
                record.setSdkFlag(androidConfigData.getSdkType());
                if (record.getConnectType() == BluetoothConstant.PROTOCOL_TYPE_BLE) {
                    record.setAddress(androidConfigData.getBle());
                    record.setMappedAddress(devMessage.getMac());
                } else {
                    record.setMappedAddress(androidConfigData.getBle());
                }
            } else {
                record.setConnectType(0);
            }
            DeviceHistoryRecord deviceHistoryRecord = new DeviceHistoryRecord(record);
            deviceHistoryRecord.setSource(DeviceHistoryRecord.SOURCE_SERVER);
            deviceHistoryRecord.setServerId(devMessage.getId());
            list.add(deviceHistoryRecord);
        }
        return list;
    }

    public DevMessage findDevMessageById(String id) {
        if (TextUtils.isEmpty(id)) return null;
        if (mServiceDevMsgList == null || mServiceDevMsgList.isEmpty()) return null;
        for (DevMessage message : mServiceDevMsgList) {
            if (id.equals(message.getId())) {
                return message;
            }
        }
        return null;
    }

    private void postServiceRecordList(List<DevMessage> list) {
        final List<DeviceHistoryRecord> deviceHistoryRecordList = convertDeviceHistoryRecordByService(list);
        mUIHandler.post(() -> {
            if (!mRecordListeners.isEmpty()) {
                for (OnServiceRecordListener listener : new ArrayList<>(mRecordListeners)) {
                    listener.onServiceRecord(deviceHistoryRecordList);
                }
            }
        });
    }

    private void postRecordChange(final int op, final DevMessage devMessage) {
        mUIHandler.post(() -> {
            if (mRecordListeners.isEmpty()) return;
            for (OnServiceRecordListener listener : new ArrayList<>(mRecordListeners)) {
                listener.onRecordChange(op, devMessage);
            }
        });
    }

    private boolean addTask(HistoryTask task) {
        if (!mTaskList.contains(task)) {
            return !mTaskList.add(task);
        }
        return true;
    }

    private void removeTask(HistoryTask task) {
        if (mTaskList.remove(task)) {
            if (task.getOp() == HistoryTask.OP_REMOVE) {
                DevMessage devMessage = findDevMessageById(task.getId());
                JL_Log.w(TAG, "-removeTask- devMessage = " + devMessage + ", task = " + task);
                if (devMessage != null) {
                    mServiceDevMsgList.remove(devMessage);
                    postRecordChange(task.getOp(), devMessage);
                }
            }
        }
        if (mTaskList.isEmpty()) {
            resetCacheServiceList();
            syncHistoryRecordList();
        }
    }

    private boolean isReconnectDevice() {
        return reconnectTask != null;
    }

    private boolean checkReconnectDevice(BleScanMessage bleScanMessage) {
        if (reconnectTask == null || bleScanMessage == null) return false;
        return bleScanMessage.getEdrAddr() != null && bleScanMessage.getEdrAddr().equals(reconnectTask.getRecord().getAddress());
        /*return (bleScanMessage.getVid() == reconnectTask.getRecord().getVid() || bleScanMessage.getUid() == reconnectTask.getRecord().getVid())
                && bleScanMessage.getPid() == reconnectTask.getRecord().getPid()
                && bleScanMessage.getEdrAddr() != null && bleScanMessage.getEdrAddr().equals(reconnectTask.getRecord().getAddress());*/
    }

    private long getCurrentTime() {
        return Calendar.getInstance().getTimeInMillis();
    }

    private boolean isMatchHistoryID(List<String> list, String string) {
        for (String cache : list) {
            if (cache != null && cache.equals(string)) {
                return true;
            }
        }
        return false;
    }

    private List<String> getRemoveHistoryID() {
        String string = PreferencesHelper.getSharedPreferences(HealthApplication.getAppViewModel().getApplication()).getString(KEY_REMOVE_HISTORY_ID, null);
        if (TextUtils.isEmpty(string)) {
            return new ArrayList<>();
        }
        String[] ids = string.split(",");
        return new ArrayList<>(Arrays.asList(ids));
    }

    private void saveRemoveHistoryID(String id) {
        if (TextUtils.isEmpty(id)) return;
        List<String> ids = getRemoveHistoryID();
        if (!ids.contains(id)) {
            ids.add(id);
            StringBuilder content = new StringBuilder();
            for (String item : ids) content.append(item).append(",");
            PreferencesHelper.putStringValue(HealthApplication.getAppViewModel().getApplication(), KEY_REMOVE_HISTORY_ID, content.toString());
        }
    }

    private void deleteRemoveHistoryId(String id) {
        if (TextUtils.isEmpty(id)) return;
        List<String> ids = getRemoveHistoryID();
        if (ids.remove(id)) {
            if (ids.isEmpty()) {
                PreferencesHelper.remove(HealthApplication.getAppViewModel().getApplication(), KEY_REMOVE_HISTORY_ID);
            } else {
                StringBuilder content = new StringBuilder();
                for (String item : ids) content.append(item).append(",");
                PreferencesHelper.putStringValue(HealthApplication.getAppViewModel().getApplication(), KEY_REMOVE_HISTORY_ID, content.toString());
            }
        }
    }

    private final BluetoothEventListener mEventListener = new BluetoothEventListener() {

        @Override
        public void onHistoryRecord(int op, HistoryRecord record) {
            JL_Log.w(TAG, "-onHistoryRecord- op = " + op + ", record = " + record);
            if (mServiceDevMsgList == null) return;
            DevMessage message = isContainsDevMsg(mServiceDevMsgList, record);
            if (op == 0) {
                if (message == null) {
                    addDeviceMsg(record);
                }
            } else {
                if (message != null) {
                    removeDeviceMsg(message.getId(), null);
                }
            }
        }

        @Override
        public void onBtDiscoveryStatus(boolean bBle, boolean bStart) {
            if (!bStart && isReconnectDevice()) {
                long left = getCurrentTime() - reconnectTask.getStartTime();
                if (left >= BluetoothConstant.DEFAULT_SCAN_TIMEOUT) {
                    mBluetoothHelper.getBluetoothOp().startBLEScan(left);
                }
            }
        }

        @Override
        public void onBtDiscovery(BluetoothDevice device, BleScanMessage bleScanMessage) {
            JL_Log.d(TAG, "-onBtDiscovery- device = " + device + ", bleScanMessage = " + bleScanMessage + ",\n isReconnectDevice : " + reconnectTask);
            if (isReconnectDevice() && checkReconnectDevice(bleScanMessage)) {
                BluetoothDevice targetDev = device;
                if (bleScanMessage.getConnectWay() == BluetoothConstant.PROTOCOL_TYPE_SPP) {
                    targetDev = BluetoothUtil.getRemoteDevice(bleScanMessage.getEdrAddr());
                    if (targetDev == null) {
                        targetDev = device;
                    }
                }
                reconnectTask.setConnectDev(targetDev);
                mBluetoothHelper.getBluetoothOp().stopBLEScan();
                mBluetoothHelper.connectDevice(device, bleScanMessage);
                mUIHandler.removeMessages(MSG_RECONNECT_TASK_TIMEOUT);
            }
        }

        @Override
        public void onConnection(BluetoothDevice device, int status) {
            JL_Log.d(TAG, "-onConnection- device = " + device + ", status = " + status + ", isReconnectDevice : " + isReconnectDevice());
            if (isReconnectDevice() && BluetoothUtil.deviceEquals(device, reconnectTask.getConnectDev())) {
                if (status == BluetoothConstant.CONNECT_STATE_DISCONNECT) {
                    if (reconnectTask.getCallback() != null) {
                        reconnectTask.getCallback().onFailed(BluetoothError.ERR_NOT_CONNECT_REMOTE, "The remote device is not connected");
                    }
                    reconnectTask = null;
                }
            }
        }
    };

    private final OnWatchCallback mOnWatchCallback = new OnWatchCallback() {
        @Override
        public void onWatchSystemInit(int code) {
            if (isReconnectDevice() && BluetoothUtil.deviceEquals(mWatchManager.getConnectedDevice(), reconnectTask.getConnectDev())) {
                if (code == 0) {
                    if (reconnectTask.getCallback() != null) {
                        reconnectTask.getCallback().onSuccess(reconnectTask.getRecord());
                    }
                } else {
                    if (reconnectTask.getCallback() != null) {
                        reconnectTask.getCallback().onFailed(BluetoothError.ERR_NOT_CONNECT_REMOTE, "The remote device is not connected");
                    }
                }
                reconnectTask = null;
            }
            if (code == 0) {
                updateConnectTime(mWatchManager.getConnectedDevice());
            }
        }
    };
}
