package com.jieli.healthaide.data.vo.preview;

import com.jieli.healthaide.data.vo.heart_rate.HeartRateDayVo;

/**
 * @ClassName: PreviewHeartRateVo
 * @Description: 预览视图-心率
 * @Author: ZhangHuanMing
 * @CreateDate: 2021/7/6 8:25
 */
public class PreviewHeartRateVo extends HeartRateDayVo {
}
